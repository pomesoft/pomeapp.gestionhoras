# ==========================================
# Iniciar-MCPInspector.ps1
# Configura variables de entorno y ejecuta
# MCP Inspector
# ==========================================

$env:LLM_PROVIDER = "openai"
$env:LLM_MODEL = "gpt-4.1"
$env:LLM_API_KEY = "BSDFSFERRERd46464"
$env:LLM_BASE_URL = "https://foundrymobile.services.ai.azure.com/"

Write-Host ""
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host " Iniciando MCP Inspector..." -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "Provider : $($env:LLM_PROVIDER)"
Write-Host "Modelo   : $($env:LLM_MODEL)"
Write-Host "Base URL : $($env:LLM_BASE_URL)"
Write-Host ""

npx @modelcontextprotocol/inspector

Write-Host ""
Write-Host "MCP Inspector finalizado." -ForegroundColor Yellow
Pause
