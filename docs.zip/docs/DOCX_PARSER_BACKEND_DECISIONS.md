# Decisiones - Integración de Parser DOCX en NexplanAgente-Backend

## Resumen Ejecutivo
Documento que captura todas las decisiones arquitectónicas, técnicas y de implementación tomadas durante la evaluación de viabilidad para integrar un parser de archivos DOCX en el backend de NexplanAgente, como parte del flujo de estimación con agentes.

---

## Decisiones Principales

### 1. VIABILIDAD DE LA SOLUCIÓN
**Decisión:** ✅ **VIABLE** - Integración del parser DOCX en el backend antes de llamar al LLM

**Contexto:**
- La API debe recibir un prompt + documentos DOCX como parámetros
- El backend debe parsear los archivos antes de invocar GPT-4 (actualmente gpt-4.1)
- Objetivo: Extraer contenido de documentos para enriquecer el contexto del agente estimador

**Rationale:**
- La arquitectura hexagonal actual permite agregar un nuevo puerto `DocumentParser` y adaptadores sin cambios disruptivos
- El flujo existente en `langgraph_functional_analysis_runner.py` puede extenderse para incluir el paso de parsing
- No requiere cambios fundamentales a la estructura de capas (API → Application → Domain → Infrastructure)

**Detalles:**
- Nueva capa en la infraestructura: `DocumentParser` port con adaptador Mammoth
- Se integra en el use case `analyze_functional_requirement`
- Precondición: Parsing antes de invocar `LangGraph` workflow

---

### 2. MANEJO DE IMÁGENES EN DOCUMENTOS DOCX
**Decisión:** 🖼️ **VISION SUMMARY** - Extracción y procesamiento de imágenes con GPT-4o vision

**Contexto:**
- Los documentos DOCX pueden contener imágenes (mockups, diagramas, especificaciones visuales)
- Pasando imágenes en base64 directamente al LLM es viable pero costoso en tokens
- Límite actual de adjuntos: 30 MB (puede cambiar)
- El prompt para estimación requiere esta información visual para precisión

**Rationale:**
- **Escalabilidad:** Procesar imágenes mediante Vision Summary permite manejar documentos con múltiples imágenes sin explosión de tokens
- **Costo controlado:** ~85-170 tokens por imagen en Vision Summary vs. base64 directo que sería más costoso
- **Latencia manejable:** Vision Summary con batch processing mantiene latencia aceptable
- **Calidad:** Descripciones detalladas de imágenes preservan contexto crítico para estimación

**Detalles:**
- Paso 1: Mammoth extrae imágenes del DOCX
- Paso 2: Batch-send imágenes a GPT-4o vision (máximo 5 imágenes por batch recomendado)
- Paso 3: GPT-4o devuelve descripciones detalladas de cada imagen
- Paso 4: Descripciones se enriquecen en el contexto para el flujo de análisis funcional

**Costo Estimado:**
- ~$0.001-0.002 USD por imagen
- ~5 imágenes máximo recomendado para mantener costos y latencia controlados
- Límite adaptativo: Si total imágenes > 5, aplicar downsampling o priorización

---

### 3. FORMATO DE DESCRIPCIONES DE IMÁGENES
**Decisión:** 📝 **DESCRIPCIONES DETALLADAS** - No forzar brevedad

**Contexto:**
- La pregunta inicial fue si la descripción debía ser forzosamente breve
- El contexto de uso es estimación, donde los detalles visuales importan

**Rationale:**
- Las mockups y diagramas contienen información arquitectónica/funcional crítica
- Brevedad forzada podría perder detalles de diseño, flujos o especificaciones visuales
- El agente estimador requiere contexto completo para estimaciones precisas
- Las descripciones detalladas se consumen en contexto, no afectan significativamente el costo final

**Detalles:**
- GPT-4o vision genera descripciones completas y detalladas de las imágenes
- Se incluyen: layout, componentes, flujos visuales, anotaciones, elementos de diseño
- Las descripciones se formatean como texto estructurado en el contexto del prompt

---

### 4. VIABILIDAD DE MULTIMODAL CON LANGCHAIN-OPENAI
**Decisión:** ✅ **CONFIRMADO** - ChatOpenAI soporta nativa multimodal

**Contexto:**
- Se necesitaba verificar si `langchain-openai` y `ChatOpenAI` soportan imágenes
- Verificación realizada analizando código existente en `openai_provider.py` y `langgraph_functional_analysis_runner.py`

**Rationale:**
- `ChatOpenAI` nativa soporta imagen payloads cuando mensajes incluyen bloques "type": "image_url"
- LangChain ya construye estos mensajes correctamente
- No requiere dependencias adicionales más allá de `mammoth` y `python-multipart`
- El código existente de análisis funcional ya usa `ChatOpenAI.invoke(messages)` que es compatible

**Detalles:**
- Verificación: `langgraph_functional_analysis_runner.py` utiliza `ChatOpenAI` sin restricciones de formato
- Los prompts en `graph.py` pueden extenderse para incluir mensajes multimodales
- La construcción de mensajes con imágenes requiere actualización en `prompts.py`

---

### 5. ESTRATEGIA DE IMÁGENES: BASE64 VS VISION SUMMARY
**Decisión:** 🎯 **VISION SUMMARY** - Mejor que base64 directo

**Contexto:**
- Pregunta: ¿Pasar imágenes en base64 directamente al LLM es correcto?
- Escenario: Hasta 10+ imágenes posibles, límite de 30 MB total

**Rationale:**
- **Base64 directo:** Más simple pero exponencial en tokens con múltiples imágenes
- **Vision Summary:** Pre-procesa con GPT-4o vision (especializado), luego envía descripciones textuales
- Mejor balance entre complejidad y costo para documentación con múltiples imágenes
- Permite batch processing y límites controlados
- Escalable si el límite de 30 MB aumenta en futuro

**Comparativa:**
- 1 imagen: base64 directo es comparable
- 5+ imágenes: Vision Summary es ~40-60% más económico en tokens finales
- 10+ imágenes: Vision Summary es crítico para mantener costos y latencia

**Detalles:**
- Se asume documentación heterogénea (textos + diagrams + mockups)
- Batch size máximo recomendado: 5 imágenes por llamada a Vision
- Fallback: Si Vision Summary falla, loguear e intentar continuar sin esa imagen

---

### 6. DEPENDENCIAS NUEVAS
**Decisión:** 📦 **SOLO 2 DEPENDENCIAS** - Mammoth + python-multipart

**Contexto:**
- ¿Qué librerías agregar para soportar parsing DOCX y handling multimodal?

**Rationale:**
- `mammoth`: Estándar de facto para DOCX→HTML/plain-text con buena extracción de imágenes en base64
- `python-multipart`: Necesario para FastAPI recibir archivos multipart/form-data
- No agregar: `python-docx` (incompleto para imágenes), `opencv` (overhead para OCR que no es necesario)
- Reutilizar: `langchain-openai` ya instalado, soporta vision nativamente

**Detalles:**
- Ambas son lightweight y bien mantenidas
- Mammoth produce salida HTML compatible con procesamiento posterior
- python-multipart es estándar en ecosistema FastAPI

---

### 7. VALIDACIONES Y LÍMITES DE ARCHIVO
**Decisión:** ✅ **VALIDACIONES CUÁDRUPLE** - Tipo, tamaño, imágenes, contenido

**Contexto:**
- Necesidad de proteger backend de archivos malformados, excesivos, o problemáticos

**Validaciones a implementar:**
1. **Tipo:** Solo .docx (application/vnd.openxmlformats-officedocument.wordprocessingml.document)
2. **Tamaño:** Máximo 30 MB total por request (ajustable)
3. **Cantidad de archivos:** Máximo 5 archivos DOCX por request (para limitar latencia)
4. **Imágenes:** Máximo 10 imágenes extraídas por documento (validar post-parsing)

**Rationale:**
- Evitar DoS o consumo excesivo de tokens
- Fallar rápido en validación es más eficiente que parsing fallido
- Mensajes de error claros para cliente

---

### 8. CAMBIOS AL MARKDOWN DEL PLAN
**Decisión:** 📄 **ACTUALIZAR DOCX_PARSER_BACKEND_PLAN.md**

**Contexto:**
- El plan original asume implementación de API standalone
- La solución integrada requiere ajustes en la especificación

**Cambios sugeridos:**
1. **Sección "Integración":** Especificar integración en endpoint `/functional-analysis` (no API standalone)
2. **Sección "Parser Port":** Documentar puerto `DocumentParser` + adaptador Mammoth
3. **Sección "Manejo de Imágenes":** Reemplazar con "Vision Summary" approach (extraer → batch vision → descripciones)
4. **Sección "Token Management":** Aclarar que Vision Summary pre-procesa; LangGraph workflow maneja contexto final
5. **Sección "Próximos Pasos":** Actualizar roadmap considerando integración en flujo existente

**Rationale:**
- Plan original se enfocaba en API aislada; realidad es integración en sistema existente
- Vision Summary es estrategia key diferente de lo originalemente documentado
- Aclaraciones mejoran implementación sin perder esencia del parsing

---

### 9. METADATA Y CONTEXTO PRESERVADO
**Decisión:** 📋 **METADATA COMPLETA** - Preservar información de documento

**Contexto:**
- Además de contenido y imágenes, ¿qué metadata preservar?

**Metadata a extraer y pasar:**
1. Nombre del archivo original
2. Fecha de última modificación
3. Autor (si disponible en propiedades DOCX)
4. Número de imágenes extraídas
5. Tamaño del archivo
6. Hash del contenido (para caching opcional)

**Rationale:**
- Agente estimador puede usar metadata para contexto (ej: "documento de hace 3 meses")
- Auditoría y debugging facilitados
- Caching futuro posible mediante hash

**Detalles:**
- Se agrega schema `DocumentMetadata` en domain/models
- Se incluye en payload enviado a LangGraph workflow

---

### 10. MANEJO DE ERRORES Y RESILIENCIA
**Decisión:** 🛡️ **FALLBACK GRACEFUL** - Continuar sin imagen fallida

**Contexto:**
- ¿Qué ocurre si Vision Summary falla para una imagen?
- ¿Qué si un documento no es válido?

**Estrategia:**
1. **Parsing DOCX falla:** Return 400 con error específico (formato corrupto, etc.)
2. **Extracto de imagen falla:** Log warning, continua sin esa imagen (no bloquea)
3. **Vision Summary falla:** Log error, continua con descripción genérica ("Imagen no procesada") 
4. **Total imágenes > límite:** Seleccionar prioritariamente primeras N imágenes (respetar orden en documento)

**Rationale:**
- No permitir que un error visual bloquee estimación completa
- Mejor estimación parcial que fallo total
- Transparency: Cliente informado qué imágenes se procesaron exitosamente

---

### 11. TOKEN MANAGEMENT DELEGADO
**Decisión:** 🔄 **NO TRUNCAR EN PARSER** - Dejar a LangGraph

**Contexto:**
- ¿Quién maneja truncado de tokens si contexto es muy grande?

**Rationale:**
- Parser extrae contenido completo del DOCX
- Vision Summary produce descripciones completas
- LangGraph workflow (`langgraph_functional_analysis_runner.py`) es responsable de:
  - Seleccionar qué información incluir en prompt final
  - Respetar límites de token context window de GPT-4
  - Priorizar información crítica

**Detalles:**
- Parser = extracción bruta
- Workflow = inteligencia de selección
- Separación de concerns clara

---

## Resumen de Cambios Arquitectónicos

| Componente | Cambio | Rationale |
|-----------|--------|-----------|
| Domain Models | + DocumentMetadata schema | Preservar metadata de archivos |
| Application Ports | + DocumentParser port | Abstracción de parsing |
| Infrastructure | + MammothAdapter | Implementar DocumentParser |
| Use Cases | Extender analyze_functional_requirement | Incluir parsing en flujo |
| API Routes | Actualizar request body | Aceptar multi-part/form-data |
| Prompts | + Vision Summary context | Incluir descripciones de imágenes |
| LangGraph Workflow | + Pre-fetch de parsed docs | Integrar documentos en contexto |

---

## Próximos Pasos (Implementación)

1. **Actualizar DOCX_PARSER_BACKEND_PLAN.md** con cambios especificados
2. **Crear DocumentParser port** en `src/application/ports/`
3. **Crear MammothAdapter** en `src/infrastructure/document_parsing/`
4. **Agregar dependencias** (mammoth, python-multipart) a requirements.txt
5. **Extender schemas** en `src/domain/models/schemas.py`
6. **Actualizar use case** `analyze_functional_requirement`
7. **Actualizar API routes** para aceptar archivos
8. **Extender prompts** en `src/infrastructure/agents/prompts.py`
9. **Integrar Vision Summary** en `langgraph_functional_analysis_runner.py`
10. **Agregar validaciones** en API layer
11. **Escribir tests** para parser y Vision Summary
12. **Documentar** en backend_architecture.md

---

## Notas Importantes

- **No es MVP separado:** Todo integrado en flujo existente, no es API standalone
- **Vision Summary es key:** Diferencia entre "pasar base64" y "procesar inteligentemente imágenes"
- **Escalabilidad:** Estrategia soporta documentación heterogénea y futuros aumentos de límites
- **Costo:** Estimado en ~$0.005-0.010 USD por request con 5 imágenes (Vision + Análisis completo)
- **Latencia:** +2-5 segundos adicionales por Vision Summary batch (depende de número de imágenes)

---

**Documento creado:** 2026-06-23  
**Estado:** Decisiones consolidadas, listo para implementación  
**Propuesto por:** Análisis de viabilidad NexplanAgente-Backend
