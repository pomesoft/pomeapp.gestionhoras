# Patrones Arquitectónicos Identificados - NexplanAgente-Backend

**Fecha:** 2026-07-01  
**Propósito:** Documentar patrones de código y estilos a mantener para nuevas implementaciones

---

## 1. Patrones de Puertos y Adaptadores

### 1.1 Definición de Puertos
- **Ubicación:** `src/application/ports/`
- **Estilo:** Usar `Protocol` de `typing` (no `ABC`)
- **Patrón:**
  ```python
  from typing import Protocol
  
  class MyPort(Protocol):
      def method_name(self) -> ReturnType:
          ...
  ```
- **Ventaja:** Más flexible que ABC, permite implementaciones implícitas
- **Ejemplo existente:** `LlmProvider`, `AgentRunner`

### 1.2 Implementación de Adaptadores
- **Ubicación:** `src/infrastructure/`
- **Patrón:** Clases concretas que implementan el puerto
- **Inyección:** Constructor con dependencias
- **Ejemplo:**
  ```python
  class ConcreteAdapter:
      def __init__(self, dependency: Type):
          self._dependency = dependency
      
      def method_name(self) -> ReturnType:
          # implementación
  ```

---

## 2. Patrones de Modelos de Dominio

### 2.1 Dataclasses Congeladas
- **Ubicación:** `src/domain/models/schemas.py`
- **Estilo:** `@dataclass(frozen=True)` para inmutabilidad
- **Uso:** Estados, configuraciones, resultados finales
- **Ejemplo:**
  ```python
  @dataclass(frozen=True)
  class AgentDiagnostics:
      workflow: str = "functional_analysis"
      trace: list[str] = field(default_factory=list)
  ```

### 2.2 Modelos Pydantic
- **Estilo:** `BaseModel` con validación
- **Patrón:** Para requests/responses de API
- **ConfigDict:** Usar `model_config = ConfigDict(extra="forbid")`
- **Ejemplo:**
  ```python
  class FunctionalAnalysisRequest(BaseModel):
      specification: str
      skip_previous_evaluation: bool = False
      model_config = ConfigDict(extra="forbid")
  ```

---

## 3. Patrones de Código

### 3.1 Imports
- Usar `from __future__ import annotations` al inicio de archivos
- Imports ordenados: stdlib → third-party → local
- Usar type hints en todas las funciones

### 3.2 Type Hints
- Obligatorio en todas las firmas de función
- Usar tipos específicos (`list[Type]` en lugar de `List[Type]`)
- Usar `Optional[Type]` cuando sea None posible

### 3.3 Métodos Async
- Patrón observable en `langgraph_functional_analysis_runner.py`
- Usar `async def` para operaciones no bloqueantes
- Usar `asyncio.to_thread()` para llamadas síncronas en contexto async

### 3.4 Manejo de Errores
- Crear excepciones custom en `src/domain/errors.py`
- Usar excepciones específicas, no genéricas
- Pattern: Catch específico → re-raise custom

---

## 4. Estructura de Directorios - Capas

```
src/
├─ domain/                  # Modelos de negocio puros
│  ├─ models/              # Dataclasses, esquemas
│  ├─ errors.py            # Excepciones custom
│  └─ __init__.py
├─ application/            # Casos de uso, puertos
│  ├─ ports/              # Interfaces/protocols
│  ├─ use_cases/          # Lógica de aplicación
│  ├─ services/           # Servicios transversales
│  ├─ dtos/               # Data Transfer Objects
│  └─ __init__.py
└─ infrastructure/         # Implementaciones concretas
   ├─ agents/             # Runners de LLM
   ├─ llm/                # Providers
   ├─ documents/          # Extractores de documentos
   ├─ document_parsing/   # [NUEVO] Parsing DOCX
   ├─ config/             # Configuraciones
   └─ __init__.py
```

---

## 5. Patrones de Integración

### 5.1 Inyección de Dependencias
- Constructor con parámetros de dependencias
- Settings inyectado via `FastAPI` Dependencies
- Configuración centralizada en `infrastructure/config/settings.py`

### 5.2 Workflow LangGraph
- Definido en `infrastructure/agents/graph.py`
- Nodos = funciones async
- Edges = transiciones condicionales
- Estado = dict con campos específicos
- Compilación = `.compile()`
- Ejecución = `.stream()` con `stream_mode="updates"`

### 5.3 Prompts
- Usar `ChatPromptTemplate.from_template()` con `template_format="jinja2"`
- Variables de template con `{{ variable }}`
- Centralizar prompts en `infrastructure/agents/prompts.py`

---

## 6. Puntos de Integración para Parser DOCX

### 6.1 Dónde Entra el Parser
1. **Endpoint de entrada:** `/functional-analysis` (FastAPI)
2. **Flujo:** Recibe especificación (texto o archivo)
3. **Si es DOCX:** Parser extrae contenido
4. **Vision Summary:** Procesa imágenes extraídas
5. **Salida:** Especificación enriquecida → workflow LangGraph

### 6.2 Integración en Workflow
- **Entrada:** `FunctionalAnalysisRequest` (con archivo opcional)
- **Nodo pre-análisis:** Validar y parsear DOCX si existe
- **Estado workflow:** Campo `document_context` con contenido extraído
- **En prompts:** Incluir contexto de documento

### 6.3 Respuesta Enriquecida
- **Metadata:** `analysis_metadata` contiene info del documento
- **Descripciones:** Imágenes descritas por Vision Summary
- **Referencias:** Vincular hallazgos con secciones del documento

---

## 7. Convenios de Código

### 7.1 Nombres
- Clases: `PascalCase` (ej: `MammothAdapter`)
- Funciones/métodos: `snake_case` (ej: `parse_docx`)
- Constantes: `UPPER_SNAKE_CASE`
- Privados: prefijo `_` (ej: `_extract_images`)

### 7.2 Docstrings
- Usar docstrings en funciones públicas
- Formato: descripción → Args → Returns → Raises
- Ejemplo:
  ```python
  def parse_docx(self, file_path: str) -> ParsedDocument:
      """
      Parsea un archivo DOCX y extrae contenido + imágenes.
      
      Args:
          file_path: Ruta al archivo .docx
      
      Returns:
          ParsedDocument con contenido, metadata e imágenes
      
      Raises:
          FileNotFoundError: Si archivo no existe
          ValueError: Si archivo no es DOCX válido
      """
  ```

### 7.3 Logging
- Usar `logging.getLogger(__name__)` en módulos
- Niveles: INFO (eventos), WARNING (problemas), ERROR (fallos)

---

## 8. Convenciones de Testing

### 8.1 Ubicación
- **Unit tests:** `tests/unit/test_*.py`
- **Integration:** `tests/integration/test_*.py`

### 8.2 Framework
- Pytest
- Fixtures para dependencias
- Mocking para servicios externos

---

## Resumen para FASE 1
✅ **Completado:**
- Dependencias instaladas (mammoth 1.4.28)
- Estructura de directorios creada
- Patrones arquitectónicos documentados
- Puntos de integración identificados

**Siguiente (FASE 2):** Crear modelos de dominio (`document_models.py`)
