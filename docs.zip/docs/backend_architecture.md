# Arquitectura Backend FastAPI - Agente Analista Funcional

## Resumen

El backend expone el agente de analisis funcional como una WebAPI sincrona y stateless. La implementacion sigue Clean Architecture para que la capa HTTP no dependa de LangGraph, LangChain ni de un proveedor LLM concreto.

La version inicial implementa OpenAI `gpt-4.1` y deja puertos preparados para RAG, multiples proveedores LLM y orquestacion multiagente.

## Capas

```mermaid
flowchart TB
    Client["Cliente Web / Frontend / Integrador"] --> API["FastAPI Controllers"]

    API --> App["Application Layer<br/>Use Cases"]
    App --> Domain["Domain Layer<br/>Models + Errors"]
    App --> Ports["Application Ports"]

    Ports --> AgentAdapter["Infrastructure<br/>LangGraph Agent Adapter"]
    Ports --> LLMAdapter["Infrastructure<br/>LLM Provider Adapter"]
    Ports --> RAGAdapter["Infrastructure<br/>Retriever Port futuro"]

    AgentAdapter --> LangGraph["LangGraph Workflow"]
    LLMAdapter --> OpenAI["OpenAI GPT-4.1"]
    LLMAdapter -. futuro .-> Gemini["Gemini"]
    LLMAdapter -. futuro .-> Anthropic["Anthropic"]
    RAGAdapter -. futuro .-> VectorStore["Vector Store / Retriever"]
```

Responsabilidades:

- `src/api`: endpoints, schemas HTTP, dependency injection y traduccion de errores a HTTP.
- `src/application`: casos de uso y puertos.
- `src/domain`: modelos y errores propios del negocio.
- `src/infrastructure`: adapters concretos para LangGraph, OpenAI y configuracion.

## Contrato HTTP

### `POST /api/v1/functional-analysis`

Ejecuta el analisis funcional de una especificacion en texto libre y devuelve una
respuesta normalizada para consumo de frontend o integradores. Antes de ejecutar
el analisis completo, el backend puede evaluar si la especificacion tiene detalle
suficiente. Si no lo tiene, responde `200` con `needs_complete_specification=true`,
un `requested_detail` y un analisis vacio; en ese caso no se ejecuta el nodo de
analisis funcional.

#### Descripcion funcional

El endpoint recibe una especificacion funcional y la procesa con el workflow
LangGraph del agente analista funcional.

Flujo de decision:

1. FastAPI valida el contrato Pydantic del request.
2. Si `specification` es exactamente `""` o `"string"`, la ruta corta la
   ejecucion y devuelve un analisis vacio solicitando mayor detalle. Este caso
   evita procesar valores placeholder de clientes o Swagger.
3. El caso de uso limpia espacios con `strip()`. Si la especificacion queda
   vacia, responde `400`.
4. Si `skip_previous_evaluation=false`, el workflow ejecuta primero
   `evaluate_functional_specification`.
5. La evaluacion previa consulta al LLM y espera JSON con:
   `needs_complete_specification` y `requested_detail`.
6. Si `needs_complete_specification=true`, el workflow finaliza sin ejecutar
   `analyze_functional_specification`.
7. Si `needs_complete_specification=false`, o si
   `skip_previous_evaluation=true`, se ejecuta el analisis funcional y
   se devuelve el contrato completo normalizado.

La evaluacion previa pide completar informacion cuando la especificacion es
demasiado breve o ambigua, no permite identificar funcionalidades o tareas
minimas, no permite inferir actores o contexto de uso, no describe entradas,
salidas, reglas de negocio o flujo esperado, no permite detectar componentes o
integraciones relevantes, tiene contradicciones importantes, o es solo una idea
general sin alcance funcional minimo. No pide detalle por informacion que pueda
inferirse razonablemente.

#### Parametros de input

Body JSON:

```json
{
  "specification": "Se requiere implementar login, recuperacion de clave y ABM de usuarios.",
  "skip_previous_evaluation": false
}
```

Campos:

| Campo | Tipo | Obligatorio | Default | Descripcion |
| --- | --- | --- | --- | --- |
| `specification` | `string` | Si | - | Texto libre con la especificacion funcional a evaluar y analizar. |
| `skip_previous_evaluation` | `boolean` | No | `false` | Si es `true`, salta la evaluacion previa de completitud y ejecuta directamente el analisis funcional. |

#### Datos devueltos

Respuesta `200` cuando la especificacion se procesa correctamente o cuando se
requiere mas detalle:

```json
{
  "needs_complete_specification": false,
  "requested_detail": "",
  "analysis": {
    "functional_summary": "",
    "detected_tasks": [],
    "technical_components": [],
    "detected_integrations": [],
    "detected_risks": [],
    "assumptions": [],
    "observations": [],
    "analysis_metadata": {}
  },
  "diagnostics": {
    "workflow": "functional_analysis",
    "model": "gpt-4.1",
    "parse_method": "structured",
    "trace": []
  }
}
```

Campos:

| Campo | Tipo | Descripcion |
| --- | --- | --- |
| `needs_complete_specification` | `boolean` | `true` cuando la evaluacion previa determina que no debe ejecutarse el analisis funcional porque falta detalle. `false` cuando el analisis se ejecuto o puede ejecutarse. |
| `requested_detail` | `string` | Detalle concreto de la informacion faltante. Viene vacio cuando `needs_complete_specification=false`. |
| `analysis.functional_summary` | `string` | Sintesis del alcance funcional detectado. |
| `analysis.detected_tasks` | `array` | Lista principal de tareas o funcionalidades detectadas. Cada item contiene `name` y `description`. |
| `analysis.technical_components` | `array[string]` | Componentes, modulos o capacidades tecnicas inferidas desde el requerimiento. |
| `analysis.detected_integrations` | `array[string]` | Integraciones externas o internas identificadas. |
| `analysis.detected_risks` | `array[string]` | Riesgos funcionales o tecnicos relevantes. |
| `analysis.assumptions` | `array[string]` | Supuestos usados para completar inferencias razonables. |
| `analysis.observations` | `array[string]` | Notas adicionales del analisis. |
| `analysis.analysis_metadata` | `object` | Metadatos como modelo, metodo de parseo, fecha de ejecucion y cantidades detectadas. Queda vacio si no se ejecuta el analisis. |
| `diagnostics` | `object` | Diagnostico del workflow. Siempre se incluye en la respuesta. |
| `diagnostics.workflow` | `string` | Identificador del workflow, actualmente `functional_analysis`. |
| `diagnostics.model` | `string` | Modelo usado por el agente. |
| `diagnostics.parse_method` | `string` | Metodo de parseo utilizado: `structured`, `json_text`, `lines`, `specification_evaluation` o `error`. |
| `diagnostics.trace` | `array[string]` | Trazas del workflow. |

Ejemplo de respuesta cuando falta detalle suficiente:

```json
{
  "needs_complete_specification": true,
  "requested_detail": "Faltan reglas de negocio y flujo esperado para gestionar el stock.",
  "analysis": {
    "functional_summary": "",
    "detected_tasks": [],
    "technical_components": [],
    "detected_integrations": [],
    "detected_risks": [],
    "assumptions": [],
    "observations": [],
    "analysis_metadata": {}
  },
  "diagnostics": {
    "workflow": "functional_analysis",
    "model": "gpt-4.1",
    "parse_method": "specification_evaluation",
    "trace": [
      "Workflow 1: specification evaluation executed",
      "Needs complete specification: True"
    ]
  }
}
```

Errores:

- `400`: especificacion vacia o invalida.
- `422`: request mal formado.
- `503`: configuracion LLM ausente o proveedor no disponible.
- `504`: timeout del LLM o workflow.
- `500`: error inesperado controlado.

### Health checks

- `GET /health`: valida que el proceso responde.
- `GET /ready`: valida configuracion minima del proveedor LLM.

## Flujo Sincrono

```mermaid
sequenceDiagram
    participant C as Cliente
    participant API as FastAPI Endpoint
    participant UC as AnalyzeFunctionalRequirementUseCase
    participant AR as AgentRunner Port
    participant LG as LangGraph Adapter
    participant LLM as OpenAI GPT-4.1

    C->>API: POST /api/v1/functional-analysis
    API->>API: Validar request Pydantic
    alt specification es "" o "string"
        API-->>C: 200 needs_complete_specification=true + analisis vacio
    else specification con contenido
        API->>UC: execute(specification, skip_previous_evaluation)
        UC->>AR: run(specification)
        AR->>LG: Crear estado inicial stateless
        alt skip_previous_evaluation=false
            LG->>LLM: Evaluar completitud de especificacion
            LLM-->>LG: JSON de evaluacion
            alt needs_complete_specification=true
                LG-->>AR: Analisis vacio + evaluacion incompleta
            else especificacion suficiente
                LG->>LLM: Invocar prompt de analisis funcional
                LLM-->>LG: Respuesta de analisis
                LG->>LG: Parsear y normalizar salida
            end
        else skip_previous_evaluation=true
            LG->>LLM: Invocar prompt de analisis funcional
            LLM-->>LG: Respuesta de analisis
            LG->>LG: Parsear y normalizar salida
        end
        LG-->>AR: FunctionalAnalysisResult
        AR-->>UC: Resultado de dominio
        UC-->>API: Response DTO
        API-->>C: 200 JSON
    end
```

## Preparacion RAG Y Multiagente

```mermaid
flowchart LR
    UseCase["Use Case<br/>Analyze Functional Requirement"] --> Orchestrator["Agent Orchestrator Port"]

    Orchestrator --> AF["Agente Analista Funcional"]
    Orchestrator -. futuro .-> RAG["Agente RAG / Context Retriever"]
    Orchestrator -. futuro .-> QA["Agente QA / Consistencia"]
    Orchestrator -. futuro .-> EST["Agente Estimacion"]

    RAG -. futuro .-> VS["Vector Store"]
    AF --> LLM["LLM Provider Port"]
    QA --> LLM
    EST --> LLM

    LLM --> OpenAI["OpenAI"]
    LLM -. futuro .-> Gemini["Gemini"]
    LLM -. futuro .-> Anthropic["Anthropic"]
```

## Configuracion

Variables principales:

```powershell
$env:LLM_PROVIDER="openai"
$env:LLM_API_KEY="..."
$env:LLM_BASE_URL="https://foundrymobile.services.ai.azure.com/openai/v1/"
$env:LLM_MODEL="gpt-4.1"
$env:LLM_VERIFY_TLS="true"
$env:LLM_TIMEOUT_SECONDS="60"
```

La WebAPI no escribe checkpoints SQLite. El workflow LangGraph se compila sin checkpointer para cada ejecucion API.

## Ejecucion

```powershell
uvicorn src.main:app --reload
```

## Pruebas

```powershell
python -m pytest
```
