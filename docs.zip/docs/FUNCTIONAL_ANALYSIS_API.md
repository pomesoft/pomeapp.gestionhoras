# Especificación funcional de los endpoints de análisis funcional

## Visión general

El backend expone una API REST construida con **FastAPI** para realizar análisis funcional asistido por un agente de IA sobre especificaciones de requerimientos. Todos los endpoints están prefijados con `/api/v1`.

Ambos endpoints implementan:

- Autenticación mediante token **Bearer JWT de Azure AD**.
- Un mismo flujo de análisis funcional basado en LangGraph.
- El mismo esquema de respuesta: `FunctionalAnalysisApiResponse`.

| Método | Ruta | Descripción |
|--------|------|-------------|
| `POST` | `/api/v1/functional-analysis` | Analiza una especificación funcional enviada como JSON. |
| `POST` | `/api/v1/functional-analysis/upload` | Permite enviar una especificación opcional junto con uno o varios archivos adjuntos (.txt, .pdf, .docx). Extrae y consolida el texto de los archivos antes de ejecutar el análisis. |

---

## Modelos y esquemas

### FunctionalAnalysisRequest (cuerpo JSON, endpoint `/functional-analysis`)

| Campo | Tipo | Requerido | Descripción |
|-------|------|-----------|-------------|
| `specification` | `string` | Sí | Texto de la especificación funcional a analizar. |
| `skip_previous_evaluation` | `boolean` | No (default: `false`) | Si es `true`, omite la evaluación previa de suficiencia de la especificación. |

### Campos del multipart `/functional-analysis/upload`

| Campo | Tipo | Requerido | Descripción |
|-------|------|-----------|-------------|
| `specification` | `string` | No | Texto libre con la especificación funcional (ingresado manualmente). |
| `skip_previous_evaluation` | `boolean` | No (default: `false`) | Omite la evaluación previa de suficiencia. |
| `files` | `array` de `UploadFile` | No (pero se exige texto o al menos un archivo) | Archivos adjuntos. Pueden enviarse múltiples archivos bajo el mismo campo `files`. |

Formatos de archivo soportados:

- `.txt`
- `.pdf`
- `.docx`

Restricciones:

- Cada archivo se valida contra una lista blanca de extensiones.
- El tamaño máximo por archivo se define en la variable de entorno `MAX_FILE_SIZE_MB` (por defecto: `10 MB`).
- Los archivos se procesan **en memoria**, sin persistirse en disco.

### Respuesta exitosa: FunctionalAnalysisApiResponse

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `needs_complete_specification` | `boolean` | `true` si el agente detectó que faltan detalles para realizar el análisis. |
| `requested_detail` | `string` | Detalle adicional solicitado por el agente cuando `needs_complete_specification` es `true`. |
| `analysis` | `FunctionalAnalysisResponseModel` | Resultado estructurado del análisis funcional. |
| `diagnostics` | `DiagnosticsResponse` | Metadatos de ejecución del workflow. |

### FunctionalAnalysisResponseModel (campo `analysis`)

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `functional_summary` | `string` | Resumen funcional generado por el agente. |
| `detected_tasks` | `array` de `DetectedTaskModel` | Tareas identificadas en la especificación. |
| `technical_components` | `array` de `string` | Componentes técnicos detectados. |
| `detected_integrations` | `array` de `string` | Integraciones detectadas. |
| `detected_risks` | `array` de `string` | Riesgos detectados. |
| `assumptions` | `array` de `string` | Supuestos realizados por el agente. |
| `observations` | `array` de `string` | Observaciones adicionales. |
| `analysis_metadata` | `object` | Metadatos específicos del análisis, como modelo, método de parseo y cantidad de tareas. |

#### DetectedTaskModel

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `name` | `string` | Nombre de la tarea. |
| `description` | `string` | Descripción de la tarea. |

### DiagnosticsResponse (campo `diagnostics`)

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `workflow` | `string` | Identificador del workflow, normalmente `"functional_analysis"`. |
| `model` | `string` | Modelo de lenguaje utilizado. |
| `parse_method` | `string` | Método de parseo aplicado. Cuando la especificación es insuficiente, devuelve `"specification_evaluation"`. |
| `trace` | `array` de `string` | Traza de ejecución del workflow. |

---

## Endpoint 1: POST `/api/v1/functional-analysis`

### Descripción
Analiza una especificación funcional enviada directamente en el cuerpo de la solicitud como JSON.

### Seguridad
Se requiere un header `Authorization: Bearer <token_jwt_de_azure_ad>`.

### Request

**Content-Type:** `application/json`

```json
{
  "specification": "Se requiere implementar un módulo de autenticación con login, recuperación de contraseña, validación de sesión y ABM de usuarios.",
  "skip_previous_evaluation": false
}
```

### Lógica de negocio

1. Si `specification` es vacío o el literal `"string"`, se devuelve inmediatamente una respuesta indicando que la especificación necesita más detalle.
2. El caso de uso `AnalyzeFunctionalRequirementUseCase` valida que la especificación no esté vacía.
3. Se ejecuta el workflow de análisis funcional a través de `LangGraphFunctionalAnalysisRunner`.
4. Se construye la respuesta combinando evaluación, análisis y diagnósticos.

### Response exitosa (200 OK)

```json
{
  "needs_complete_specification": false,
  "requested_detail": "",
  "analysis": {
    "functional_summary": "El sistema requiere un módulo de autenticación que permita el ingreso de usuarios, recuperación de credenciales, control de sesión y administración de cuentas.",
    "detected_tasks": [
      {
        "name": "Login de usuarios",
        "description": "Permitir el ingreso al sistema mediante credenciales válidas."
      },
      {
        "name": "Recuperación de contraseña",
        "description": "Generar un flujo seguro para restablecer la contraseña."
      },
      {
        "name": "ABM de usuarios",
        "description": "Permitir altas, bajas y modificaciones de cuentas de usuario."
      }
    ],
    "technical_components": [
      "Servicio de autenticación",
      "Base de datos de usuarios",
      "Gestor de sesiones"
    ],
    "detected_integrations": [
      "Servicio de correo electrónico para recuperación de contraseña"
    ],
    "detected_risks": [
      "Almacenamiento inseguro de contraseñas"
    ],
    "assumptions": [
      "Se asume que existe un servidor de correo configurado."
    ],
    "observations": [
      "No se explicitan requisitos de multifactor."
    ],
    "analysis_metadata": {
      "model": "gpt-4o-mini",
      "parse_method": "json",
      "task_count": 3
    }
  },
  "diagnostics": {
    "workflow": "functional_analysis",
    "model": "gpt-4o-mini",
    "parse_method": "json",
    "trace": [
      "Paso 1: evaluación de especificación",
      "Paso 2: análisis funcional"
    ]
  }
}
```

### Response cuando faltan detalles (200 OK)

```json
{
  "needs_complete_specification": true,
  "requested_detail": "Por favor indique si el módulo de autenticación debe soportar autenticación multifactor y cuáles son los roles de usuario esperados.",
  "analysis": {
    "functional_summary": "",
    "detected_tasks": [],
    "technical_components": [],
    "detected_integrations": [],
    "detected_risks": [],
    "assumptions": [],
    "observations": [],
    "analysis_metadata": {}
  },
  "diagnostics": {
    "workflow": "functional_analysis",
    "model": "",
    "parse_method": "specification_evaluation",
    "trace": []
  }
}
```

---

## Endpoint 2: POST `/api/v1/functional-analysis/upload`

### Descripción
Acepta una especificación textual opcional y/o archivos adjuntos. Extrae el texto de cada archivo (.txt, .pdf, .docx), consolida el texto manual con el texto extraído en una única especificación y luego ejecuta el análisis funcional.

### Seguridad
Se requiere un header `Authorization: Bearer <token_jwt_de_azure_ad>`.

### Request

**Content-Type:** `multipart/form-data`

| Parte | Tipo | Requerido | Descripción |
|-------|------|-----------|-------------|
| `specification` | `text/plain` | No | Especificación funcional ingresada manualmente. |
| `skip_previous_evaluation` | `text/plain` | No | `"true"` o `"false"` (default: `"false"`). |
| `files` | `file` | No (al menos uno entre `specification` o `files`) | Archivos adjuntos. Puede repetirse para enviar varios. |

Ejemplo de cuerpo `multipart/form-data`:

```http
--boundary
Content-Disposition: form-data; name="specification"

Se requiere implementar un módulo de autenticación...
--boundary
Content-Disposition: form-data; name="skip_previous_evaluation"

false
--boundary
Content-Disposition: form-data; name="files"; filename="requerimientos.pdf"
Content-Type: application/pdf

<contenido binario del PDF>
--boundary
Content-Disposition: form-data; name="files"; filename="notas.txt"
Content-Type: text/plain

El sistema debe permitir login con usuario y contraseña.
--boundary--
```

### Lógica de negocio

1. Para cada archivo recibido:
   - Se valida extensión y tamaño máximo.
   - Se extrae el texto según el formato.
   - Si la extracción falla, se registra un warning pero se continúa con los archivos restantes.
2. Se consolida el texto manual y el extraído en una sola cadena con el siguiente formato:

   ```markdown
   # Especificación ingresada por el usuario

   {texto_manual}

   # Documentación adjunta

   ## Archivo: archivo1.pdf

   {texto_extraído}

   ## Archivo: archivo2.txt

   {texto_extraído}
   ```

3. Si la especificación consolidada está vacía, se responde con `400 Bad Request`.
4. Si la especificación consolidada es válida, se delega al mismo caso de uso del endpoint JSON.
5. Los errores de extracción se loguean pero no interrumpen el análisis, siempre que exista contenido válido.

### Response exitosa (200 OK)

Comparte el mismo formato que el endpoint `/functional-analysis`.

```json
{
  "needs_complete_specification": false,
  "requested_detail": "",
  "analysis": {
    "functional_summary": "...",
    "detected_tasks": [...],
    "technical_components": [...],
    "detected_integrations": [...],
    "detected_risks": [...],
    "assumptions": [...],
    "observations": [...],
    "analysis_metadata": {...}
  },
  "diagnostics": {
    "workflow": "functional_analysis",
    "model": "...",
    "parse_method": "...",
    "trace": [...]
  }
}
```

---

## Códigos de estado

| Código | Descripción | Cuándo ocurre |
|--------|-------------|---------------|
| `200 OK` | Análisis exitoso. | El agente completó el análisis y devuelve el resultado estructurado. |
| `400 Bad Request` | Solicitud inválida. | Especificación vacía, o en `/upload` no hay texto ni archivos con contenido extraíble. |
| `401 Unauthorized` | No autorizado. | Falta el header `Authorization`, el token es inválido, expiró, o no coincide audience/issuer. |
| `500 Internal Server Error` | Error inesperado. | Excepción no controlada durante la ejecución del agente. |
| `503 Service Unavailable` | Servicio no disponible. | Configuración de LLM ausente o proveedor no soportado/no disponible. No se pudo contactar al servidor JWKS de Azure AD. |
| `504 Gateway Timeout` | Timeout del workflow. | El LLM o el workflow excedieron el tiempo máximo configurado. |

---

## Notas de implementación

- El workflow de análisis devuelve `needs_complete_specification = true` mediante un código de estado `200 OK`, no como un error del cliente.
- En el endpoint `/upload`, los archivos que no pueden extraerse no detienen el procesamiento; sólo reducen el contenido disponible para el análisis.
- El campo `analysis_metadata` es rellenado por el agente y puede incluir campos como `model`, `parse_method` y `task_count`.
- La validación del token JWT utiliza el JWKS endpoint de Azure AD configurado en `AZURE_JWKS_URI`, verificando firma, audience (`AZURE_AUDIENCE`), issuer (`AZURE_ISSUER`) y expiración.
