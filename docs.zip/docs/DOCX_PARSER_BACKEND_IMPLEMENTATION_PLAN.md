
# Plan de Implementación - Parser DOCX en NexplanAgente-Backend

**Documento:** DOCX_PARSER_BACKEND_IMPLEMENTATION_PLAN.md  
**Fecha de creación:** 2026-07-01  
**Estado:** En preparación para implementación  
**Referencia:** Basado en DOCX_PARSER_BACKEND_DECISIONS.md  
**Objetivo:** Integración completa del parser DOCX con Vision Summary en el flujo existente de análisis funcional

---

## Tabla de Contenidos

1. [Visión General](#visión-general)
2. [Estructura de Fases](#estructura-de-fases)
3. [Fase 1: Preparación del Entorno](#fase-1-preparación-del-entorno)
4. [Fase 2: Componentes Base](#fase-2-componentes-base)
5. [Fase 3: Integración Parser](#fase-3-integración-parser)
6. [Fase 4: Vision Summary](#fase-4-vision-summary)
7. [Fase 5: Integración en Workflow](#fase-5-integración-en-workflow)
8. [Fase 6: Validaciones y Seguridad](#fase-6-validaciones-y-seguridad)
9. [Fase 7: Testing](#fase-7-testing)
10. [Fase 8: Documentación y Despliegue](#fase-8-documentación-y-despliegue)
11. [Dependencias Críticas](#dependencias-críticas)
12. [Criterios de Éxito](#criterios-de-éxito)

---

## Visión General

### Contexto
Este plan implementa la integración del parser de archivos DOCX en el backend de NexplanAgente, permitiendo que el agente estimador acceda a contenido de documentos y procesamiento inteligente de imágenes mediante Vision Summary. La solución NO es un API standalone, sino una integración en el flujo existente de análisis funcional.

### Alcance
- ✅ Parsing de archivos DOCX con extracción de contenido e imágenes
- ✅ Procesamiento de imágenes mediante Vision Summary (GPT-4o vision)
- ✅ Integración en endpoint `/functional-analysis` existente
- ✅ Validaciones de tipo, tamaño y contenido de archivos
- ✅ Manejo de metadatos de documento
- ✅ Estrategia de fallback graceful para errores

### No en Alcance (v1)
- ❌ OCR de imágenes escaneadas
- ❌ Extracción de tablas complejas
- ❌ Conversión de DOCX a PDF
- ❌ API standalone de parsing (integración only)

---

## Estructura de Fases

```
┌──────────────────────────────────────────────────────────────┐
│ FASE 1: Preparación (Dependencias + Estructura Base)         │
├──────────────────────────────────────────────────────────────┤
│  ├─ Actualizar requirements.txt (mammoth, python-multipart) │
│  ├─ Crear estructura de directorios                          │
│  └─ Configurar workspace                                     │
├──────────────────────────────────────────────────────────────┤
│ FASE 2: Componentes Base (Domain + Ports)                    │
├──────────────────────────────────────────────────────────────┤
│  ├─ DocumentMetadata schema (domain/models)                  │
│  ├─ DocumentParser port (application/ports)                 │
│  └─ DTOs y tipos de respuesta                               │
├──────────────────────────────────────────────────────────────┤
│ FASE 3: Integración Parser (Infrastructure)                  │
├──────────────────────────────────────────────────────────────┤
│  ├─ MammothAdapter implementación                            │
│  ├─ Extracción de contenido + imágenes                       │
│  └─ Manejo de errores de parsing                             │
├──────────────────────────────────────────────────────────────┤
│ FASE 4: Vision Summary (Image Processing)                    │
├──────────────────────────────────────────────────────────────┤
│  ├─ ImageVisionService (wrapper ChatOpenAI)                  │
│  ├─ Batch processing (máx 5 imágenes)                        │
│  └─ Descripción de imágenes → contexto                       │
├──────────────────────────────────────────────────────────────┤
│ FASE 5: Integración en Workflow (Application)                │
├──────────────────────────────────────────────────────────────┤
│  ├─ Use case: parse_documents                                │
│  ├─ Coordinación parser + vision summary                     │
│  └─ Retorno de contenido enriquecido                         │
├──────────────────────────────────────────────────────────────┤
│ FASE 6: Validaciones y Seguridad (API)                       │
├──────────────────────────────────────────────────────────────┤
│  ├─ Validador de tipos/tamaño de archivos                    │
│  ├─ Límites de cantidad (archivos, imágenes)                 │
│  └─ Sanitización de nombres de archivo                       │
├──────────────────────────────────────────────────────────────┤
│ FASE 7: Testing (Unit + Integration)                         │
├──────────────────────────────────────────────────────────────┤
│  ├─ Tests de parsers (Mammoth)                               │
│  ├─ Tests de vision summary                                  │
│  ├─ Tests de validaciones                                    │
│  └─ Tests de integración end-to-end                          │
├──────────────────────────────────────────────────────────────┤
│ FASE 8: Documentación y Despliegue                            │
├──────────────────────────────────────────────────────────────┤
│  ├─ Actualizar backend_architecture.md                       │
│  ├─ Guía de API (request/response)                           │
│  ├─ Ejemplos de uso                                          │
│  └─ Deploy en ambientes (dev/test/prod)                      │
└──────────────────────────────────────────────────────────────┘
```

**Timeline estimado:** 8-10 semanas (estimado en sprints de 2 semanas)

---

## FASE 1: Preparación del Entorno

### Objetivo
Preparar el ambiente, instalar dependencias y establecer estructura base de directorios.

### Tareas

#### 1.1 Actualizar requirements.txt
**Dependencias a agregar:**
```
mammoth==1.4.28          # Parser DOCX → HTML/text
python-multipart==0.0.6  # FastAPI multipart/form-data
```

**Acción:**
- Agregar las dos dependencias a `requirements.txt`
- Ejecutar `pip install -r requirements.txt` en ambiente local
- Verificar que ambas librerías están disponibles sin conflictos

**Criterio de aceptación:**
- ✅ `mammoth` importable en Python
- ✅ `python-multipart` registro automático en FastAPI
- ✅ Sin conflictos de versiones con dependencias existentes

**Dependencias previas:** Ninguna
**Tiempo estimado:** 15 minutos

---

#### 1.2 Crear Estructura de Directorios
**Estructura a crear:**

```
src/
├─ domain/
│  └─ models/
│     └─ document_models.py          [NUEVO]
├─ application/
│  ├─ ports/
│  │  └─ document_parser_port.py     [NUEVO]
│  ├─ use_cases/
│  │  └─ parse_documents_use_case.py [NUEVO]
│  └─ dtos/
│     └─ document_dtos.py            [NUEVO]
└─ infrastructure/
   ├─ document_parsing/
   │  ├─ mammoth_adapter.py          [NUEVO]
   │  ├─ image_vision_service.py    [NUEVO]
   │  └─ __init__.py                 [NUEVO]
   └─ agents/                         [EXISTENTE - a actualizar]
```

**Acción:**
- Crear directorios si no existen
- Crear archivos `__init__.py` en cada módulo nuevo

**Criterio de aceptación:**
- ✅ Estructura completamente creada
- ✅ Python path resolver correctly los nuevos módulos
- ✅ `__init__.py` presentes en todos los directorios

**Dependencias previas:** Ninguna
**Tiempo estimado:** 10 minutos

---

#### 1.3 Análisis de Estructura Existente
**Acción:**
- Revisar `src/domain/models/` para entender patrón de schemas
- Revisar `src/application/ports/` para entender patrón de puertos
- Revisar `src/infrastructure/` para patrón de adaptadores
- Revisar `langgraph_functional_analysis_runner.py` para puntos de integración

**Criterio de aceptación:**
- ✅ Documentar patrones encontrados
- ✅ Identificar estilos de código/importes a mantener
- ✅ Localizados puntos de integración con workflow actual

**Dependencias previas:** Ninguna
**Tiempo estimado:** 30 minutos

---

### Resumen Fase 1
- **Duración:** ~1 día
- **Dependencias:** Ninguna
- **Entregables:** 
  - requirements.txt actualizado
  - Estructura de directorios creada
  - Documento de patrones/estilos identificados

---

## FASE 2: Componentes Base

### Objetivo
Crear los modelos de dominio, puertos abstractos y DTOs que definen la interfaz de parsing.

---

#### 2.1 Crear DocumentMetadata Schema
**Archivo:** `src/domain/models/document_models.py`

**Contenido:**
```python
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class DocumentMetadata:
    """Metadata extraída de un documento DOCX"""
    filename: str                    # Nombre original del archivo
    file_size_bytes: int            # Tamaño en bytes
    last_modified: Optional[datetime] # Fecha de última modificación
    author: Optional[str]            # Autor del documento
    num_images: int                  # Cantidad de imágenes extraídas
    content_hash: str               # Hash SHA-256 del contenido
    
@dataclass
class ExtractedImage:
    """Imagen extraída de un documento"""
    image_id: str                   # ID único (ej: "img_1")
    base64_data: str               # Datos de imagen en base64
    image_format: str              # "png", "jpg", "gif", etc.
    file_size_bytes: int           # Tamaño de imagen
    description: Optional[str]      # Descripción post Vision Summary

@dataclass
class ParsedDocument:
    """Documento parseado completo"""
    metadata: DocumentMetadata
    plain_text: str                # Contenido textual extraído
    html_content: str              # Contenido HTML (de Mammoth)
    images: list[ExtractedImage]   # Lista de imágenes extraídas
    extraction_timestamp: datetime  # Cuándo se extrajo
```

**Especificaciones:**
- Usar dataclass para inmutabilidad
- Seguir patrón de tipos del proyecto
- Incluir validaciones básicas de campos

**Criterio de aceptación:**
- ✅ Schema compila sin errores
- ✅ Importable desde aplicación
- ✅ Soporta serialización JSON

**Dependencias previas:** 1.2
**Tiempo estimado:** 1 hora

---

#### 2.2 Crear DocumentParser Port
**Archivo:** `src/application/ports/document_parser_port.py`

**Contenido:**
```python
from abc.ABC, abstractmethod
from typing import Optional
from pathlib import Path
from src.domain.models.document_models import ParsedDocument

class DocumentParserPort(ABC):
    """Puerto abstracto para parsers de documentos"""
    
    @abstractmethod
    async def parse_docx(self, file_path: str) -> ParsedDocument:
        """
        Parsea un archivo DOCX y extrae contenido + imágenes
        
        Args:
            file_path: Ruta al archivo .docx
            
        Returns:
            ParsedDocument con contenido, metadata, e imágenes
            
        Raises:
            FileNotFoundError: Si archivo no existe
            InvalidDocumentError: Si archivo no es DOCX válido
        """
        pass
    
    @abstractmethod
    async def validate_docx(self, file_path: str) -> bool:
        """Valida que el archivo sea DOCX válido sin parsearlo completo"""
        pass
```

**Especificaciones:**
- Interfaz abstracta (ABC)
- Métodos async
- Manejo de errores específicos

**Criterio de aceptación:**
- ✅ Puerto define contrato claro
- ✅ Exceptions específicas definidas
- ✅ Método async

**Dependencias previas:** 2.1
**Tiempo estimado:** 45 minutos

---

#### 2.3 Crear DTOs
**Archivo:** `src/application/dtos/document_dtos.py`

**Contenido:**
```python
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class ParsedDocumentDTO(BaseModel):
    """DTO para respuesta de parsing"""
    metadata: dict = Field(..., description="Metadatos del documento")
    plain_text: str = Field(..., description="Contenido textual")
    images_count: int = Field(..., ge=0, description="Cantidad de imágenes")
    images_descriptions: list[str] = Field(default_factory=list)
    extraction_timestamp: datetime
    
    class Config:
        json_schema_extra = {
            "example": {
                "metadata": {"filename": "spec.docx", "file_size_bytes": 102400},
                "plain_text": "Especificación funcional...",
                "images_count": 2,
                "images_descriptions": ["Mockup de login", "Diagrama de flujo"],
                "extraction_timestamp": "2026-07-01T10:30:00Z"
            }
        }
```

**Especificaciones:**
- Usar Pydantic para validación
- Incluir ejemplos de schema
- Compatible con FastAPI

**Criterio de aceptación:**
- ✅ Válido con Pydantic
- ✅ Serializable a JSON
- ✅ Documentado con ejemplos

**Dependencias previas:** 2.1
**Tiempo estimado:** 45 minutos

---

### Resumen Fase 2
- **Duración:** ~2-3 días
- **Dependencias:** Fase 1 completada
- **Entregables:** 
  - `document_models.py` (ParsedDocument, DocumentMetadata, ExtractedImage)
  - `document_parser_port.py` (puerto abstracto)
  - `document_dtos.py` (DTOs Pydantic)

---

## FASE 3: Integración Parser (Mammoth)

### Objetivo
Implementar el adaptador Mammoth para extraer contenido e imágenes de DOCX.

---

#### 3.1 Crear MammothAdapter
**Archivo:** `src/infrastructure/document_parsing/mammoth_adapter.py`

**Contenido clave:**
```python
import mammoth
import base64
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Optional
import asyncio
from src.domain.models.document_models import (
    ParsedDocument, DocumentMetadata, ExtractedImage
)
from src.application.ports.document_parser_port import DocumentParserPort

class MammothAdapter(DocumentParserPort):
    """Adaptador para parsear DOCX usando Mammoth"""
    
    async def parse_docx(self, file_path: str) -> ParsedDocument:
        """
        Parsea DOCX: extrae texto, HTML e imágenes
        
        Pasos:
        1. Validar archivo existe y es .docx
        2. Leer archivo
        3. Extraer contenido HTML con Mammoth
        4. Extraer imágenes en base64
        5. Construir ParsedDocument con metadata
        """
        # 1. Validaciones
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Archivo no encontrado: {file_path}")
        if path.suffix.lower() != ".docx":
            raise ValueError("Archivo debe ser .docx")
        
        # 2. Leer archivo
        with open(file_path, "rb") as f:
            docx_bytes = f.read()
        
        # 3. Extraer con Mammoth
        result = mammoth.convert_to_html(docx_bytes)
        html_content = result.value
        
        # 4. Extraer imágenes (Mammoth proporciona)
        images = await self._extract_images(docx_bytes, file_path)
        
        # 5. Construir metadata
        metadata = self._create_metadata(path, docx_bytes, len(images))
        
        # 6. Convertir HTML a plain text
        plain_text = self._html_to_plain_text(html_content)
        
        return ParsedDocument(
            metadata=metadata,
            plain_text=plain_text,
            html_content=html_content,
            images=images,
            extraction_timestamp=datetime.utcnow()
        )
    
    async def _extract_images(self, docx_bytes: bytes, file_path: str) -> list[ExtractedImage]:
        """Extrae imágenes en base64"""
        # Usar zipfile para acceder internos del DOCX
        import zipfile
        import xml.etree.ElementTree as ET
        
        images = []
        try:
            with zipfile.ZipFile(BytesIO(docx_bytes)) as zip_file:
                # Buscar imágenes en word/media/
                for name in zip_file.namelist():
                    if name.startswith("word/media/"):
                        image_data = zip_file.read(name)
                        # Determinar formato
                        ext = Path(name).suffix.lower().strip(".")
                        # Convertir a base64
                        b64 = base64.b64encode(image_data).decode("utf-8")
                        images.append(ExtractedImage(
                            image_id=f"img_{len(images)}",
                            base64_data=b64,
                            image_format=ext,
                            file_size_bytes=len(image_data),
                            description=None  # Se llena en Vision Summary
                        ))
        except Exception as e:
            # Log warning pero no bloquear
            pass
        
        return images
    
    def _create_metadata(self, path: Path, docx_bytes: bytes, num_images: int) -> DocumentMetadata:
        """Crea metadata del documento"""
        # Obtener propiedades del DOCX si existen
        author = None
        try:
            # Extraer del core.xml
            pass
        except:
            pass
        
        content_hash = hashlib.sha256(docx_bytes).hexdigest()
        
        return DocumentMetadata(
            filename=path.name,
            file_size_bytes=len(docx_bytes),
            last_modified=datetime.fromtimestamp(path.stat().st_mtime),
            author=author,
            num_images=num_images,
            content_hash=content_hash
        )
    
    def _html_to_plain_text(self, html: str) -> str:
        """Convierte HTML a texto plano"""
        from html.parser import HTMLParser
        
        class MLStripper(HTMLParser):
            def __init__(self):
                self.reset()
                self.strict = False
                self.convert_charrefs = True
                self.text = []
            
            def handle_data(self, d):
                self.text.append(d)
            
            def get_data(self):
                return "".join(self.text)
        
        stripper = MLStripper()
        stripper.feed(html)
        return stripper.get_data()
    
    async def validate_docx(self, file_path: str) -> bool:
        """Valida rápidamente si es DOCX válido"""
        try:
            path = Path(file_path)
            if not path.exists() or path.suffix.lower() != ".docx":
                return False
            
            # Intentar abrir como ZIP (DOCX es ZIP)
            import zipfile
            with zipfile.ZipFile(file_path, 'r') as z:
                # Verificar estructura DOCX
                required_files = ["word/document.xml", "[Content_Types].xml"]
                return all(f in z.namelist() for f in required_files)
        except:
            return False
```

**Especificaciones:**
- Usar Mammoth para extracción HTML
- Usar zipfile para acceder a imágenes internas
- Extraer metadata (nombre, tamaño, autor, hash)
- Convertir HTML a plain text
- Manejo graceful de errores

**Criterio de aceptación:**
- ✅ Parsea archivos DOCX válidos
- ✅ Extrae imágenes en base64
- ✅ Genera metadata correcta
- ✅ Plain text sin HTML
- ✅ Maneja errores sin crash

**Dependencias previas:** 2.1, 2.2, 1.1
**Tiempo estimado:** 3-4 horas

---

#### 3.2 Crear Validaciones de Archivo
**Archivo:** `src/infrastructure/document_parsing/validators.py` (NUEVO)

**Contenido:**
```python
from pathlib import Path
from typing import Tuple

class DocumentValidator:
    """Validador de archivos DOCX"""
    
    MAX_FILE_SIZE = 30 * 1024 * 1024  # 30 MB
    MAX_FILES_PER_REQUEST = 5
    MAX_IMAGES_PER_DOCUMENT = 10
    ALLOWED_MIMETYPES = [
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ]
    
    @staticmethod
    def validate_file(file_path: str, file_size: int) -> Tuple[bool, Optional[str]]:
        """
        Valida un archivo DOCX
        
        Returns:
            (válido, mensaje_error_o_none)
        """
        path = Path(file_path)
        
        # Validar extensión
        if path.suffix.lower() != ".docx":
            return False, "Archivo debe tener extensión .docx"
        
        # Validar tamaño
        if file_size > DocumentValidator.MAX_FILE_SIZE:
            return False, f"Archivo excede límite de {DocumentValidator.MAX_FILE_SIZE / 1024 / 1024:.0f} MB"
        
        # Validar mimetype
        # (En FastAPI, verificar en endpoint)
        
        return True, None
    
    @staticmethod
    def validate_images_count(images_count: int) -> Tuple[bool, Optional[str]]:
        """Valida cantidad de imágenes"""
        if images_count > DocumentValidator.MAX_IMAGES_PER_DOCUMENT:
            return False, f"Documento excede límite de {DocumentValidator.MAX_IMAGES_PER_DOCUMENT} imágenes"
        return True, None
```

**Criterio de aceptación:**
- ✅ Valida tipo DOCX
- ✅ Valida tamaño máximo (30 MB)
- ✅ Valida cantidad de imágenes
- ✅ Mensajes de error claros

**Dependencias previas:** 3.1
**Tiempo estimado:** 1 hora

---

### Resumen Fase 3
- **Duración:** ~1 semana
- **Dependencias:** Fase 2 completada
- **Entregables:** 
  - `mammoth_adapter.py` (adaptador de parsing)
  - `validators.py` (validación de archivos)
  - Tests unitarios para ambos

---

## FASE 4: Vision Summary

### Objetivo
Implementar servicio que procese imágenes extraídas usando GPT-4o vision en batch.

---

#### 4.1 Crear ImageVisionService
**Archivo:** `src/infrastructure/document_parsing/image_vision_service.py`

**Contenido clave:**
```python
from typing import Optional, List
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, ImageContent
import asyncio
import logging
from src.domain.models.document_models import ExtractedImage

logger = logging.getLogger(__name__)

class ImageVisionService:
    """Servicio para procesar imágenes con Vision Summary (GPT-4o vision)"""
    
    # Constantes
    MAX_IMAGES_PER_BATCH = 5
    VISION_MODEL = "gpt-4-vision-preview"  # o "gpt-4o"
    
    def __init__(self, openai_api_key: str):
        self.client = ChatOpenAI(
            model=self.VISION_MODEL,
            api_key=openai_api_key
        )
    
    async def describe_images(self, images: List[ExtractedImage]) -> List[ExtractedImage]:
        """
        Procesa imágenes en batch y genera descripciones
        
        Estrategia:
        1. Dividir en batches de máx 5 imágenes
        2. Para cada batch, invocar GPT-4o vision
        3. Asignar descripción a cada imagen
        4. Retornar imágenes con descriptions
        
        Args:
            images: Lista de ExtractedImage (sin description aún)
        
        Returns:
            Lista de ExtractedImage con descriptions asignadas
        """
        
        if not images:
            return images
        
        # Limitar a máximo 10 imágenes
        if len(images) > 10:
            logger.warning(f"Documento tiene {len(images)} imágenes, procesando solo 10")
            images = images[:10]
        
        # Procesar en batches
        batches = [
            images[i:i + self.MAX_IMAGES_PER_BATCH] 
            for i in range(0, len(images), self.MAX_IMAGES_PER_BATCH)
        ]
        
        described_images = []
        
        for batch_idx, batch in enumerate(batches):
            try:
                descriptions = await self._process_batch(batch)
                
                # Asignar descripciones a imágenes
                for img, desc in zip(batch, descriptions):
                    img.description = desc
                    described_images.extend(batch)
            
            except Exception as e:
                logger.error(f"Error procesando batch {batch_idx}: {e}")
                # Fallback: descripciones genéricas
                for img in batch:
                    img.description = f"[Imagen no procesada: {img.image_id}]"
                    described_images.extend(batch)
        
        return described_images
    
    async def _process_batch(self, images: List[ExtractedImage]) -> List[str]:
        """Procesa un batch de imágenes y retorna descripciones"""
        
        # Construir mensaje con imágenes
        messages = []
        
        # Mensaje inicial
        messages.append({
            "type": "text",
            "text": (
                "Por favor, describe detalladamente cada una de las siguientes imágenes. "
                "Incluye: layout, componentes visuales, flujos, textos visibles, anotaciones, "
                "colores dominantes y cualquier información arquitectónica o funcional relevante. "
                "Sé completo y detallado, ya que estas descripciones serán usadas para análisis funcional."
            )
        })
        
        # Agregar imágenes en base64
        for img in images:
            messages.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/{img.image_format};base64,{img.base64_data}"
                }
            })
        
        # Invocar GPT-4o
        response = await asyncio.to_thread(
            self.client.invoke,
            HumanMessage(content=messages)
        )
        
        # Parsear respuesta: esperamos descripciones separadas por imágenes
        # Aquí podría haber post-procesamiento para extraer descripciones individuales
        descriptions_text = response.content
        
        # Simple split: asumir que cada párrafo es una descripción
        descriptions = self._parse_descriptions(descriptions_text, len(images))
        
        return descriptions
    
    def _parse_descriptions(self, text: str, image_count: int) -> List[str]:
        """
        Parsea texto de respuesta en descripciones individuales
        
        Estrategia simple: dividir por párrafos/saltos de línea dobles
        """
        # Si es texto corto, asumir que es una única descripción
        if image_count == 1:
            return [text.strip()]
        
        # Dividir por párrafos
        paragraphs = text.split("\n\n")
        
