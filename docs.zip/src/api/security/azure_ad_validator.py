from __future__ import annotations

import logging
from typing import Any

import httpx
from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwk, jwt
from jose.utils import base64url_decode

from src.infrastructure.config.settings import Settings
from src.api.dependencies import get_settings

logger = logging.getLogger(__name__)

# HTTPBearer extrae el token del header Authorization: Bearer <token>
_bearer_scheme = HTTPBearer(auto_error=True)

# Cache simple de JWKS en memoria para evitar requests repetidos
_jwks_cache: dict[str, Any] = {}


def _fetch_jwks(jwks_uri: str) -> dict[str, Any]:
    """Obtiene las claves públicas del JWKS endpoint de Azure AD."""
    if jwks_uri in _jwks_cache:
        return _jwks_cache[jwks_uri]

    try:
        response = httpx.get(jwks_uri, timeout=10.0)
        response.raise_for_status()
        jwks = response.json()
        _jwks_cache[jwks_uri] = jwks
        return jwks
    except httpx.HTTPError as exc:
        logger.error("Error al obtener JWKS desde %s: %s", jwks_uri, exc)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="No se pudo contactar al servidor de autenticación.",
        ) from exc


def _get_signing_key(token: str, jwks_uri: str) -> Any:
    """Obtiene la clave de firma correspondiente al kid del token."""
    try:
        unverified_header = jwt.get_unverified_header(token)
    except JWTError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token mal formado: no se pudo leer el encabezado JWT.",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc

    kid = unverified_header.get("kid")
    if not kid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido: falta el campo 'kid' en el encabezado.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    jwks = _fetch_jwks(jwks_uri)

    for key_data in jwks.get("keys", []):
        if key_data.get("kid") == kid:
            # Microsoft's JWKS endpoint omits the 'alg' field; pass it explicitly
            # so python-jose can identify the RSA algorithm correctly.
            return jwk.construct(key_data, algorithm="RS256")

    # Kid no encontrado: limpiar cache y reintentar una vez
    _jwks_cache.pop(jwks_uri, None)
    jwks = _fetch_jwks(jwks_uri)
    for key_data in jwks.get("keys", []):
        if key_data.get("kid") == kid:
            return jwk.construct(key_data, algorithm="RS256")

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Token inválido: clave de firma no encontrada.",
        headers={"WWW-Authenticate": "Bearer"},
    )


def validate_azure_ad_token(
    credentials: HTTPAuthorizationCredentials = Security(_bearer_scheme),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Dependencia de FastAPI que valida el token portador de Azure AD.

    Extrae el token del header Authorization, valida la firma contra el
    JWKS endpoint del inquilino y verifica los reclamos: audiencia, emisor y
    caducidad.

    Retorna el payload del token si es válido.
    Lanza HTTPException 401 si el token está inválido, caducado o ausente.
    """
    token = credentials.credentials

    signing_key = _get_signing_key(token, settings.azure_jwks_uri)

    try:
        payload = jwt.decode(
            token,
            signing_key,
            algorithms=["RS256"],
            audience=settings.azure_audience,
            issuer=settings.azure_issuer,
            options={
                "verify_exp": True,
                "verify_aud": True,
                "verify_iss": True,
            },
        )
    except JWTError as exc:
        error_msg = str(exc).lower()
        if "expired" in error_msg:
            detail = "Token expirado."
        elif "audience" in error_msg:
            detail = "Token inválido: audience incorrecto."
        elif "issuer" in error_msg:
            detail = "Token inválido: issuer incorrecto."
        else:
            detail = f"Token inválido: {exc}"

        logger.warning("Token JWT rechazado: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=detail,
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc

    return payload
