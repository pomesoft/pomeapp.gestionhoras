from __future__ import annotations

from functools import lru_cache

from src.application.ports.document_text_extractor import DocumentTextExtractor
from src.application.use_cases.analyze_functional_requirement import (
    AnalyzeFunctionalRequirementUseCase,
)
from src.infrastructure.agents.langgraph_functional_analysis_runner import (
    LangGraphFunctionalAnalysisRunner,
)
from src.infrastructure.config.settings import Settings
from src.infrastructure.documents.document_text_extractor import (
    document_text_extractor as _document_text_extractor_singleton,
)


@lru_cache
def get_settings() -> Settings:
    return Settings()


def get_analyze_use_case() -> AnalyzeFunctionalRequirementUseCase:
    return AnalyzeFunctionalRequirementUseCase(
        agent_runner=LangGraphFunctionalAnalysisRunner(get_settings())
    )


def get_document_text_extractor() -> DocumentTextExtractor:
    """Return the shared ConcreteDocumentTextExtractor singleton."""
    return _document_text_extractor_singleton
