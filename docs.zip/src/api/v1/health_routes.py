from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from src.api.dependencies import get_settings
from src.domain.models.schemas import HealthResponse, ReadyResponse
from src.infrastructure.config.settings import Settings
from src.infrastructure.llm.openai_provider import OpenAiProvider


router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(status="ok")


@router.get("/ready", response_model=ReadyResponse)
def ready(settings: Settings = Depends(get_settings)) -> ReadyResponse:
    provider = OpenAiProvider(settings)
    if not provider.is_configured():
        raise HTTPException(status_code=503, detail="Configuracion LLM incompleta.")
    return ReadyResponse(
        status="ready",
        llm_provider=settings.llm_provider,
        llm_model=settings.llm_model,
    )
