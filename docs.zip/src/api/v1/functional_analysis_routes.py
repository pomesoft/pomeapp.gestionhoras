from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile

from src.domain.models.schemas import (
    AnalyzeOptions,
    DiagnosticsResponse,
    FunctionalAnalysisApiResponse,
    FunctionalAnalysisRequest,
    FunctionalAnalysisResponseModel,
    empty_analysis,
)
from src.application.use_cases.analyze_functional_requirement import (
    AnalyzeFunctionalRequirementUseCase,
)
from src.application.ports.document_text_extractor import DocumentTextExtractor
from src.application.services.specification_consolidator import consolidate_specification
from src.api.dependencies import get_analyze_use_case, get_document_text_extractor
from src.api.security.azure_ad_validator import validate_azure_ad_token
from src.domain.errors import (
    AgentTimeoutError,
    ConfigurationError,
    InvalidSpecificationError,
    ProviderUnavailableError,
)

from src.infrastructure.config.settings import ConfigError, Settings
from src.infrastructure.observability import AzureMonitorTelemetryLogger


logger = logging.getLogger(__name__)
telemetry_logger = AzureMonitorTelemetryLogger(Settings())
telemetry_logger.configure()


router = APIRouter(prefix="/api/v1", tags=["functional-analysis"])


@router.post(
    "/functional-analysis",
    response_model=FunctionalAnalysisApiResponse,
    responses={
        400: {"description": "Especificacion vacia o invalida."},
        401: {"description": "Acceso no autorizado. Se requiere Bearer token válido de Azure AD."},
        503: {"description": "Configuracion LLM ausente o proveedor no disponible."},
        504: {"description": "Timeout del LLM o workflow."},
    },
)
def analyze_functional_requirement(
    request: FunctionalAnalysisRequest,
    use_case: AnalyzeFunctionalRequirementUseCase = Depends(get_analyze_use_case),
    _token_payload: dict[str, Any] = Depends(validate_azure_ad_token),
) -> FunctionalAnalysisApiResponse:

    ticket_id = f"AF-{uuid.uuid4().hex[:6].upper()}"

    if request.specification in ("", "string"):
        requested_detail = (
            "La especificacion funcional requiere mayor detalle para realizar el analisis."
        )

        dataReturn = FunctionalAnalysisApiResponse(
            ticket_id=ticket_id,
            needs_complete_specification=True,
            requested_detail=requested_detail,
            analysis=FunctionalAnalysisResponseModel.model_validate(empty_analysis()),
            diagnostics=DiagnosticsResponse(parse_method="specification_evaluation"),
        )

        inputBody:dict[str, object] = {
                    "specification_length":len(request.specification or ""),
                    "skip_previous_evaluation": request.skip_previous_evaluation,
                }
        
        outputBody:dict[str, object] = {
                    "needs_complete_specification":dataReturn.needs_complete_specification,
                    "requested_detail":dataReturn.requested_detail,
                    "analysis":dataReturn.analysis,
                }

        diagnostics: dict[str, object] = {
                "workflow": dataReturn.diagnostics.workflow, 
                "model": dataReturn.diagnostics.model, 
                "parse_method": dataReturn.diagnostics.parse_method, 
                "trace": dataReturn.diagnostics.trace, 
            }
                
        telemetry_logger.trackTrace(
            ticket_id, "analyze_functional_requirement_api", "Ejecucion API de analisis funcional.",inputBody, outputBody, diagnostics, "OK" )

        telemetry_logger.trackTraceKPI(
            ticket_id=ticket_id,
            specification_lenght=len(request.specification or ""),
            skip_previous_evaluation=request.skip_previous_evaluation,
            needs_complete_specification=dataReturn.needs_complete_specification,
            analysis_lenght=len(dataReturn.analysis.functional_summary, ""),
            detected_task=len(dataReturn.analysis.detected_tasks),
            response_time=10,
            model=dataReturn.diagnostics.model,
            input_tokens=10,
            output_tokens=30
        )

        return dataReturn

    try:
        result = use_case.execute(
            specification=request.specification,
            options=AnalyzeOptions(
                skip_previous_evaluation=request.skip_previous_evaluation,
            ),
        )
    except InvalidSpecificationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except (ConfigurationError, ProviderUnavailableError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except AgentTimeoutError as exc:
        raise HTTPException(status_code=504, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Error inesperado ejecutando el agente.") from exc

    diagnostics = DiagnosticsResponse(
        workflow=result.diagnostics.workflow,
        model=result.diagnostics.model,
        parse_method=result.diagnostics.parse_method,
        trace=result.diagnostics.trace,
    )

    evaluation = result.evaluation or {}
    needs_complete_specification = bool(
        evaluation.get("needs_complete_specification", False)
    )
    requested_detail = (
        str(evaluation.get("requested_detail", ""))
        if needs_complete_specification
        else ""
    )
    analysis_response = FunctionalAnalysisResponseModel.model_validate(result.analysis)


    dataReturn=FunctionalAnalysisApiResponse(
        needs_complete_specification=needs_complete_specification,
        requested_detail=requested_detail,
        analysis=analysis_response,
        diagnostics=diagnostics,
    )

    inputBody:dict[str, object] = {
            "specification_length":len(request.specification or ""),
            "skip_previous_evaluation": request.skip_previous_evaluation,
        }
            
    outputBody:dict[str, object] = {
            "needs_complete_specification":dataReturn.needs_complete_specification,
            "requested_detail_length":dataReturn.requested_detail,
            "analysis":dataReturn.analysis.functional_summary,
        }
    
    diagnostics: dict[str, object] = {
        "workflow": dataReturn.diagnostics.workflow, 
        "model": dataReturn.diagnostics.model, 
        "parse_method": dataReturn.diagnostics.parse_method, 
        "trace": dataReturn.diagnostics.trace, 
    }

    telemetry_logger.trackTrace(
        "ticket_id", 
        "analyze_functional_requirement_api", 
        "Ejecucion API de analisis funcional.",
        inputBody, 
        outputBody, 
        diagnostics,
        "OK"  )

    telemetry_logger.trackTraceKPI(
        ticket_id=ticket_id,
        specification_lenght=len(request.specification or ""),
        skip_previous_evaluation=request.skip_previous_evaluation,
        needs_complete_specification=dataReturn.needs_complete_specification,
        analysis_lenght=len(dataReturn.analysis.functional_summary or ""),
        detected_task=len(dataReturn.analysis.detected_tasks),
        response_time=10,
        model=dataReturn.diagnostics.model,
        input_tokens=10,
        output_tokens=30
    )
    
    return dataReturn


def _build_api_response(result: Any) -> FunctionalAnalysisApiResponse:
    """Shared helper: build the API response from a use-case result."""
    diagnostics = DiagnosticsResponse(
        workflow=result.diagnostics.workflow,
        model=result.diagnostics.model,
        parse_method=result.diagnostics.parse_method,
        trace=result.diagnostics.trace,
    )
    evaluation = result.evaluation or {}
    needs_complete_specification = bool(
        evaluation.get("needs_complete_specification", False)
    )
    requested_detail = (
        str(evaluation.get("requested_detail", ""))
        if needs_complete_specification
        else ""
    )
    analysis_response = FunctionalAnalysisResponseModel.model_validate(result.analysis)
    return FunctionalAnalysisApiResponse(
        needs_complete_specification=needs_complete_specification,
        requested_detail=requested_detail,
        analysis=analysis_response,
        diagnostics=diagnostics,
    )


@router.post(
    "/functional-analysis/upload",
    response_model=FunctionalAnalysisApiResponse,
    responses={
        400: {"description": "Sin contenido válido: se requiere texto o al menos un archivo."},
        401: {"description": "Acceso no autorizado. Se requiere Bearer token válido de Azure AD."},
        503: {"description": "Configuracion LLM ausente o proveedor no disponible."},
        504: {"description": "Timeout del LLM o workflow."},
    },
)
async def upload_and_analyze(
    specification: str | None = Form(
        default=None,
        description="Texto libre con la especificación funcional (opcional).",
    ),
    skip_previous_evaluation: bool | None = Form(
        default=False,
        description="Omite la evaluación previa de completitud.",
    ),
    files: list[UploadFile] = File(
        default_factory=list,
        description="Archivos adjuntos (.txt, .pdf, .docx).",
    ),
    use_case: AnalyzeFunctionalRequirementUseCase = Depends(get_analyze_use_case),
    extractor: DocumentTextExtractor = Depends(get_document_text_extractor),
    _token_payload: dict[str, Any] = Depends(validate_azure_ad_token),
) -> FunctionalAnalysisApiResponse:
    """Multipart endpoint: acepta texto libre opcional y archivos subidos.

    Extrae el texto de cada archivo, lo consolida todo en una única
    cadena de especificación y, a continuación, lo delega al mismo caso de uso de análisis que utiliza
    el punto final JSON. Formatos compatibles: .txt, .pdf, .docx.
    """
    # ------------------------------------------------------------------
    # 1. Extract text from every uploaded file
    # ------------------------------------------------------------------
    extraction_results = []
    for upload in files:
        safe_filename = upload.filename or "archivo_sin_nombre"
        content = await upload.read()
        result = extractor.extract(filename=safe_filename, content=content)
        extraction_results.append(result)
        if not result.success:
            logger.warning(
                "Extracción fallida para '%s': %s", safe_filename, result.error_message
            )

    # ------------------------------------------------------------------
    # 2. Consolidate manual text + extracted content
    # ------------------------------------------------------------------
    consolidation = consolidate_specification(
        manual_text=specification,
        extraction_results=extraction_results,
    )

    # ------------------------------------------------------------------
    # 3. Validate that we have something to analyse
    # ------------------------------------------------------------------
    if not consolidation.has_content:
        failed_details = "; ".join(
            f"'{fn}': {err}" for fn, err in consolidation.failed_files
        )
        detail = (
            "Se requiere al menos texto manual o un archivo válido con contenido extraíble."
        )
        if failed_details:
            detail += f" Errores de extracción: {failed_details}"
        raise HTTPException(status_code=400, detail=detail)

    # ------------------------------------------------------------------
    # 4. Log warnings about failed files but continue with what we have
    # ------------------------------------------------------------------
    if consolidation.failed_files:
        logger.warning(
            "Se omitieron %d archivo(s) por errores de extracción: %s",
            len(consolidation.failed_files),
            [fn for fn, _ in consolidation.failed_files],
        )

    # ------------------------------------------------------------------
    # 5. Delegate to use case
    # ------------------------------------------------------------------
    final_spec = consolidation.specification

    if final_spec in ("", "string"):
        requested_detail = (
            "La especificacion funcional requiere mayor detalle para realizar el analisis."
        )
        return FunctionalAnalysisApiResponse(
            needs_complete_specification=True,
            requested_detail=requested_detail,
            analysis=FunctionalAnalysisResponseModel.model_validate(empty_analysis()),
            diagnostics=DiagnosticsResponse(parse_method="specification_evaluation"),
        )

    ticket_id = f"AF-{uuid.uuid4().hex[:6].upper()}"

    try:
        
        result = use_case.execute(
            specification=final_spec,
            options=AnalyzeOptions(
                skip_previous_evaluation=skip_previous_evaluation,
            ),
        )
        
    except InvalidSpecificationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except (ConfigurationError, ProviderUnavailableError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except AgentTimeoutError as exc:
        raise HTTPException(status_code=504, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500, detail="Error inesperado ejecutando el agente."
        ) from exc

    data_response=_build_api_response(result)


    telemetry_logger.trackTraceKPI(
        ticket_id=ticket_id,
        specification_lenght=len(final_spec or ""),
        skip_previous_evaluation=skip_previous_evaluation,
        needs_complete_specification=data_response.needs_complete_specification,
        analysis_lenght=len(data_response.analysis.functional_summary or ""),
        detected_task=len(data_response.analysis.detected_tasks),
        response_time=10,
        model=data_response.diagnostics.model,
        input_tokens=10,
        output_tokens=30
    )

    return data_response
