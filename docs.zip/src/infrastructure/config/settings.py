from __future__ import annotations

from pathlib import Path

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


BASE_DIR = Path(__file__).resolve().parents[3]
CHECKPOINT_DB_PATH = BASE_DIR / "nexplan_workflow_analisis.db"


class ConfigError(RuntimeError):
    pass


class Settings(BaseSettings):
    app_name: str = "Nexplan Functional Analysis API"
    app_environment: str = Field(default="development", validation_alias="APP_ENVIRONMENT")
    llm_provider: str = "openai"
    llm_model: str = Field(default="gpt-4.1", validation_alias="LLM_MODEL")
    llm_base_url: str = Field(
        default="https://foundrymobile.services.ai.azure.com/openai/v1/",
        validation_alias=AliasChoices("LLM_BASE_URL", "BASE_URL_LLM"),
    )
    llm_api_key: str = Field(
        default="",
        repr=False,
        validation_alias=AliasChoices("LLM_API_KEY", "API_KEY_LLM"),
    )
    llm_verify_tls: bool = Field(default=True, validation_alias="LLM_VERIFY_TLS")
    llm_timeout_seconds: float = Field(default=60, validation_alias="LLM_TIMEOUT_SECONDS")

    # Azure AD / OAuth2 configuration
    azure_instance: str = Field(
        default="https://login.microsoftonline.com/",
        validation_alias="AZURE_INSTANCE",
    )
    azure_tenant_id: str = Field(
        default="",
        validation_alias="AZURE_TENANT_ID",
    )
    azure_client_id: str = Field(
        default="",
        validation_alias="AZURE_CLIENT_ID",
    )
    azure_client_secret: str = Field(
        default="",
        repr=False,
        validation_alias="AZURE_CLIENT_SECRET",
    )
    azure_audience: str = Field(
        default="",
        validation_alias="AZURE_AUDIENCE",
    )
    applicationinsights_connection_string: str = Field(
        default="",
        validation_alias="APPLICATIONINSIGHTS_CONNECTION_STRING",
    )
    otel_service_name: str = Field(
        default="",
        validation_alias="OTEL_SERVICE_NAME",
    )
    telemetry_logger_name: str = Field(
        default="",
        validation_alias="TELEMETRY_LOGGER_NAME",
    )
    telemetry_logger_name_kpi: str = Field(
            default="",
            validation_alias="TELEMETRY_LOGGER_NAME_KPI",
        )
    telemetry_live_metrics_enabled: str = Field(
        default="",
        validation_alias="TELEMETRY_LIVE_METRICS_ENABLED",
    )

    # Document upload configuration
    max_file_size_mb: float = Field(
        default=10.0,
        validation_alias="MAX_FILE_SIZE_MB",
        description="Maximum allowed size per uploaded file, in megabytes.",
    )

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    @property
    def is_llm_configured(self) -> bool:
        return bool(self.llm_api_key.strip() and self.llm_model.strip())

    @property
    def is_azure_ad_configured(self) -> bool:
        return bool(
            self.azure_tenant_id.strip()
            and self.azure_client_id.strip()
            and self.azure_audience.strip()
        )

    @property
    def is_telemetry_configured(self) -> bool:
        return bool(self.applicationinsights_connection_string.strip())

    @property
    def azure_jwks_uri(self) -> str:
        return (
            f"{self.azure_instance.rstrip('/')}/{self.azure_tenant_id}"
            "/discovery/v2.0/keys"
        )

    @property
    def azure_issuer(self) -> str:
        return (
            f"{self.azure_instance.rstrip('/')}/{self.azure_tenant_id}/v2.0"
        )


def get_settings() -> Settings:
    return Settings()


def validar_configuracion(settings: Settings | None = None) -> None:
    current_settings = settings or get_settings()
    if not current_settings.llm_api_key.strip():
        raise ConfigError("Falta configurar API_KEY_LLM o LLM_API_KEY como variable de entorno.")


_settings = get_settings()
LLM_MODEL = _settings.llm_model
BASE_URL_LLM = _settings.llm_base_url
API_KEY_LLM = _settings.llm_api_key
VERIFY_TLS = _settings.llm_verify_tls
