"""Document parsing adapters and services."""
