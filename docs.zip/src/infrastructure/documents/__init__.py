# Infrastructure: document text extraction
