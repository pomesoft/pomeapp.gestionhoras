"""
Infrastructure implementation of DocumentTextExtractor port.

Supports .txt, .pdf and .docx formats.
Does NOT persist files to disk; all processing is done in memory.
"""
from __future__ import annotations

import io
import logging
from pathlib import PurePosixPath, PureWindowsPath

from src.application.ports.document_text_extractor import (
    DocumentTextExtractor,
    FileExtractionResult,
)
from src.infrastructure.config.settings import get_settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_BYTES_PER_MB = 1024 * 1024

ALLOWED_EXTENSIONS: frozenset[str] = frozenset({".txt", ".pdf", ".docx"})


def _get_max_file_size_bytes() -> int:
    """Read MAX_FILE_SIZE_MB from Settings (env-backed), fall back to 10 MB."""
    try:
        mb = get_settings().max_file_size_mb
        return int(mb * _BYTES_PER_MB)
    except Exception:  # noqa: BLE001
        return int(10 * _BYTES_PER_MB)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_extension(filename: str) -> str:
    """Return the lower-cased extension (e.g. '.pdf') from a filename string.

    Handles both POSIX and Windows path separators to avoid directory
    traversal issues when the client sends a full path as the filename.
    """
    # Strip any directory components – only keep the base name
    safe_name = PurePosixPath(filename).name
    safe_name = PureWindowsPath(safe_name).name
    return PurePosixPath(safe_name).suffix.lower()


# ---------------------------------------------------------------------------
# Format-specific extractors
# ---------------------------------------------------------------------------


def _extract_txt(content: bytes, filename: str) -> str:
    """Decode TXT bytes trying UTF-8 then latin-1 as fallback."""
    try:
        return content.decode("utf-8")
    except UnicodeDecodeError:
        try:
            return content.decode("latin-1")
        except UnicodeDecodeError as exc:
            raise ValueError(
                f"No se pudo decodificar '{filename}' como texto (UTF-8 ni latin-1)."
            ) from exc


def _extract_pdf(content: bytes, filename: str) -> str:
    """Extract text from PDF bytes using pypdf."""
    try:
        import pypdf  # lazy import – only required when processing PDFs
    except ImportError as exc:
        raise ImportError(
            "pypdf no está instalado. Ejecute: pip install pypdf"
        ) from exc

    reader = pypdf.PdfReader(io.BytesIO(content))
    if reader.is_encrypted:
        raise ValueError(
            f"El archivo '{filename}' está cifrado y no puede ser procesado."
        )

    pages: list[str] = []
    for page_num, page in enumerate(reader.pages, start=1):
        try:
            page_text = page.extract_text() or ""
            pages.append(page_text)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "No se pudo extraer texto de la página %d de '%s': %s",
                page_num,
                filename,
                exc,
            )
    return "\n".join(pages)


def _extract_docx(content: bytes, filename: str) -> str:
    """Extract text from DOCX bytes using python-docx."""
    try:
        import docx  # lazy import – only required when processing DOCX files
    except ImportError as exc:
        raise ImportError(
            "python-docx no está instalado. Ejecute: pip install python-docx"
        ) from exc

    document = docx.Document(io.BytesIO(content))
    paragraphs = [para.text for para in document.paragraphs]
    return "\n".join(paragraphs)


# ---------------------------------------------------------------------------
# Public implementation
# ---------------------------------------------------------------------------


class ConcreteDocumentTextExtractor:
    """Concrete implementation of the DocumentTextExtractor port.

    Validates file size and extension before attempting extraction.
    Returns a structured FileExtractionResult instead of raising exceptions,
    so callers can handle per-file errors gracefully.
    """

    def extract(self, filename: str, content: bytes) -> FileExtractionResult:
        """Extract text from *content* bytes, using *filename* to detect format.

        Returns:
            FileExtractionResult with `success=True` and the extracted text,
            or `success=False` and a descriptive `error_message`.
        """
        # ------------------------------------------------------------------
        # 1. Reject empty files
        # ------------------------------------------------------------------
        if not content:
            return FileExtractionResult(
                filename=filename,
                text="",
                success=False,
                error_message=f"El archivo '{filename}' está vacío.",
            )

        # ------------------------------------------------------------------
        # 2. Enforce maximum file size
        # ------------------------------------------------------------------
        max_bytes = _get_max_file_size_bytes()
        if len(content) > max_bytes:
            max_mb = max_bytes / _BYTES_PER_MB
            return FileExtractionResult(
                filename=filename,
                text="",
                success=False,
                error_message=(
                    f"El archivo '{filename}' supera el tamaño máximo permitido "
                    f"de {max_mb:.1f} MB."
                ),
            )

        # ------------------------------------------------------------------
        # 3. Validate extension
        # ------------------------------------------------------------------
        extension = _safe_extension(filename)
        if extension not in ALLOWED_EXTENSIONS:
            return FileExtractionResult(
                filename=filename,
                text="",
                success=False,
                error_message=(
                    f"El formato '{extension or '(sin extensión)'}' del archivo "
                    f"'{filename}' no está soportado. "
                    f"Formatos permitidos: {', '.join(sorted(ALLOWED_EXTENSIONS))}."
                ),
            )

        # ------------------------------------------------------------------
        # 4. Extract text according to format
        # ------------------------------------------------------------------
        try:
            if extension == ".txt":
                text = _extract_txt(content, filename)
            elif extension == ".pdf":
                text = _extract_pdf(content, filename)
            elif extension == ".docx":
                text = _extract_docx(content, filename)
            else:
                # Should never reach here due to the check above
                return FileExtractionResult(
                    filename=filename,
                    text="",
                    success=False,
                    error_message=f"Formato no soportado: '{extension}'.",
                )
        except (ImportError, ValueError) as exc:
            logger.warning("Extracción fallida para '%s': %s", filename, exc)
            return FileExtractionResult(
                filename=filename,
                text="",
                success=False,
                error_message=str(exc),
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("Error inesperado extrayendo texto de '%s'", filename)
            return FileExtractionResult(
                filename=filename,
                text="",
                success=False,
                error_message=(
                    f"Error inesperado al procesar '{filename}': {exc}"
                ),
            )

        # ------------------------------------------------------------------
        # 5. Warn if extracted text is empty but file had content
        # ------------------------------------------------------------------
        stripped = text.strip()
        if not stripped:
            logger.warning(
                "El archivo '%s' fue procesado pero no se pudo extraer texto legible.",
                filename,
            )
            return FileExtractionResult(
                filename=filename,
                text="",
                success=False,
                error_message=(
                    f"El archivo '{filename}' fue procesado pero no contiene "
                    "texto extraíble (puede ser una imagen o estar en blanco)."
                ),
            )

        return FileExtractionResult(
            filename=filename,
            text=stripped,
            success=True,
        )


# Convenience singleton – callers can import this directly
document_text_extractor = ConcreteDocumentTextExtractor()
