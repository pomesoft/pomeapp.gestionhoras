from __future__ import annotations

from src.infrastructure.config.settings import Settings


class OpenAiProvider:
    def __init__(self, settings: Settings):
        self._settings = settings

    @property
    def model(self) -> str:
        return self._settings.llm_model

    def is_configured(self) -> bool:
        return (
            self._settings.llm_provider.lower() == "openai"
            and self._settings.is_llm_configured
        )
