from __future__ import annotations

from src.infrastructure.observability.azure_monitor import AzureMonitorTelemetryLogger

__all__ = ["AzureMonitorTelemetryLogger"]
