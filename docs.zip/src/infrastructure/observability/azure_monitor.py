from __future__ import annotations

import logging
import os
from threading import Lock
from typing import Any

from src.infrastructure.config.settings import Settings


class AzureMonitorTelemetryLogger:
    _lock = Lock()
    _configured = False

    def __init__(self, settings: Settings):
        self._settings = settings
        self._logger = logging.getLogger(settings.telemetry_logger_name)
        self._logger.setLevel(logging.INFO)

    def configure(self) -> None:
        logging.basicConfig(level=logging.INFO)

        with self._lock:
            if self.__class__._configured:
                return

            connection_string = self._settings.applicationinsights_connection_string.strip()
            if not connection_string:
                self._logger.info(
                    "Azure Monitor OpenTelemetry deshabilitado: falta APPLICATIONINSIGHTS_CONNECTION_STRING."
                )
                return

            if self._settings.otel_service_name.strip():
                os.environ.setdefault(
                    "OTEL_SERVICE_NAME",
                    self._settings.otel_service_name.strip(),
                )

            try:
                from azure.monitor.opentelemetry import configure_azure_monitor
            except ImportError:
                self._logger.exception(
                    "No se pudo configurar Azure Monitor OpenTelemetry: falta azure-monitor-opentelemetry."
                )
                return

            try:
                configure_azure_monitor(
                    connection_string=connection_string,
                    logger_name=self._settings.telemetry_logger_name,
                    enable_live_metrics=self._settings.telemetry_live_metrics_enabled,
                )
            except Exception as exc:
                self.exception(
                    "No se pudo configurar Azure Monitor OpenTelemetry.",
                    exc,
                    environment=self._settings.app_environment,
                )
                return

            self.__class__._configured = True
            self._logger.info(
                "Azure Monitor OpenTelemetry configurado.",
                extra=self._extra(
                    {
                        "service_name": self._settings.otel_service_name,
                        "environment": self._settings.app_environment,
                    }
                ),
            )

    def info(self, message: str, **custom_dimensions: object) -> None:

        self._logger.info(
            message,
            extra=self._extra(custom_dimensions),
            stacklevel=2,
        )

    def trackTrace(
            self, 
            ticket_id: str, 
            inputPath: str, 
            messagePath: str,
            inputBody: object,
            outputBody: object,
            diagnostics: object,
            statusCode:str ) -> None:

        data_track:dict[str, object] = {
            "ticket_id": ticket_id,
            "inputPath": inputPath,
            "messagePath": messagePath,
            "inputBody": self._extra(inputBody),
            "outputBody": self._extra(outputBody),
            "diagnostics": self._extra(diagnostics),
            "statusCode": statusCode,
        }
         
        self._logger.info(
            self._settings.telemetry_logger_name,
            extra=data_track,
            stacklevel=2,
        )

    def trackTraceKPI(
                self, 
                ticket_id: str, 
                specification_lenght: int, 
                skip_previous_evaluation: bool,
                needs_complete_specification: bool, 
                analysis_lenght: int, 
                detected_task: int, 
                response_time: int,
                model: str,
                input_tokens: int,
                output_tokens: int,
            ) -> None:
    
            data_track:dict[str, object] = {
                "ticket_id": ticket_id,
                "specification_lenght": specification_lenght,
                "skip_previous_evaluation": skip_previous_evaluation,
                "needs_complete_specification": needs_complete_specification,
                "analysis_lenght": analysis_lenght,
                "detected_task": detected_task,
                "response_time": response_time,
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": input_tokens+output_tokens,
            }

            print(f"trackTraceKPI \n{data_track}\n")
             
            self._logger.info(
                self._settings.telemetry_logger_name_kpi,
                extra=data_track,
                stacklevel=2,
            )


    def exception(
        self,
        message: str,
        exception: BaseException | None = None,
        **custom_dimensions: object,
    ) -> None:
        exc_info: bool | tuple[type[BaseException], BaseException, Any] = True
        if exception is not None:
            exc_info = (type(exception), exception, exception.__traceback__)

        self._logger.exception(
            message,
            exc_info=exc_info,
            extra=self._extra(
                {
                    **custom_dimensions,
                    "error_type": type(exception).__name__ if exception else "",
                }
            ),
            stacklevel=2,
        )

    @staticmethod
    def _extra(custom_dimensions: dict[str, object]) -> dict[str, dict[str, object]]:
        clean_dimensions = {
            key: value
            for key, value in custom_dimensions.items()
            if value is not None and value != ""
        }
        return clean_dimensions
