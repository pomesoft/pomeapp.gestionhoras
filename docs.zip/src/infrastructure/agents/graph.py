from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime
from operator import add
from typing import Annotated, Any, Dict, List, TypedDict

import httpx
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph

from src.domain.models.schemas import (
    FunctionalAnalysisSchema,
    SpecificationEvaluationSchema,
    empty_analysis,
    incomplete_evaluation,
    sufficient_evaluation,
)
from src.infrastructure.agents.prompts import (
    get_functional_analysis_prompt,
    get_specification_evaluation_prompt,
)
from src.infrastructure.config.settings import (
    API_KEY_LLM,
    BASE_URL_LLM,
    CHECKPOINT_DB_PATH,
    LLM_MODEL,
    VERIFY_TLS,
    validar_configuracion,
)


class FunctionalAnalysisWorkflowState(TypedDict):
    functional_specification: str
    skip_previous_functional_analysis_evaluation: bool
    specification_evaluation: Dict[str, Any]
    functional_analysis: Dict[str, Any]
    diagnostics: Dict[str, Any]
    history: Annotated[List[str], add]


class FunctionalAnalysisWorkflow:
    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
        verify_tls: bool | None = None,
        timeout_seconds: float | None = None,
    ):
        self.api_key = API_KEY_LLM if api_key is None else api_key
        self.base_url = BASE_URL_LLM if base_url is None else base_url
        self.model = LLM_MODEL if model is None else model
        self.verify_tls = VERIFY_TLS if verify_tls is None else verify_tls
        self.timeout_seconds = timeout_seconds

        if api_key is None:
            validar_configuracion()
        elif not self.api_key:
            raise ValueError("Missing API_KEY_LLM or LLM_API_KEY environment variable.")

        http_client = httpx.Client(
            verify=self.verify_tls,
            timeout=self.timeout_seconds if self.timeout_seconds else None,
        )

        self.llm = ChatOpenAI(
            model=self.model,
            base_url=self.base_url,
            api_key=self.api_key,
            http_client=http_client,
            temperature=0,
            use_responses_api=True,
        )
        try:
            self.structured_llm = self.llm.with_structured_output(FunctionalAnalysisSchema)
        except Exception:
            self.structured_llm = None
        try:
            self.structured_evaluation_llm = self.llm.with_structured_output(
                SpecificationEvaluationSchema
            )
        except Exception:
            self.structured_evaluation_llm = None

        self.functional_analysis_workflow = None

    @staticmethod
    def _to_str_list(value: Any) -> List[str]:
        if not isinstance(value, list):
            return []
        return [str(v).strip() for v in value if str(v).strip()]

    @staticmethod
    def _normalize_task(item: Any) -> Dict[str, str]:
        if isinstance(item, str):
            return {"name": item.strip(), "description": ""}
        if not isinstance(item, dict):
            return {"name": "", "description": ""}
        return {
            "name": str(item.get("name", "")).strip(),
            "description": str(item.get("description", "")).strip(),
        }

    @staticmethod
    def _extract_response_text(response: Any) -> str:
        text_attr = getattr(response, "text", None)
        if isinstance(text_attr, str) and text_attr.strip():
            return text_attr

        content = getattr(response, "content", "")
        if isinstance(content, str):
            return content

        if isinstance(content, list):
            parts: List[str] = []
            for item in content:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict):
                    parts.append(str(item.get("text") or item.get("output_text") or ""))
                else:
                    text = getattr(item, "text", "")
                    if text:
                        parts.append(str(text))
            return "\n".join([part for part in parts if part])

        return str(content)

    @staticmethod
    def _clean_json_block(text: str) -> str:
        clean = (text or "").strip()
        if clean.startswith("```"):
            clean = re.sub(r"^```(?:json)?\s*", "", clean, flags=re.IGNORECASE)
            clean = re.sub(r"\s*```$", "", clean)
        return clean.strip()

    @classmethod
    def _extract_json(cls, text: str) -> Any:
        clean = cls._clean_json_block(text)
        try:
            return json.loads(clean)
        except json.JSONDecodeError:
            pass

        decoder = json.JSONDecoder()
        for idx, char in enumerate(clean):
            if char not in "{[":
                continue
            try:
                data, _ = decoder.raw_decode(clean[idx:])
                return data
            except json.JSONDecodeError:
                continue
        raise ValueError("No valid JSON was found in the LLM response.")

    @classmethod
    def _extract_tasks_by_line(cls, text: str) -> List[Dict[str, str]]:
        tasks: List[Dict[str, str]] = []
        for line in (text or "").splitlines():
            clean = line.strip()
            clean = re.sub(r"^[-*]\s*", "", clean)
            clean = re.sub(r"^\d+[\.\)]\s*", "", clean)
            clean = clean.strip()
            if clean:
                tasks.append({"name": clean, "description": ""})
        return tasks

    def _normalize_analysis(
        self, data: Any, parse_method: str, raw_response: str = ""
    ) -> Dict[str, Any]:
        analysis = empty_analysis()

        if isinstance(data, list):
            tasks = [self._normalize_task(item) for item in data]
            tasks = [task for task in tasks if task["name"] or task["description"]]
            analysis["detected_tasks"] = tasks
        elif isinstance(data, dict):
            analysis["functional_summary"] = str(
                data.get("functional_summary", "")
            ).strip()
            source_tasks = data.get("detected_tasks", [])
            tasks = [self._normalize_task(item) for item in source_tasks]
            analysis["detected_tasks"] = [
                task for task in tasks if task["name"] or task["description"]
            ]
            analysis["technical_components"] = self._to_str_list(
                data.get("technical_components")
            )
            analysis["detected_integrations"] = self._to_str_list(
                data.get("detected_integrations")
            )
            analysis["detected_risks"] = self._to_str_list(data.get("detected_risks"))
            analysis["assumptions"] = self._to_str_list(data.get("assumptions"))
            analysis["observations"] = self._to_str_list(data.get("observations"))

        analysis["analysis_metadata"] = {
            "model": self.model,
            "parse_method": parse_method,
            "execution_date": datetime.now().isoformat(timespec="seconds"),
            "task_count": len(analysis["detected_tasks"]),
            "raw_response_available": bool(raw_response),
        }
        return analysis

    def _diagnostics(self, parse_method: str, trace: List[str] | None = None) -> Dict[str, Any]:
        return {
            "workflow": "functional_analysis",
            "model": self.model,
            "parse_method": parse_method,
            "trace": trace or [],
        }

    @staticmethod
    def _normalize_evaluation(data: Any) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return incomplete_evaluation(
                "The completeness evaluation response could not be interpreted."
            )

        needs_completion = bool(data.get("needs_complete_specification", False))
        detail = str(data.get("requested_detail", "")).strip()

        if needs_completion:
            return incomplete_evaluation(detail)

        evaluation = sufficient_evaluation()
        if detail:
            evaluation["requested_detail"] = detail
        return evaluation

    def evaluate_functional_specification(self, state: FunctionalAnalysisWorkflowState):
        functional_specification = state["functional_specification"]
        prompt = get_specification_evaluation_prompt()

        try:
            messages = prompt.format_messages(
                functional_specification=functional_specification
            )

            if self.structured_evaluation_llm is not None:
                try:
                    output = self.structured_evaluation_llm.invoke(messages)
                    if hasattr(output, "model_dump"):
                        data = output.model_dump()
                    elif isinstance(output, dict):
                        data = output
                    else:
                        data = {}
                    evaluation = self._normalize_evaluation(data)
                    history = [
                        "Workflow 1: specification evaluation executed",
                        "Needs complete specification: "
                        f"{evaluation['needs_complete_specification']}",
                        "Evaluation parse method: structured",
                    ]
                    return {
                        "specification_evaluation": evaluation,
                        "diagnostics": self._diagnostics("structured", history),
                        "history": history,
                    }
                except Exception:
                    pass

            response = self.llm.invoke(messages)
            content = self._extract_response_text(response).strip()
            data = self._extract_json(content)
            evaluation = self._normalize_evaluation(data)
            history = [
                "Workflow 1: specification evaluation executed",
                "Needs complete specification: "
                f"{evaluation['needs_complete_specification']}",
                "Evaluation parse method: json_text",
            ]
            return {
                "specification_evaluation": evaluation,
                "diagnostics": self._diagnostics("json_text", history),
                "history": history,
            }
        except Exception as exc:
            evaluation = incomplete_evaluation(
                "The specification completeness could not be evaluated. "
                "Review that the text includes features, actors, rules, and expected flow."
            )
            history = [f"Specification evaluation error: {str(exc)}"]
            return {
                "specification_evaluation": evaluation,
                "diagnostics": self._diagnostics("error", history),
                "history": history,
            }

    def analyze_functional_specification(self, state: FunctionalAnalysisWorkflowState):
        functional_specification = state["functional_specification"]
        prompt = get_functional_analysis_prompt()

        try:
            messages = prompt.format_messages(
                functional_specification=functional_specification
            )

            if self.structured_llm is not None:
                try:
                    output = self.structured_llm.invoke(messages)

                    if hasattr(output, "model_dump"):
                        data = output.model_dump()
                    elif isinstance(output, dict):
                        data = output
                    else:
                        data = {}
                    analysis = self._normalize_analysis(data, "structured")
                    if analysis["detected_tasks"]:
                        return self._ok_response(analysis)
                except Exception:
                    pass

            response = self.llm.invoke(messages)
            content = self._extract_response_text(response).strip()

           

            try:
                data = self._extract_json(content)
                analysis = self._normalize_analysis(data, "json_text", content)
            except Exception:
                tasks = self._extract_tasks_by_line(content)
                analysis = self._normalize_analysis(
                    {"detected_tasks": tasks},
                    "lines",
                    content,
                )
            return self._ok_response(analysis)
        except Exception as exc:
            analysis = empty_analysis()
            analysis["analysis_metadata"] = {
                "model": self.model,
                "parse_method": "error",
                "execution_date": datetime.now().isoformat(timespec="seconds"),
                "task_count": 0,
            }
            history = [f"Workflow 1 error: {str(exc)}"]
            return {
                "functional_analysis": analysis,
                "diagnostics": self._diagnostics("error", history),
                "history": history,
            }

    @staticmethod
    def _ok_response(analysis: Dict[str, Any]) -> Dict[str, Any]:
        history = [
            "Workflow 1: functional analysis executed",
            "Detected tasks: " f"{len(analysis['detected_tasks'])}",
            "Parse method used: "
            f"{analysis['analysis_metadata'].get('parse_method', '')}",
        ]
        return {
            "functional_analysis": analysis,
            "diagnostics": {
                "workflow": "functional_analysis",
                "model": str(analysis["analysis_metadata"].get("model", "")),
                "parse_method": str(analysis["analysis_metadata"].get("parse_method", "")),
                "trace": history,
            },
            "history": history,
        }

    @staticmethod
    def functional_analysis_response(state: FunctionalAnalysisWorkflowState):
        analysis = state.get("functional_analysis", empty_analysis())
        diagnostics = state.get(
            "diagnostics",
            {
                "workflow": "functional_analysis",
                "model": "",
                "parse_method": "",
                "trace": [],
            },
        )
        return {
            "functional_analysis": analysis,
            "diagnostics": diagnostics,
            "history": ["Workflow 1: functional_analysis_response emitted."],
        }

    @staticmethod
    def _decide_next_node(state: FunctionalAnalysisWorkflowState) -> str:
        evaluation = state.get("specification_evaluation", {})
        if bool(evaluation.get("needs_complete_specification", False)):
            return END
        return "analyze_functional_specification"

    @staticmethod
    def _decide_first_node(state: FunctionalAnalysisWorkflowState) -> str:
        if bool(state.get("skip_previous_functional_analysis_evaluation", False)):
            return "analyze_functional_specification"
        return "evaluate_functional_specification"

    def create_functional_analysis_workflow(self):
        graph = StateGraph(FunctionalAnalysisWorkflowState)
        graph.add_node(
            "evaluate_functional_specification",
            self.evaluate_functional_specification,
        )
        graph.add_node(
            "analyze_functional_specification",
            self.analyze_functional_specification,
        )
        graph.add_node("functional_analysis_response", self.functional_analysis_response)
        graph.add_conditional_edges(
            START,
            self._decide_first_node,
            {
                "evaluate_functional_specification": "evaluate_functional_specification",
                "analyze_functional_specification": "analyze_functional_specification",
            },
        )
        graph.add_conditional_edges(
            "evaluate_functional_specification",
            self._decide_next_node,
            {
                "analyze_functional_specification": "analyze_functional_specification",
                END: END,
            },
        )
        graph.add_edge("analyze_functional_specification", "functional_analysis_response")
        graph.add_edge("functional_analysis_response", END)
        self.functional_analysis_workflow = graph
        return graph

    def compile_functional_analysis_workflow(self):
        if self.functional_analysis_workflow is None:
            self.create_functional_analysis_workflow()
        conn = sqlite3.connect(CHECKPOINT_DB_PATH, check_same_thread=False)
        return self.functional_analysis_workflow.compile(checkpointer=SqliteSaver(conn))


def create_functional_analysis_workflow():
    return FunctionalAnalysisWorkflow().compile_functional_analysis_workflow()
