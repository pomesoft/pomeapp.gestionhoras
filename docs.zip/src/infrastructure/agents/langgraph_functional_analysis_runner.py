from __future__ import annotations

import uuid

import httpx

from src.domain.errors import AgentTimeoutError, ConfigurationError, ProviderUnavailableError
from src.domain.models.schemas import (
    AgentDiagnostics,
    FunctionalAnalysisResult,
    empty_analysis,
    sufficient_evaluation,
)
from src.infrastructure.agents.graph import FunctionalAnalysisWorkflow
from src.infrastructure.config.settings import Settings


class LangGraphFunctionalAnalysisRunner:
    def __init__(self, settings: Settings):
        self._settings = settings

    def run(
        self,
        specification: str,
        skip_previous_evaluation: bool = False,
    ) -> FunctionalAnalysisResult:
        if self._settings.llm_provider.lower() != "openai":
            raise ProviderUnavailableError(
                f"Proveedor LLM no soportado en v1: {self._settings.llm_provider}"
            )
        if not self._settings.is_llm_configured:
            raise ConfigurationError("Falta configurar LLM_API_KEY y LLM_MODEL.")

        try:
            workflow_builder = FunctionalAnalysisWorkflow(
                api_key=self._settings.llm_api_key,
                base_url=self._settings.llm_base_url,
                model=self._settings.llm_model,
                verify_tls=self._settings.llm_verify_tls,
                timeout_seconds=self._settings.llm_timeout_seconds,
            )
            workflow = workflow_builder.create_functional_analysis_workflow().compile()
            thread_id = f"api-af-{uuid.uuid4().hex}"
            config = {"configurable": {"thread_id": thread_id}}
            initial_state = {
                "functional_specification": specification,
                "skip_previous_functional_analysis_evaluation": skip_previous_evaluation,
                "specification_evaluation": sufficient_evaluation(),
                "functional_analysis": empty_analysis(),
                "diagnostics": {
                    "workflow": "functional_analysis",
                    "model": "",
                    "parse_method": "",
                    "trace": [],
                },
                "history": [],
            }

            trace: list[str] = []
            analysis = empty_analysis()
            evaluation = sufficient_evaluation()
            diagnostics: dict[str, object] = {
                "workflow": "functional_analysis",
                "model": "",
                "parse_method": "",
                "trace": [],
            }
            for chunk in workflow.stream(
                initial_state, config=config, stream_mode="updates"
            ):
                for output in chunk.values():
                    if "history" in output and output["history"]:
                        trace.extend(output["history"])
                    if "specification_evaluation" in output:
                        evaluation = output["specification_evaluation"]
                    if "functional_analysis" in output:
                        analysis = output["functional_analysis"]
                    if "diagnostics" in output:
                        diagnostics = output["diagnostics"]
            metadata = analysis.get("analysis_metadata", {}) or {}
            parse_method = str(
                diagnostics.get("parse_method") or metadata.get("parse_method") or ""
            )
            if evaluation.get("needs_complete_specification"):
                parse_method = "specification_evaluation"
            return FunctionalAnalysisResult(
                analysis=analysis,
                evaluation=evaluation,
                diagnostics=AgentDiagnostics(
                    workflow=str(diagnostics.get("workflow") or "functional_analysis"),
                    model=str(
                        diagnostics.get("model")
                        or metadata.get("model")
                        or self._settings.llm_model
                    ),
                    parse_method=parse_method,
                    trace=trace,
                )
            )
        except httpx.TimeoutException as exc:
            raise AgentTimeoutError("Timeout ejecutando el agente de analisis funcional.") from exc
