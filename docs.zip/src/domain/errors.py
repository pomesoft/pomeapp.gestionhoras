from __future__ import annotations


class ApplicationError(Exception):
    """Base error for expected application failures."""


class InvalidSpecificationError(ApplicationError):
    pass


class ConfigurationError(ApplicationError):
    pass


class ProviderUnavailableError(ApplicationError):
    pass


class AgentTimeoutError(ApplicationError):
    pass
