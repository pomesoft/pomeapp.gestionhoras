from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class DocumentMetadata:
    """Metadata extraída de un documento DOCX"""
    filename: str                      # Nombre original del archivo
    file_size_bytes: int              # Tamaño en bytes
    last_modified: Optional[datetime]  # Fecha de última modificación
    author: Optional[str]              # Autor del documento
    num_images: int                    # Cantidad de imágenes extraídas
    content_hash: str                  # Hash SHA-256 del contenido


@dataclass
class ExtractedImage:
    """Imagen extraída de un documento"""
    image_id: str                      # ID único (ej: "img_1")
    base64_data: str                   # Datos de imagen en base64
    image_format: str                  # "png", "jpg", "gif", etc.
    file_size_bytes: int               # Tamaño de imagen
    description: Optional[str]         # Descripción post Vision Summary


@dataclass
class ParsedDocument:
    """Documento parseado completo"""
    metadata: DocumentMetadata
    plain_text: str                    # Contenido textual extraído
    html_content: str                  # Contenido HTML (de Mammoth)
    images: list[ExtractedImage]       # Lista de imágenes extraídas
    extraction_timestamp: datetime     # Cuándo se extrajo
