from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


@dataclass(frozen=True)
class AnalyzeOptions:
    skip_previous_evaluation: bool = False


@dataclass(frozen=True)
class AgentDiagnostics:
    workflow: str = "functional_analysis"
    model: str = ""
    parse_method: str = ""
    trace: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class FunctionalAnalysisResult:
    analysis: dict[str, Any]
    diagnostics: AgentDiagnostics
    evaluation: dict[str, Any] = field(default_factory=dict)


class FunctionalAnalysisRequest(BaseModel):
    specification: str
    skip_previous_evaluation: bool = False

    model_config = ConfigDict(extra="forbid")


class DetectedTaskModel(BaseModel):
    name: str = ""
    description: str = ""


class SpecificationEvaluationSchema(BaseModel):
    needs_complete_specification: bool = False
    requested_detail: str = (
        "The functional specification is sufficient to perform the analysis."
    )


class FunctionalAnalysisSchema(BaseModel):
    functional_summary: str = ""
    detected_tasks: list[DetectedTaskModel] = Field(default_factory=list)
    technical_components: list[str] = Field(default_factory=list)
    detected_integrations: list[str] = Field(default_factory=list)
    detected_risks: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    observations: list[str] = Field(default_factory=list)


class FunctionalAnalysisResponseModel(BaseModel):
    functional_summary: str = ""
    detected_tasks: list[DetectedTaskModel] = Field(default_factory=list)
    technical_components: list[str] = Field(default_factory=list)
    detected_integrations: list[str] = Field(default_factory=list)
    detected_risks: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    observations: list[str] = Field(default_factory=list)
    analysis_metadata: dict[str, Any] = Field(default_factory=dict)


class DiagnosticsResponse(BaseModel):
    workflow: str = "functional_analysis"
    model: str = ""
    parse_method: str = ""
    trace: list[str] = Field(default_factory=list)


class FunctionalAnalysisApiResponse(BaseModel):
    needs_complete_specification: bool = False
    requested_detail: str = ""
    analysis: FunctionalAnalysisResponseModel
    diagnostics: DiagnosticsResponse

    model_config = ConfigDict(extra="forbid")


class DocumentMetadata(BaseModel):
    """Metadata about an uploaded document (used as display/logging info only)."""

    filename: str
    size_bytes: int = 0
    extension: str = ""
    extraction_success: bool = True
    extraction_error: str = ""


class HealthResponse(BaseModel):
    status: str


class ReadyResponse(BaseModel):
    status: str
    llm_provider: str
    llm_model: str


def empty_analysis() -> dict[str, Any]:
    return {
        "functional_summary": "",
        "detected_tasks": [],
        "technical_components": [],
        "detected_integrations": [],
        "detected_risks": [],
        "assumptions": [],
        "observations": [],
        "analysis_metadata": {},
    }


def sufficient_evaluation() -> dict[str, Any]:
    return {
        "needs_complete_specification": False,
        "requested_detail": (
            "The functional specification is sufficient to perform the analysis."
        ),
    }


def incomplete_evaluation(requested_detail: str = "") -> dict[str, Any]:
    detail = str(requested_detail).strip()
    return {
        "needs_complete_specification": True,
        "requested_detail": detail
        or "The functional specification requires more detail to perform the analysis.",
    }
