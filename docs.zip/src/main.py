from __future__ import annotations

from fastapi import FastAPI

from src.api.v1.functional_analysis_routes import router as functional_analysis_router
from src.api.v1.health_routes import router as health_router
from src.infrastructure.config.settings import Settings


def create_app() -> FastAPI:
    settings = Settings()
    app = FastAPI(title=settings.app_name, version="1.0.0")
    app.include_router(health_router)
    app.include_router(functional_analysis_router)
    return app


app = create_app()
