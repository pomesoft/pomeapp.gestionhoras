"""Capa de exposición MCP.

Este paquete actúa como un adaptador delgado sobre las capas existentes de
Clean Architecture, exponiendo la funcionalidad del agente a través del
protocolo Model Context Protocol (MCP) mediante FastMCP.

No contiene lógica de negocio; únicamente adapta los modelos y casos de uso
existentes al formato requerido por MCP.
"""

__all__: list[str] = []
