from __future__ import annotations

import sys
from pathlib import Path

# Ensure the project root is on sys.path so `src` imports resolve when fastmcp
# loads this file directly as a standalone module.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from fastmcp import FastMCP
from fastmcp.server.auth.providers.azure import AzureProvider

from src.mcp.tools import (
    analyze_functional_requirement
)



# The Auth0Provider utilizes Auth0 OIDC configuration
# auth_provider = AzureProvider(
#     client_id="39946bc0-d91d-40ac-86d9-6a2f74306738",               # Your Auth0 application Client ID
#     client_secret="D-T8Q~JCm5YmibNTpRlUZXHdSpTvAE8xBeGh3c7m",       # Your Auth0 application Client Secret
#     tenant_id="038018c3-616c-4b46-ad9b-aa9007f701b5",
#     required_scopes=["api://39946bc0-d91d-40ac-86d9-6a2f74306738"],          # Your Auth0 API audience
#     base_url="http://localhost:8000",                           # Must match your application configuration
#     # redirect_path="/auth/callback"                            # Default value, customize if needed
# )

# mcp = FastMCP(
#     "nexplan-functional-analysis-mcp",
#     auth=auth_provider
# )

mcp = FastMCP(
    "nexplan-functional-analysis-mcp"
)

mcp.add_tool(analyze_functional_requirement)



def main() -> None:
    """Run the MCP server over HTTP."""
    print("Starting Nexplan Functional Analysis MCP server")
    mcp.run(transport="http")

if __name__ == "__main__":
    main()
