from __future__ import annotations

import base64
import logging
from typing import Any

from mcp.server.fastmcp.exceptions import ToolError

from src.api.dependencies import get_analyze_use_case, get_document_text_extractor
from src.application.services.specification_consolidator import consolidate_specification
from src.domain.errors import (
    AgentTimeoutError,
    ApplicationError,
    ConfigurationError,
    InvalidSpecificationError,
    ProviderUnavailableError,
)
from src.domain.models.schemas import (
    AnalyzeOptions,
    DiagnosticsResponse,
    FunctionalAnalysisApiResponse,
    FunctionalAnalysisResponseModel,
    empty_analysis,
)

logger = logging.getLogger(__name__)


def _build_api_response(result: Any) -> FunctionalAnalysisApiResponse:
    """Build the same API response payload from a use-case result."""
    diagnostics = DiagnosticsResponse(
        workflow=result.diagnostics.workflow,
        model=result.diagnostics.model,
        parse_method=result.diagnostics.parse_method,
        trace=result.diagnostics.trace,
    )
    evaluation = result.evaluation or {}
    needs_complete_specification = bool(
        evaluation.get("needs_complete_specification", False)
    )
    requested_detail = (
        str(evaluation.get("requested_detail", ""))
        if needs_complete_specification
        else ""
    )
    analysis_response = FunctionalAnalysisResponseModel.model_validate(result.analysis)
    return FunctionalAnalysisApiResponse(
        needs_complete_specification=needs_complete_specification,
        requested_detail=requested_detail,
        analysis=analysis_response,
        diagnostics=diagnostics,
    )


def _empty_response(requested_detail: str) -> dict[str, Any]:
    response = FunctionalAnalysisApiResponse(
        needs_complete_specification=True,
        requested_detail=requested_detail,
        analysis=FunctionalAnalysisResponseModel.model_validate(empty_analysis()),
        diagnostics=DiagnosticsResponse(parse_method="specification_evaluation"),
    )
    return response.model_dump(by_alias=True)


def _execute_use_case(
    specification: str,
    skip_previous_evaluation: bool = False,
) -> FunctionalAnalysisApiResponse:
    """Delegate the analysis to the existing use case and convert errors to ToolError."""
    use_case = get_analyze_use_case()

    try:
        result = use_case.execute(
            specification=specification,
            options=AnalyzeOptions(
                skip_previous_evaluation=skip_previous_evaluation,
            ),
        )
    except InvalidSpecificationError as exc:
        logger.warning("Especificacion invalida: %s", exc)
        raise ToolError(
            f"La especificacion proporcionada no es valida: {exc}"
        ) from exc
    except ConfigurationError as exc:
        logger.error("Error de configuracion del agente: %s", exc)
        raise ToolError(
            "El servicio de analisis no esta configurado correctamente. "
            "Verifica las variables de entorno del proveedor LLM."
        ) from exc
    except ProviderUnavailableError as exc:
        logger.error("Proveedor no disponible: %s", exc)
        raise ToolError(
            "El proveedor de lenguaje no esta disponible en este momento."
        ) from exc
    except AgentTimeoutError as exc:
        logger.error("Timeout del agente: %s", exc)
        raise ToolError(
            "La ejecucion del analisis excedio el tiempo maximo permitido."
        ) from exc
    except ApplicationError as exc:
        logger.error("Error de aplicacion en el agente: %s", exc)
        raise ToolError(f"Error ejecutando el analisis funcional: {exc}") from exc
    except Exception as exc:
        logger.exception("Error inesperado ejecutando el agente de analisis.")
        raise ToolError(
            "Ocurrio un error inesperado al ejecutar el analisis funcional."
        ) from exc

    return _build_api_response(result)


def analizar_requerimiento(especificacion_funcional: str) -> dict[str, Any]:
    """Analiza una especificacion funcional y retorna el JSON.

    Args:
        especificacion_funcional: Texto de la especificacion funcional a analizar.

    Returns:
        Diccionario equivalente a FunctionalAnalysisApiResponse.
    """
    if (
        not isinstance(especificacion_funcional, str)
        or especificacion_funcional.strip() in ("", "string")
    ):
        return _empty_response(
            "La especificacion funcional requiere mayor detalle para realizar el analisis."
        )

    response = _execute_use_case(especificacion_funcional.strip())
    return response.model_dump(by_alias=True)


def analyze_functional_requirement(
    specification: str,
    skip_previous_evaluation: bool = False,
) -> dict[str, Any]:
    """Analiza un requisito funcional utilizando el caso de uso existente.
    Args:
        specification: Texto de especificación funcional a analizar.
        skip_previous_evaluation: Omitir el paso de evaluación anterior.
    Returns:
        Diccionario equivalente a FunctionalAnalysisApiResponse.
    """
    if not isinstance(specification, str) or specification.strip() in ("", "string"):
        return _empty_response(
            "La especificacion funcional requiere mayor detalle para realizar el analisis."
        )

    response = _execute_use_case(
        specification=specification.strip(),
        skip_previous_evaluation=skip_previous_evaluation,
    )
    return response.model_dump(by_alias=True)
