from __future__ import annotations

from src.application.ports.agent_runner import AgentRunner
from src.domain.errors import InvalidSpecificationError
from src.domain.models.schemas import AnalyzeOptions, FunctionalAnalysisResult


class AnalyzeFunctionalRequirementUseCase:
    def __init__(self, agent_runner: AgentRunner):
        self._agent_runner = agent_runner

    def execute(
        self, specification: str, options: AnalyzeOptions | None = None
    ) -> FunctionalAnalysisResult:
        clean_specification = (specification or "").strip()
        if not clean_specification:
            raise InvalidSpecificationError("La especificacion funcional no puede estar vacia.")

        effective_options = options or AnalyzeOptions()
        result = self._agent_runner.run(
            clean_specification,
            skip_previous_evaluation=effective_options.skip_previous_evaluation,
        )
        return result
