"""
Specification consolidation service.

Merges a manually entered specification with text extracted from one or
more uploaded documents into a single, well-structured string that is
passed to the existing functional-analysis workflow unchanged.

This module contains NO I/O, NO framework code, and NO extraction logic.
It only combines already-extracted strings, so it can be reused from both
the FastAPI layer and the Streamlit UI (or any other entry point).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from src.application.ports.document_text_extractor import FileExtractionResult


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ConsolidationResult:
    """Outcome of a consolidation attempt."""

    specification: str
    """Final merged specification text, ready to be fed to the use case."""

    successful_files: list[str] = field(default_factory=list)
    """Filenames whose text was successfully extracted and included."""

    failed_files: list[tuple[str, str]] = field(default_factory=list)
    """Pairs of (filename, error_message) for files that could not be extracted."""

    @property
    def has_content(self) -> bool:
        """True if the consolidated specification contains any text."""
        return bool(self.specification.strip())


# ---------------------------------------------------------------------------
# Consolidation
# ---------------------------------------------------------------------------


def consolidate_specification(
    manual_text: str | None,
    extraction_results: list[FileExtractionResult],
) -> ConsolidationResult:
    """Build a single specification string from manual text and file extractions.

    The output format is:

        # Especificación ingresada por el usuario

        {manual_text}

        # Documentación adjunta

        ## Archivo: filename1.pdf

        {extracted_text_1}

        ## Archivo: filename2.docx

        {extracted_text_2}

    Sections are only included when they have content:
    - The "manual" section is omitted if *manual_text* is blank.
    - The "attached docs" section is omitted if no file succeeded extraction.
    - Files that failed extraction are recorded in *failed_files* and are
      NOT included in the specification body.

    Args:
        manual_text:        Raw text entered by the user (may be None or empty).
        extraction_results: One FileExtractionResult per uploaded file.

    Returns:
        ConsolidationResult with the merged specification and per-file metadata.
    """
    sections: list[str] = []
    successful_files: list[str] = []
    failed_files: list[tuple[str, str]] = []

    # ------------------------------------------------------------------
    # 1. Manual specification section
    # ------------------------------------------------------------------
    clean_manual = (manual_text or "").strip()
    if clean_manual:
        sections.append("# Especificación ingresada por el usuario")
        sections.append("")
        sections.append(clean_manual)

    # ------------------------------------------------------------------
    # 2. Attached documents section
    # ------------------------------------------------------------------
    successful_results = [r for r in extraction_results if r.success]
    failed_results = [r for r in extraction_results if not r.success]

    for result in failed_results:
        failed_files.append((result.filename, result.error_message))

    if successful_results:
        sections.append("")
        sections.append("# Documentación adjunta")
        for result in successful_results:
            sections.append("")
            sections.append(f"## Archivo: {result.filename}")
            sections.append("")
            sections.append(result.text)
            successful_files.append(result.filename)

    specification = "\n".join(sections).strip()

    return ConsolidationResult(
        specification=specification,
        successful_files=successful_files,
        failed_files=failed_files,
    )
