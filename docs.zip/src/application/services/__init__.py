# Application-layer services (framework-agnostic business logic helpers)
