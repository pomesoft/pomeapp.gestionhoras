from __future__ import annotations

from typing import Protocol

from src.domain.models.schemas import FunctionalAnalysisResult


class AgentRunner(Protocol):
    def run(
        self,
        specification: str,
        skip_previous_evaluation: bool = False,
    ) -> FunctionalAnalysisResult:
        ...
