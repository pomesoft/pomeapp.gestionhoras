from abc import ABC, abstractmethod
from src.domain.models.document_models import ParsedDocument


class DocumentParserPort(ABC):
    """Puerto abstracto para parsers de documentos"""
    
    @abstractmethod
    async def parse_docx(self, file_path: str) -> ParsedDocument:
        """
        Parsea un archivo DOCX y extrae contenido + imágenes
        
        Args:
            file_path: Ruta al archivo .docx
            
        Returns:
            ParsedDocument con contenido, metadata, e imágenes
            
        Raises:
            FileNotFoundError: Si archivo no existe
            ValueError: Si archivo no es DOCX válido
        """
        pass
    
    @abstractmethod
    async def validate_docx(self, file_path: str) -> bool:
        """
        Valida que el archivo sea DOCX válido sin parsearlo completo
        
        Args:
            file_path: Ruta al archivo .docx
            
        Returns:
            True si es válido, False en caso contrario
        """
        pass
