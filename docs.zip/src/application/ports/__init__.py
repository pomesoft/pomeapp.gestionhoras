"""
Application ports (abstractions/interfaces).

Define los contratos que las implementaciones concretas deben cumplir.
Implementaciones en: src/infrastructure/
"""

from src.application.ports.document_parser_port import DocumentParserPort

__all__ = [
    "DocumentParserPort",
]
