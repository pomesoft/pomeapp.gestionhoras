from __future__ import annotations

from typing import Protocol


class LlmProvider(Protocol):
    @property
    def model(self) -> str:
        ...

    def is_configured(self) -> bool:
        ...
