from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


@dataclass(frozen=True)
class FileExtractionResult:
    """Result of extracting text from a single file."""

    filename: str
    text: str
    success: bool
    error_message: str = ""


@runtime_checkable
class DocumentTextExtractor(Protocol):
    """Port: extract text content from uploaded file bytes."""

    def extract(self, filename: str, content: bytes) -> FileExtractionResult:
        """
        Extract text from file bytes.

        Args:
            filename: Original filename, used to determine extension and for metadata.
            content:  Raw bytes of the file.

        Returns:
            FileExtractionResult with extracted text or error information.
        """
        ...
