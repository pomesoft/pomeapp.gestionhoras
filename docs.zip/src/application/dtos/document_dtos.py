from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class DocumentMetadataDTO(BaseModel):
    """DTO para metadata del documento"""
    filename: str = Field(..., description="Nombre original del archivo")
    file_size_bytes: int = Field(..., ge=0, description="Tamaño en bytes")
    last_modified: Optional[datetime] = Field(None, description="Fecha de última modificación")
    author: Optional[str] = Field(None, description="Autor del documento")
    num_images: int = Field(..., ge=0, description="Cantidad de imágenes extraídas")
    content_hash: str = Field(..., description="Hash SHA-256 del contenido")


class ExtractedImageDTO(BaseModel):
    """DTO para imagen extraída"""
    image_id: str = Field(..., description="ID único de imagen")
    image_format: str = Field(..., description="Formato de imagen (png, jpg, gif, etc.)")
    file_size_bytes: int = Field(..., ge=0, description="Tamaño de imagen en bytes")
    description: Optional[str] = Field(None, description="Descripción de Vision Summary")


class ParsedDocumentDTO(BaseModel):
    """DTO para respuesta de parsing"""
    metadata: DocumentMetadataDTO = Field(..., description="Metadatos del documento")
    plain_text: str = Field(..., description="Contenido textual extraído")
    html_content: str = Field(..., description="Contenido HTML extraído por Mammoth")
    images: list[ExtractedImageDTO] = Field(default_factory=list, description="Imágenes extraídas")
    images_count: int = Field(..., ge=0, description="Cantidad total de imágenes")
    extraction_timestamp: datetime = Field(..., description="Timestamp de extracción")
    
    class Config:
        json_schema_extra = {
            "example": {
                "metadata": {
                    "filename": "spec.docx",
                    "file_size_bytes": 102400,
                    "last_modified": "2026-07-01T10:30:00Z",
                    "author": "John Doe",
                    "num_images": 2,
                    "content_hash": "abc123def456"
                },
                "plain_text": "Especificación funcional del sistema...",
                "html_content": "<p>Especificación funcional...</p>",
                "images": [
                    {
                        "image_id": "img_0",
                        "image_format": "png",
                        "file_size_bytes": 50000,
                        "description": "Mockup de login con campos de usuario y contraseña"
                    },
                    {
                        "image_id": "img_1",
                        "image_format": "jpg",
                        "file_size_bytes": 75000,
                        "description": "Diagrama de flujo del proceso de autenticación"
                    }
                ],
                "images_count": 2,
                "extraction_timestamp": "2026-07-01T10:35:00Z"
            }
        }
