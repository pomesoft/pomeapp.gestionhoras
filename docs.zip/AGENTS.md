# AGENTS.md

## Objetivo Del Proyecto

Este proyecto implementa un agente de IA para asistir a analistas funcionales, desarrolladores y arquitectos en el análisis funcional de especificaciones de requerimientos de software. La salida del agente queda estructurada para etapas posteriores de estimación, pero este repositorio **no** calcula estimaciones, horas, puntos ni costos.

El sistema expone **tres interfaces de acceso** al mismo workflow de análisis:

1. **API REST** (FastAPI): interfaz HTTP para integración con otros sistemas. Protegida con Bearer Token de Azure AD (OAuth2 / OpenID Connect).
2. **Streamlit UI / CLI**: interfaz de usuario web y línea de comandos para uso directo.
3. **Servidor MCP** (`src/mcp/`): expone el análisis funcional como herramientas (tools) del protocolo [Model Context Protocol](https://modelcontextprotocol.io), para ser consumido por clientes MCP compatibles (IDEs, agentes, etc.).

---

## Stack Principal

| Capa | Tecnología |
|------|-----------|
| Lenguaje | Python 3.11+ |
| API REST | FastAPI + Uvicorn |
| UI Web | Streamlit |
| Workflow IA | LangGraph (`langgraph`) |
| LLM | OpenAI / Azure OpenAI via `langchain-openai` |
| Modelos de datos | Pydantic v2 |
| Checkpointing | SQLite via `langgraph-checkpoint-sqlite` (UI/CLI) |
| Templating de prompt | Jinja2 |
| HTTP cliente | httpx |
| Configuración | Pydantic Settings (`.env`) |
| Modelo LLM esperado | `gpt-4.1` |
| Extracción PDF | pypdf |
| Extracción DOCX | python-docx |
| Carga multipart | python-multipart |
| Validación OAuth2 | `python-jose` + `PyJWT` + JWKS de Azure AD |
| Protocolo MCP | `mcp` (FastMCP sobre stdio) |

---

## Estructura Del Proyecto

```
NexplanAgente-Backend/
├── app.py                          # Interfaz Streamlit (UI web)
├── run_cli.py                      # Ejecución por línea de comandos
├── requirements.txt                # Dependencias Python
├── .env.example                    # Ejemplo de variables de entorno
├── README.md                       # Documentación de uso principal
├── docs/
│   └── backend_architecture.md     # Documentación de arquitectura técnica
├── src/
│   ├── main.py                     # Punto de entrada FastAPI (API REST)
│   ├── api/
│   │   ├── dependencies.py         # Inyección de dependencias FastAPI
│   │   ├── security/
│   │   │   └── azure_ad_validator.py  # Validación Bearer Token Azure AD
│   │   └── v1/
│   │       ├── functional_analysis_routes.py  # Rutas de análisis funcional
│   │       └── health_routes.py               # Rutas de salud del sistema
│   ├── application/
│   │   ├── ports/
│   │   │   ├── agent_runner.py              # Protocolo AgentRunner
│   │   │   ├── document_text_extractor.py   # Protocolo DocumentTextExtractor
│   │   │   ├── llm_provider.py              # Protocolo LlmProvider
│   │   │   └── retriever.py                 # Protocolo Retriever (reservado)
│   │   ├── services/
│   │   │   └── specification_consolidator.py  # Consolidación de especificación
│   │   └── use_cases/
│   │       └── analyze_functional_requirement.py  # Caso de uso principal
│   ├── domain/
│   │   ├── errors.py               # Excepciones de dominio
│   │   └── models/
│   │       └── schemas.py          # Modelos Pydantic y dataclasses
│   ├── infrastructure/
│   │   ├── agents/
│   │   │   ├── graph.py                 # Workflow LangGraph (nodos y lógica)
│   │   │   ├── langgraph_functional_analysis_runner.py  # AgentRunner concreto
│   │   │   └── prompts.py               # Templates Jinja2 de prompts LLM
│   │   ├── config/
│   │   │   └── settings.py              # Configuración via Pydantic Settings
│   │   ├── documents/
│   │   │   └── document_text_extractor.py  # Extractor concreto (TXT, PDF, DOCX)
│   │   └── llm/
│   │       └── openai_provider.py        # Proveedor LLM (wrapper OpenAI)
│   └── mcp/
│       ├── mcp_server.py           # Servidor MCP sobre stdio
│       └── tools.py                # Tools expuestas por MCP
```

---

## API REST

### Base URL

```
http://<host>:<port>
```

Rutas disponibles:

- `GET /health`
- `GET /ready`
- `POST /api/v1/functional-analysis`
- `POST /api/v1/functional-analysis/upload`

### Autenticación

Todos los endpoints de análisis (`/api/v1/functional-analysis` y `/api/v1/functional-analysis/upload`) requieren un **Bearer Token** válido emitido por **Azure Active Directory** (OAuth2 / OpenID Connect).

El token se envía en el header:

```
Authorization: Bearer <access_token>
```

La API valida:

- Firma del JWT contra JWKS del tenant.
- `aud` (audience) contra `AZURE_AUDIENCE`.
- `iss` (issuer) contra el tenant configurado.
- Expiración (`exp`).

Si el token no es válido, expiró o no coincide con audience/issuer, se retorna `401 Unauthorized`.

### Health checks

#### `GET /health`

**Propósito:** Verificar que la aplicación está viva (liveness probe).

**Autenticación:** Ninguna.

**Response 200 OK:**
```json
{
  "status": "ok"
}
```

---

#### `GET /ready`

**Propósito:** Verificar si la aplicación está lista para recibir tráfico (readiness probe). Valida que el proveedor LLM esté configurado.

**Autenticación:** Ninguna.

**Response 200 OK** (LLM configurado):
```json
{
  "status": "ready",
  "llm_provider": "openai",
  "llm_model": "gpt-4.1"
}
```

**Response 503 Service Unavailable** (LLM no configurado):
```json
{
  "detail": "Configuracion LLM incompleta."
}
```

---

#### `POST /api/v1/functional-analysis`

**Propósito:** Recibe una especificación funcional en texto libre y ejecuta el workflow de análisis IA (LangGraph + LLM). Retorna el análisis estructurado completo, o una solicitud de mayor detalle si la especificación es insuficiente.

**Autenticación:** Requiere Bearer Token de Azure AD.

```
Authorization: Bearer <access_token>
```

**Request Body** (`application/json`):
```json
{
  "specification": "Texto libre con la especificación funcional del requerimiento.",
  "skip_previous_evaluation": false
}
```

| Campo | Tipo | Requerido | Default | Descripción |
|-------|------|-----------|---------|-------------|
| `specification` | string | Sí | - | Texto de la especificación funcional. No puede ser vacío. |
| `skip_previous_evaluation` | boolean | No | `false` | Si es `true`, omite el nodo de evaluación previa y ejecuta el análisis funcional directamente. |

**Validaciones de request:**
- `specification` vacío o solo espacios → `400 Bad Request`.
- Header `Authorization` ausente o token inválido → `401 Unauthorized`.
- LLM no configurado (falta `LLM_API_KEY` o `LLM_MODEL`) → `503 Service Unavailable`.
- Timeout del workflow LangGraph → `504 Gateway Timeout`.

**Response 200 OK:**
```json
{
  "needs_complete_specification": false,
  "requested_detail": "",
  "analysis": {
    "functional_summary": "Resumen funcional del requerimiento analizado.",
    "detected_tasks": [
      {
        "name": "Nombre de la tarea",
        "description": "Descripción detallada de la tarea."
      }
    ],
    "technical_components": ["componente global 1"],
    "detected_integrations": ["integración 1"],
    "detected_risks": ["riesgo global 1"],
    "assumptions": ["supuesto global 1"],
    "observations": ["observación 1"],
    "analysis_metadata": {
      "model_used": "gpt-4.1",
      "analysis_version": "1.0",
      "timestamp": "2024-01-01T00:00:00Z",
      "specification_length": 120,
      "task_count": 3,
      "parse_method": "structured"
    }
  },
  "diagnostics": {
    "workflow": "functional_analysis",
    "model": "gpt-4.1",
    "parse_method": "structured",
    "trace": [
      "Workflow 1: specification evaluation executed",
      "Workflow 1: functional analysis executed"
    ]
  }
}
```

**Response 200 OK** (especificación insuficiente, análisis vacío):
```json
{
  "needs_complete_specification": true,
  "requested_detail": "Faltan reglas de negocio y flujo esperado para gestionar el stock.",
  "analysis": {
    "functional_summary": "",
    "detected_tasks": [],
    "technical_components": [],
    "detected_integrations": [],
    "detected_risks": [],
    "assumptions": [],
    "observations": [],
    "analysis_metadata": {}
  },
  "diagnostics": {
    "workflow": "functional_analysis",
    "model": "gpt-4.1",
    "parse_method": "specification_evaluation",
    "trace": [
      "Workflow 1: specification evaluation executed",
      "Needs complete specification: True"
    ]
  }
}
```

**Response 400 Bad Request** (especificación vacía):
```json
{
  "detail": "La especificacion funcional no puede estar vacia."
}
```

**Response 401 Unauthorized**:
```json
{
  "detail": "Token invalido: audience incorrecto."
}
```

**Response 503 Service Unavailable** (LLM no configurado):
```json
{
  "detail": "Falta configurar LLM_API_KEY y LLM_MODEL."
}
```

**Response 504 Gateway Timeout**:
```json
{
  "detail": "Timeout ejecutando el agente de analisis funcional."
}
```

---

#### `POST /api/v1/functional-analysis/upload`

**Propósito:** Recibe texto manual y/o documentos adjuntos (TXT, PDF, DOCX), consolida el contenido extraído en una única especificación y ejecuta el workflow de análisis IA. Retorna el mismo contrato que el endpoint JSON.

**Autenticación:** Requiere Bearer Token de Azure AD.

```
Authorization: Bearer <access_token>
```

**Request** (`multipart/form-data`):

| Campo | Tipo | Requerido | Descripción |
|-------|------|-----------|-------------|
| `specification` | string (form) | No | Texto libre ingresado manualmente por el usuario. |
| `skip_previous_evaluation` | boolean (form) | No | Si es `true`, omite la evaluación previa. Default: `false`. |
| `files` | File[] | No | Archivos adjuntos. Formatos permitidos: `.txt`, `.pdf`, `.docx`. |

**Regla de validación:** Debe existir al menos `specification` con texto o al menos un archivo con texto extraíble. Si ambos están ausentes o todos fallan la extracción, retorna `400 Bad Request`.

**Consolidación de contenido:**

El texto final enviado al workflow se construye con la siguiente estructura:

```
# Especificación ingresada por el usuario

{texto_manual}

# Documentación adjunta

## Archivo: nombre_archivo_1.pdf

{texto_extraido_pdf}

## Archivo: nombre_archivo_2.docx

{texto_extraido_docx}
```

**Validaciones de archivos:**
- Extensiones permitidas: `.txt`, `.pdf`, `.docx`.
- Archivos vacíos → descartados con error informativo.
- Archivos que superan `MAX_FILE_SIZE_MB` → descartados con error informativo.
- Formatos no soportados → descartados con error informativo.
- Archivos con error de extracción → descartados, el resto continúa.

**Response 200 OK:** Mismo contrato que `POST /api/v1/functional-analysis`.

**Response 400 Bad Request** (sin texto ni archivos válidos):
```json
{
  "detail": "Se requiere al menos texto manual o un archivo válido con contenido extraíble. Errores de extracción: ..."
}
```

---

## Arquitectura Lógica (API REST)

```
HTTP Request
    │
    ▼
FastAPI Router (api/v1/functional_analysis_routes.py)
    │  Validación de Azure AD (azure_ad_validator.py)
    │  Validación de body (Pydantic) / form fields
    │
    ▼  [Solo endpoint /upload]
DocumentTextExtractor (infrastructure/documents/)
    │  Extracción de texto por formato (.txt, .pdf, .docx)
    │  Validación de tamaño y extensión
    │
    ▼  [Solo endpoint /upload]
consolidate_specification (application/services/specification_consolidator.py)
    │  Merge de texto manual + textos extraídos
    │  Construcción de especificación consolidada
    │
    ▼
AnalyzeFunctionalRequirementUseCase (application/use_cases/)
    │  Sanitización de entrada
    │  Verificación LLM configurado
    │
    ▼
LangGraphFunctionalAnalysisRunner (infrastructure/agents/)
    │  Compilación del StateGraph
    │  Streaming de eventos
    │  Control de timeout
    │
    ▼
FunctionalAnalysisWorkflow (infrastructure/agents/graph.py)
    │
    ├── Nodo: evaluate_functional_specification
    │       Evalúa si la especificación es suficiente para analizar.
    │       Usa prompt Jinja2 + LLM estructurado.
    │       Si no es suficiente → retorna análisis incompleto.
    │
    ├── Nodo: analyze_functional_specification
    │       Construye prompt Jinja2 completo.
    │       Llama ChatOpenAI (temperature=0).
    │       Parseo: structured output → JSON textual → fallback por líneas.
    │       Normaliza al contrato de FunctionalAnalysisSchema.
    │
    └── Nodo: functional_analysis_response
            Consolida el análisis.
            Agrega trazas de diagnóstico al historial.
    │
    ▼
FunctionalAnalysisApiResponse (domain/models/schemas.py)
    │
    ▼
HTTP Response JSON
```

---

## Servidor MCP

### Propósito

`src/mcp/mcp_server.py` expone la funcionalidad del agente analista funcional como **tools del Model Context Protocol (MCP)**, utilizando `FastMCP` sobre transporte **stdio**. Esto permite que clientes MCP (IDEs, asistentes, agentes orquestadores, etc.) invoquen el análisis funcional de forma nativa.

### Arquitectura MCP

```
Cliente MCP (inspector / IDE / agente)
    │
    │  stdio JSON-RPC
    ▼
FastMCP server (src/mcp/mcp_server.py)
    │
    ▼
Tools (src/mcp/tools.py)
    │
    ▼
AnalyzeFunctionalRequirementUseCase
    │  Reutiliza el mismo caso de uso que la API REST
    ▼
LangGraphFunctionalAnalysisRunner → LangGraph → LLM
```

El servidor MCP **no implementa autenticación propia**: asume que el transporte stdio es local y controlado. La seguridad queda delegada al entorno de ejecución donde se configura el cliente MCP.

### Tools expuestas

| Tool | Nombre técnico | Descripción |
|------|----------------|-------------|
| `analizar_requerimiento` | `analizar_requerimiento` | Analiza una especificación funcional en español y retorna el JSON de respuesta. |
| `analyze_functional_requirement` | `analyze_functional_requirement` | Analiza una especificación funcional en inglés y retorna el JSON de respuesta. |

**Parámetros de `analyze_functional_requirement`:**

| Parámetro | Tipo | Requerido | Default | Descripción |
|-----------|------|-----------|---------|-------------|
| `specification` | string | Sí | - | Texto de la especificación funcional. |
| `skip_previous_evaluation` | boolean | No | `false` | Omite el nodo de evaluación previa y analiza directamente. |

La tool `analizar_requerimiento` recibe el parámetro `especificacion_funcional` (string) y llama al mismo caso de uso.

### Respuesta de una tool MCP

Ambas tools retornan un diccionario equivalente a `FunctionalAnalysisApiResponse`:

```json
{
  "needs_complete_specification": false,
  "requested_detail": "",
  "analysis": {
    "functional_summary": "...",
    "detected_tasks": [
      { "name": "...", "description": "..." }
    ],
    "technical_components": [],
    "detected_integrations": [],
    "detected_risks": [],
    "assumptions": [],
    "observations": [],
    "analysis_metadata": {}
  },
  "diagnostics": {
    "workflow": "functional_analysis",
    "model": "gpt-4.1",
    "parse_method": "structured",
    "trace": []
  }
}
```

Si la especificación es vacía o placeholder (`"string"`) la tool retorna `needs_complete_specification=true` sin lanzar error. Si ocurre un error de configuración o ejecución, se lanza `ToolError` con un mensaje descriptivo.

### Logging

El servidor MCP configura logging para enviar **todos los registros a `stderr`**. Esto es obligatorio porque el transporte stdio reserva `stdout` exclusivamente para mensajes JSON-RPC; cualquier log en `stdout` rompería el parser del cliente MCP.

### Configuración requerida

El servidor MCP requiere las mismas variables de entorno del proveedor LLM que la API REST:

| Variable | Requerida | Descripción |
|----------|-----------|-------------|
| `LLM_API_KEY` | Sí | Clave del proveedor LLM. |
| `LLM_BASE_URL` | Sí | URL base del endpoint LLM. |
| `LLM_MODEL` | No | Modelo. Default: `gpt-4.1`. |
| `LLM_VERIFY_TLS` | No | Verificación TLS. Default: `true`. |
| `LLM_TIMEOUT_SECONDS` | No | Timeout en segundos. Default: `60`. |

No requiere variables de Azure AD porque no valida tokens; la confianza está en el entorno local donde corre.

### Ejecución

#### Modo stdio (recomendado para producción local e IDEs)

El servidor escucha mensajes JSON-RPC por `stdin/stdout`. Es el modo más común para clientes MCP que lanzan el servidor como subproceso.

```powershell
python src\mcp\mcp_server.py
```

Con MCP Inspector:

```powershell
npx -y @modelcontextprotocol/inspector
# Configurar en la UI:
# Command:  C:\Proyectos\Nexplan-Agente\NexplanAgente-Backend\venv\Scripts\python.exe
# Arguments: C:\Proyectos\Nexplan-Agente\NexplanAgente-Backend\src\mcp\mcp_server.py
```

#### Modo HTTP/SSE (debug con servidor ya corriendo)

El servidor expone un endpoint `/sse` en `http://127.0.0.1:8000`. Para activar este modo, asegúrate de que `mcp_server.py` tenga:

```python
mcp.run(transport="http", host="127.0.0.1", port=8000)
```

Pasos:

1. Iniciar el servidor MCP:
   ```powershell
   python src\mcp\mcp_server.py
   ```

2. Conectar el Inspector a la URL SSE:
   ```powershell
   npx -y @modelcontextprotocol/inspector http://127.0.0.1:8000/sse
   ```

   > Si el comando anterior no funciona, abre `http://localhost:6274` y configura manualmente la URL `http://127.0.0.1:8000/sse` en el transporte del Inspector.

> **Nota:** No ejecutes `npx -y @modelcontextprotocol/inspector` sin argumentos ni configuración, porque por defecto intentará conectarse a `http://localhost:3001/sse` y fallará con `ECONNREFUSED` si no hay un servidor SSE corriendo en ese puerto.

---

## Workflow LangGraph

El workflow `FunctionalAnalysisWorkflow` es un `StateGraph` con los siguientes nodos:

| Nodo | Responsabilidad |
|------|----------------|
| `evaluate_functional_specification` | Evalúa la calidad/suficiencia de la especificación antes de analizarla. Puede cortocircuitar el flujo si la especificación es insuficiente. |
| `analyze_functional_specification` | Ejecuta el análisis funcional completo llamando al LLM. Implementa tres estrategias de parseo en cascada. |
| `functional_analysis_response` | Consolida resultado, agrega diagnósticos y trazas. Punto de salida del grafo. |

**Checkpointing:** Estado del grafo persistido en SQLite (`SqliteSaver`) en el flujo Streamlit y CLI. La API REST no guarda checkpoints; cada request crea un `thread_id` efímero.

**Parseo en cascada:**
1. Salida estructurada Pydantic (`.with_structured_output()`).
2. Parseo JSON textual (extracción de bloques ` ```json ... ``` `).
3. Fallback por líneas (parsing defensivo línea a línea).

---

## Extracción De Documentos

### Puerto (Interfaz)

`src/application/ports/document_text_extractor.py` define:

- `FileExtractionResult` (dataclass): resultado de extracción por archivo.
  - `filename: str` — nombre original del archivo.
  - `text: str` — texto extraído (vacío si falló).
  - `success: bool` — indica si la extracción fue exitosa.
  - `error_message: str` — descripción del error si `success=False`.
- `DocumentTextExtractor` (Protocol): interfaz con método `extract(filename: str, content: bytes) → FileExtractionResult`.

### Implementación Concreta

`src/infrastructure/documents/document_text_extractor.py` implementa `ConcreteDocumentTextExtractor`:

| Formato | Librería | Comportamiento |
|---------|---------|----------------|
| `.txt` | built-in | Decodificación UTF-8 con fallback latin-1. |
| `.pdf` | pypdf | Extracción página a página. Maneja PDFs encriptados o de solo imágenes con advertencia. |
| `.docx` | python-docx | Extracción de párrafos del documento Word. |

**Validaciones aplicadas por el extractor:**
- Contenido vacío (0 bytes) → error.
- Tamaño superior a `MAX_FILE_SIZE_MB` (configurable, default: 10 MB) → error.
- Extensión no soportada → error con mensaje descriptivo.
- Nombres de archivo sanitizados con `pathlib.PurePosixPath` / `PureWindowsPath` para evitar traversal.

**Singleton disponible:** `document_text_extractor` en `src/infrastructure/documents/document_text_extractor.py` para inyección de dependencias.

### Consolidación De Especificación

`src/application/services/specification_consolidator.py` expone:

- `ConsolidationResult` (dataclass):
  - `specification: str` — texto final consolidado.
  - `successful_files: list[str]` — nombres de archivos procesados correctamente.
  - `failed_files: list[tuple[str, str]]` — pares `(filename, error_message)` para archivos fallidos.
  - `has_content: bool` — indica si el texto consolidado no está vacío.
- `consolidate_specification(manual_text, extraction_results) → ConsolidationResult`: construye la especificación final con secciones claramente delimitadas.

---

## Streamlit UI

### Funcionalidades

- **Campo de texto:** área de texto para ingresar especificación manual.
- **Carga de archivos:** `st.file_uploader` con `accept_multiple_files=True`.
  - Formatos aceptados: `.txt`, `.pdf`, `.docx`.
  - Muestra lista de archivos cargados con tamaño.
  - Muestra advertencias para archivos con error de extracción.
- **Validación:** si no hay texto manual ni archivos, muestra advertencia y detiene el análisis.
- **Evaluación previa opcional:** checkbox para saltar el nodo `evaluate_functional_specification`.
- **Consolidación:** extracción y merge realizados en-proceso usando los servicios de aplicación e infraestructura directamente (sin HTTP).
- **Resultado:** renderiza resumen, tareas en tabla, componentes, riesgos, supuestos, observaciones, metadatos y JSON completo.

### Función auxiliar en `app.py`

`_extract_and_consolidate(manual_text, uploaded_files)`:
- Itera sobre archivos `UploadedFile` de Streamlit.
- Llama a `document_text_extractor.extract(filename, bytes)` para cada archivo.
- Invoca `consolidate_specification` con el texto manual y los resultados de extracción.
- Retorna `(consolidated_spec: str, warnings: list[str])`.

---

## Modelos De Datos Principales

### Request

| Modelo | Ubicación | Descripción |
|--------|-----------|-------------|
| `FunctionalAnalysisRequest` | `domain/models/schemas.py` | Body del endpoint POST JSON. Campos: `specification`, `skip_previous_evaluation`. |
| `AnalyzeOptions` | `domain/models/schemas.py` | Opciones internas del caso de uso. |
| `DocumentMetadata` | `domain/models/schemas.py` | Metadatos de un documento adjunto procesado. |

### Response API / MCP

| Modelo | Ubicación | Descripción |
|--------|-----------|-------------|
| `FunctionalAnalysisApiResponse` | `domain/models/schemas.py` | Respuesta completa del endpoint POST y de las tools MCP. |
| `FunctionalAnalysisResponseModel` | `domain/models/schemas.py` | Contrato del objeto `analysis`. |
| `DetectedTaskModel` | `domain/models/schemas.py` | Tarea funcional detectada (`name`, `description`). |
| `DiagnosticsResponse` | `domain/models/schemas.py` | Diagnóstico del workflow. |
| `HealthResponse` | `domain/models/schemas.py` | Respuesta de `/health`. |
| `ReadyResponse` | `domain/models/schemas.py` | Respuesta de `/ready` incluyendo proveedor y modelo. |

### Dominio / Workflow

| Modelo | Ubicación | Descripción |
|--------|-----------|-------------|
| `FunctionalAnalysisResult` | `domain/models/schemas.py` | Resultado del caso de uso (analysis, diagnostics, evaluation). |
| `AgentDiagnostics` | `domain/models/schemas.py` | Dataclass interno de diagnóstico del agente. |
| `SpecificationEvaluationSchema` | `domain/models/schemas.py` | Evaluación previa de completitud. |
| `FunctionalAnalysisWorkflowState` | `infrastructure/agents/graph.py` | Estado interno del StateGraph LangGraph. |

### Funciones de fábrica

| Función | Descripción |
|---------|-------------|
| `empty_analysis()` | Retorna un `FunctionalAnalysisSchema` vacío. |
| `incomplete_evaluation()` | Retorna evaluación marcada como incompleta. |
| `sufficient_evaluation()` | Retorna diagnóstico positivo para especificaciones válidas. |

---

## Puertos (Interfaces / Protocolos)

| Puerto | Archivo | Descripción |
|--------|---------|-------------|
| `AgentRunner` | `application/ports/agent_runner.py` | Protocolo para ejecutar el agente IA. Implementado por `LangGraphFunctionalAnalysisRunner`. |
| `LlmProvider` | `application/ports/llm_provider.py` | Protocolo para acceder al proveedor LLM. Implementado por `OpenAiProvider`. |
| `DocumentTextExtractor` | `application/ports/document_text_extractor.py` | Protocolo para extracción de texto de archivos. Implementado por `ConcreteDocumentTextExtractor`. |
| `Retriever` | `application/ports/retriever.py` | Protocolo para recuperación de contexto (RAG). Reservado para uso futuro. |

---

## Excepciones De Dominio

Definidas en `src/domain/errors.py`:

| Excepción | Causa | HTTP Status |
|-----------|-------|-------------|
| `InvalidSpecificationError` | Especificación vacía o inválida | 400 |
| `ConfigurationError` | Variables de entorno LLM ausentes | 503 |
| `ProviderUnavailableError` | Proveedor no soportado o endpoint no disponible | 503 |
| `AgentTimeoutError` | El workflow superó el tiempo máximo | 504 |

---

## Configuración De Entorno

Variables leídas desde `.env` via Pydantic Settings (`infrastructure/config/settings.py`):

### Proveedor LLM

| Variable | Requerida | Descripción |
|----------|-----------|-------------|
| `LLM_API_KEY` | Sí | Clave de API del proveedor LLM. También acepta `API_KEY_LLM` por compatibilidad. |
| `LLM_BASE_URL` | Sí | URL base del endpoint LLM. También acepta `BASE_URL_LLM` por compatibilidad. |
| `LLM_PROVIDER` | No | Proveedor LLM. Default: `openai`. |
| `LLM_MODEL` | No | Nombre del modelo LLM. Default: `gpt-4.1`. |
| `LLM_VERIFY_TLS` | No | Verificación TLS en llamadas HTTP al LLM. Default: `true`. |
| `LLM_TIMEOUT_SECONDS` | No | Timeout en segundos. Default: `60`. |

### Azure AD / OAuth2

| Variable | Requerida | Descripción |
|----------|-----------|-------------|
| `AZURE_TENANT_ID` | Sí | Tenant ID de Azure AD. |
| `AZURE_CLIENT_ID` | Sí | Client ID de la aplicación registrada. |
| `AZURE_AUDIENCE` | Sí | Audience esperada del token (`api://...`). |
| `AZURE_INSTANCE` | No | Instancia de login. Default: `https://login.microsoftonline.com/`. |
| `AZURE_CLIENT_SECRET` | No | Client secret; solo requerido si la API valida tokens adquiriendo secretos o llama a Microsoft Graph (no usado actualmente en validación). |

### Carga de documentos

| Variable | Requerida | Descripción |
|----------|-----------|-------------|
| `MAX_FILE_SIZE_MB` | No | Tamaño máximo por archivo adjunto en MB. Default: `10`. |

**Propiedades derivadas:**

- `settings.is_llm_configured` → `True` si `LLM_API_KEY` y `LLM_MODEL` están definidas y no vacías.
- `settings.is_azure_ad_configured` → `True` si `AZURE_TENANT_ID`, `AZURE_CLIENT_ID` y `AZURE_AUDIENCE` están definidas.

**Ejemplo de `.env`:**
```env
LLM_API_KEY=sk-...
LLM_BASE_URL=https://foundrymobile.services.ai.azure.com/openai/v1/
LLM_PROVIDER=openai
LLM_MODEL=gpt-4.1
LLM_VERIFY_TLS=true
LLM_TIMEOUT_SECONDS=60
MAX_FILE_SIZE_MB=10

# Azure AD
AZURE_TENANT_ID=038018c3-616c-4b46-ad9b-aa9007f701b5
AZURE_CLIENT_ID=39946bc0-d91d-40ac-86d9-6a2f74306738
AZURE_AUDIENCE=api://39946bc0-d91d-40ac-86d9-6a2f74306738
AZURE_CLIENT_SECRET=[completar si aplica]
```

---

## Inyección De Dependencias (API REST / MCP)

`src/api/dependencies.py` provee las dependencias FastAPI:

- `get_settings()` → instancia de `Settings`.
- `get_analyze_use_case()` → instancia de `AnalyzeFunctionalRequirementUseCase` con `LangGraphFunctionalAnalysisRunner`.
- `get_document_text_extractor()` → instancia singleton de `ConcreteDocumentTextExtractor` para el endpoint multipart.

El servidor MCP (`src/mcp/tools.py`) importa `get_analyze_use_case` y `get_document_text_extractor` desde `src.api.dependencies`, reutilizando la misma configuración y casos de uso sin duplicar lógica.

---

## Contrato De Salida Del Análisis (Inmutable)

La estructura principal de `FunctionalAnalysisResponseModel` debe mantenerse:

```
needs_complete_specification   boolean
requested_detail               string
analysis
  ├── functional_summary          string
  ├── detected_tasks[]
  │     ├── name                  string
  │     └── description           string
  ├── technical_components        string[]
  ├── detected_integrations       string[]
  ├── detected_risks              string[]
  ├── assumptions                 string[]
  ├── observations                string[]
  └── analysis_metadata
        ├── model_used            string
        ├── analysis_version      string
        ├── timestamp             string (ISO 8601)
        ├── specification_length  int
        ├── task_count            int
        └── parse_method          string
diagnostics
  ├── workflow                    string
  ├── model                       string
  ├── parse_method                string
  └── trace                       string[]
```

> El modelo ya **no** incluye `estimated_complexity` por tarea. Si en el futuro se reintroduce, debe reflejarse también en `FunctionalAnalysisSchema` y en los prompts.

---

## Comandos De Ejecución

### API REST

```powershell
# Instalar dependencias
python -m pip install -r requirements.txt

# Iniciar servidor FastAPI
uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload
```

### Streamlit UI

```powershell
streamlit run app.py
```

### CLI

```powershell
# Con texto inline
python .\run_cli.py "Se requiere implementar login, recuperación de clave y ABM de usuarios."

# Con archivo
python .\run_cli.py --file .\especificacion.txt

# Saltar evaluación previa
python .\run_cli.py --skip-previous-evaluation "Se requiere implementar login..."
```

### Servidor MCP

#### Modo stdio (recomendado para producción local e IDEs)

El servidor escucha mensajes JSON-RPC por `stdin/stdout`. Es el modo más común para clientes MCP que lo lanzan como subproceso.

```powershell
python src\mcp\mcp_server.py
```

Con MCP Inspector (el inspector lanza el servidor como subproceso stdio):

```powershell
npx -y @modelcontextprotocol/inspector
# Configurar en la UI:
# Command:  C:\Proyectos\Nexplan-Agente\NexplanAgente-Backend\venv\Scripts\python.exe
# Arguments: C:\Proyectos\Nexplan-Agente\NexplanAgente-Backend\src\mcp\mcp_server.py
```

#### Modo HTTP/SSE (solo para debug)

El servidor expone un endpoint `/sse` en `http://127.0.0.1:8000`. Para activar este modo, asegúrate de que `mcp_server.py` tenga:

```python
mcp.run(transport="http", host="127.0.0.1", port=8000)
```

Pasos:

1. Iniciar el servidor MCP:
   ```powershell
   python src\mcp\mcp_server.py
   ```

2. Conectar el Inspector a la URL SSE:
   ```powershell
   npx -y @modelcontextprotocol/inspector http://127.0.0.1:8000/sse
   ```

   > Si el comando anterior no funciona, abre `http://localhost:6274` y configura manualmente la URL `http://127.0.0.1:8000/sse` en el transporte del Inspector.

> **Nota:** No ejecutes `npx -y @modelcontextprotocol/inspector` sin argumentos ni configuración, porque por defecto intentará conectarse a `http://localhost:3001/sse` y fallará con `ECONNREFUSED` si no hay un servidor SSE corriendo en ese puerto.

---

## Convenciones De Desarrollo

- Código Python simple y explícito.
- Separación estricta de capas: UI / API → Use Cases → Domain → Infrastructure.
- Centralizar cambios de contrato en `src/domain/models/schemas.py`.
- Centralizar cambios de prompt en `src/infrastructure/agents/prompts.py`.
- Centralizar cambios de workflow en `src/infrastructure/agents/graph.py`.
- Centralizar lógica de extracción de documentos en `src/infrastructure/documents/`.
- Centralizar lógica de consolidación en `src/application/services/specification_consolidator.py`.
- Centralizar validación OAuth2 en `src/api/security/azure_ad_validator.py`.
- Centralizar tools MCP en `src/mcp/tools.py` y el servidor en `src/mcp/mcp_server.py`.
- No mezclar lógica de UI ni de HTTP en `graph.py`.
- No mezclar lógica de LLM o LangGraph en `app.py`.
- No mezclar lógica de extracción de documentos en `app.py` (usar servicios de infraestructura y aplicación).
- Mantener `temperature=0` para salidas reproducibles.
- La salida del LLM debe ser siempre JSON válido conforme al contrato.
- Preservar compatibilidad entre API REST, Streamlit, CLI y MCP: comparten el mismo workflow.

---

## Reglas Para Cambios En El Workflow

Antes de modificar nodos, estado o checkpointing:

- Revisar `FunctionalAnalysisWorkflowState`.
- Verificar que `app.py`, `run_cli.py` y `LangGraphFunctionalAnalysisRunner` construyan el estado inicial correctamente.
- Verificar que `workflow.get_state(config)` siga devolviendo `functional_analysis`.
- Mantener `thread_id` configurable para checkpointing.
- No cambiar nombres de nodos sin revisar historial, diagnósticos y dependencias.

---

## Reglas Para Prompts

Al editar `src/infrastructure/agents/prompts.py`:

- No pedir estimaciones, horas, puntos ni costos.
- No permitir tareas ajenas al requerimiento.
- Mantener una estructura JSON obligatoria conforme a `FunctionalAnalysisSchema`.
- Pedir inferencias técnicas razonables solo si derivan del requerimiento.
- Evitar cambios que rompan el parseo en cascada o la normalización.

---

## Testing Y Verificación

Actualmente no hay suite de tests configurada. Para cambios funcionales, verificar:

**Via CLI:**
```powershell
python .\run_cli.py "Se requiere implementar login, recuperación de clave y ABM de usuarios."
```

**Via API REST JSON** (con curl o Postman):
```powershell
curl -X POST http://localhost:8000/api/v1/functional-analysis `
  -H "Content-Type: application/json" `
  -H "Authorization: Bearer <access_token>" `
  -d "{\"specification\": \"Se requiere implementar login y ABM de usuarios.\", \"skip_previous_evaluation\": false}"
```

**Via API REST multipart** (con curl):
```powershell
curl -X POST http://localhost:8000/api/v1/functional-analysis/upload `
  -H "Authorization: Bearer <access_token>" `
  -F "specification=Contexto adicional manual" `
  -F "files=@.\especificacion.pdf" `
  -F "files=@.\anexo.docx"
```

**Via MCP Inspector:**
Usar el inspector con:
- Command: `C:\Proyectos\Nexplan-Agente\NexplanAgente-Backend\venv\Scripts\python.exe`
- Arguments: `C:\Proyectos\Nexplan-Agente\NexplanAgente-Backend\src\mcp\mcp_server.py`

Luego invocar la tool `analyze_functional_requirement` con `specification`.

**Validar manualmente:**
- La CLI imprime JSON válido.
- `detected_tasks` contiene objetos con `name` y `description`.
- La UI muestra resumen, tareas, metadatos e historial.
- La API retorna `200` con `needs_complete_specification: false` y el análisis completo, o `true` con `requested_detail` si falta información.
- Los errores de configuración se presentan de forma clara (401, 503, 504).
- El endpoint multipart acepta `.txt`, `.pdf` y `.docx` y consolida el contenido correctamente.
- Archivos inválidos o vacíos devuelven `400` con descripción del error.
- Las tools MCP responden con el mismo contrato `FunctionalAnalysisApiResponse`.

---

## Archivos Que No Deben Editarse Salvo Indicación Explícita

- `venv/**`
- `__pycache__/**`
- `*.pyc`
- `streamlit.err.log`
- `streamlit.out.log`
- `nexplan_workflow_analisis.db`

---

## Riesgos Conocidos

- La calidad de salida depende del modelo y del endpoint configurado.
- El parseo tiene fallback defensivo, pero cambios grandes en el prompt pueden degradar la normalización.
- La base SQLite es estado local de ejecución, no fuente de verdad.
- Cualquier secreto hardcodeado debe eliminarse y reemplazarse por variables de entorno.
- `LLM_VERIFY_TLS=false` solo debe usarse en entornos locales controlados.
- PDFs compuestos solo por imágenes (sin capa de texto) no producirán texto extraíble; el archivo será descartado con advertencia.
- Archivos DOCX con contenido exclusivamente en tablas o cuadros de texto pueden no extraerse completamente con `python-docx`.
- El servidor MCP confía en el entorno local de ejecución; no aporta autenticación propia sobre stdio.

---

## Criterio De Finalización Para Agentes

Un cambio está listo cuando:

- Mantiene el contrato de salida (`FunctionalAnalysisSchema`).
- Funciona desde CLI, Streamlit, API REST y MCP.
- No introduce secretos en código fuente ni commits.
- No edita artefactos locales.
- Conserva la separación entre capas (API / Use Cases / Domain / Infrastructure).
- Documenta cualquier cambio de comportamiento relevante en este archivo.
