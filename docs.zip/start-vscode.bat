@echo off

set http_proxy=http://proxy-azure.grupo.ypf.com
set https_proxy=http://proxy-azure.grupo.ypf.com

cd /d C:\Proyectos\Nexplan-Agente\NexplanAgente-Backend
code .