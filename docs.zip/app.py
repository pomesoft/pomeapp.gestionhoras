from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List

import streamlit as st

from src.application.services.specification_consolidator import consolidate_specification
from src.domain.models.schemas import empty_analysis, sufficient_evaluation
from src.infrastructure.agents.graph import create_functional_analysis_workflow
from src.infrastructure.config.settings import ConfigError, Settings
from src.infrastructure.documents.document_text_extractor import document_text_extractor



st.set_page_config(page_title="Nexplan - Analisis Funcional", layout="wide")


def create_ticket_id() -> str:
    return f"AF-{uuid.uuid4().hex[:6].upper()}"


def get_functional_analysis_workflow():
    if "functional_analysis_workflow" not in st.session_state:
        st.session_state.functional_analysis_workflow = create_functional_analysis_workflow()
    return st.session_state.functional_analysis_workflow


def process_functional_analysis_workflow(
    functional_specification: str,
    ticket_id: str,
    skip_previous_evaluation: bool = False,
):
          
    initial_state = {
        "functional_specification": functional_specification,
        "skip_previous_functional_analysis_evaluation": skip_previous_evaluation,
        "specification_evaluation": sufficient_evaluation(),
        "functional_analysis": empty_analysis(),
        "diagnostics": {
            "workflow": "functional_analysis",
            "model": "",
            "parse_method": "",
            "trace": [],
        },
        "history": [],
    }
    config = {"configurable": {"thread_id": f"{ticket_id}-wf1"}}
    history: List[str] = []

    workflow = get_functional_analysis_workflow()
    for chunk in workflow.stream(initial_state, config=config, stream_mode="updates"):
        for _, output in chunk.items():
            if "history" in output and output["history"]:
                history.extend(output["history"])

    final_state = workflow.get_state(config)
    values = final_state.values if hasattr(final_state, "values") else final_state
    evaluation = values.get("specification_evaluation", sufficient_evaluation())
    analysis = values.get("functional_analysis", empty_analysis())

    
    return evaluation, analysis, history, config


def _render_list(title: str, items: List[str]):
    st.markdown(f"**{title}**")
    if not items:
        st.caption("Sin datos")
        return
    st.markdown("\n".join([f"- {item}" for item in items]))


def render_functional_analysis(analysis: Dict[str, Any]):
    st.subheader("Analisis funcional detectado por IA")

    st.markdown("**Resumen funcional**")
    summary = str(analysis.get("functional_summary", "")).strip()
    st.write(summary if summary else "Sin resumen funcional")

    st.markdown("**Tareas detectadas**")
    tasks = analysis.get("detected_tasks", [])
    if isinstance(tasks, list) and tasks:
        rows = []
        for task in tasks:
            if not isinstance(task, dict):
                continue
            rows.append(
                {
                    "Nombre": str(task.get("name", "")).strip(),
                    "Descripcion": str(task.get("description", "")).strip(),
                }
            )
        if rows:
            st.dataframe(rows, use_container_width=True, hide_index=True)
        else:
            st.caption("Sin tareas estructuradas")
    else:
        st.caption("Sin tareas detectadas")

    col1, col2 = st.columns(2)
    with col1:
        _render_list("Componentes tecnicos", analysis.get("technical_components", []))
        _render_list(
            "Integraciones detectadas", analysis.get("detected_integrations", [])
        )
        _render_list("Riesgos detectados", analysis.get("detected_risks", []))
    with col2:
        _render_list("Supuestos realizados", analysis.get("assumptions", []))
        _render_list("Observaciones", analysis.get("observations", []))

    metadata = analysis.get("analysis_metadata", {}) or {}
    with st.expander("Metadatos y JSON completo"):
        st.caption(
            "Modelo: "
            f"{metadata.get('model', '')} | "
            "Parseo: "
            f"{metadata.get('parse_method', '')} | "
            "Tareas: "
            f"{metadata.get('task_count', 0)}"
        )
        st.json(analysis)


def render_incomplete_evaluation(evaluation: Dict[str, Any]):
    st.warning("La especificacion funcional necesita mas informacion antes del analisis.")
    st.markdown("**Detalle solicitado**")
    st.write(str(evaluation.get("requested_detail", "")).strip())
    with st.expander("JSON de evaluacion"):
        st.json(evaluation)


def initialize_state():
    if "current_analysis" not in st.session_state:
        st.session_state.current_analysis = empty_analysis()
    if "current_evaluation" not in st.session_state:
        st.session_state.current_evaluation = sufficient_evaluation()
    if "current_wf1_history" not in st.session_state:
        st.session_state.current_wf1_history = []
    if "current_ticket" not in st.session_state:
        st.session_state.current_ticket = ""
    if "tickets" not in st.session_state:
        st.session_state.tickets = {}


def _extract_and_consolidate(
    manual_text: str,
    uploaded_files,
) -> tuple[str, list[str]]:
    """Extract text from uploaded files and consolidate with manual text.

    Returns:
        consolidated_specification: The merged specification string.
        warnings: List of warning messages for files that failed extraction.
    """
    extraction_results = []
    for uploaded_file in uploaded_files or []:
        content = uploaded_file.read()
        result = document_text_extractor.extract(uploaded_file.name, content)
        extraction_results.append(result)

    consolidation = consolidate_specification(
        manual_text=manual_text,
        extraction_results=extraction_results,
    )

    warnings: list[str] = []
    for failed_filename, failed_error in consolidation.failed_files:
        warnings.append(
            f"No se pudo extraer texto de '{failed_filename}': {failed_error or 'error desconocido'}"
        )

    return consolidation.specification, warnings


def main():
    initialize_state()

    st.title("Nexplan - Agente Analista Funcional")
    st.markdown(
        "Analiza una especificacion funcional y devuelve una salida estructurada. "
        "No calcula estimaciones ni ejecuta workflows de perfiles."
    )

    functional_specification = st.text_area(
        "Especificacion funcional (opcional si adjunta documentos)",
        height=200,
        placeholder=(
            "Ejemplo:\n\n"
            "Se requiere implementar un modulo de autenticacion con login, "
            "recuperacion de contrasena, validacion de sesion y ABM de usuarios."
        ),
    )

    uploaded_files = st.file_uploader(
        "Documentacion adjunta (opcional)",
        type=["txt", "pdf", "docx"],
        accept_multiple_files=True,
        help="Formatos soportados: .txt, .pdf, .docx. Puede adjuntar multiples archivos.",
    )

    if uploaded_files:
        st.markdown("**Archivos cargados:**")
        for uf in uploaded_files:
            size_kb = round(uf.size / 1024, 1) if hasattr(uf, "size") else "?"
            st.caption(f"- {uf.name} ({size_kb} KB)")

    skip_previous_evaluation = st.checkbox(
        "Evitar evaluacion previa al analisis funcional.",
        value=False,
    )

    if st.button("Analizar especificacion funcional", use_container_width=True):
        has_text = bool(functional_specification.strip())
        has_files = bool(uploaded_files)

        if not has_text and not has_files:
            st.warning(
                "Debe ingresar una especificacion funcional o adjuntar al menos un documento."
            )
            st.stop()

        # Extract and consolidate if files are present
        if has_files:
            with st.spinner("Extrayendo texto de los documentos adjuntos..."):
                consolidated_spec, extraction_warnings = _extract_and_consolidate(
                    manual_text=functional_specification.strip(),
                    uploaded_files=uploaded_files,
                )

            for warning_msg in extraction_warnings:
                st.warning(warning_msg)

            if not consolidated_spec.strip():
                st.error(
                    "No se pudo obtener texto de ningun documento ni del campo de texto. "
                    "Verifique los archivos adjuntos."
                )
                st.stop()
        else:
            consolidated_spec = functional_specification.strip()

        ticket_id = create_ticket_id()
        try:
            with st.spinner("Ejecutando Workflow 1: analisis funcional..."):
                evaluation, analysis, history, wf1_config = (
                    process_functional_analysis_workflow(
                        consolidated_spec,
                        ticket_id,
                        skip_previous_evaluation=skip_previous_evaluation,
                    )
                )
        except ConfigError as exc:
            st.error(str(exc))
            st.stop()
        except Exception as exc:
            st.error(f"Error ejecutando workflow 1: {str(exc)}")
            st.stop()

        st.session_state.current_ticket = ticket_id
        st.session_state.current_evaluation = evaluation
        st.session_state.current_analysis = analysis
        st.session_state.current_wf1_history = history
        st.session_state.tickets[ticket_id] = {
            "specification_evaluation": evaluation,
            "functional_analysis": analysis,
            "wf1_history": history,
            "wf1_config": wf1_config,
            "timestamp": datetime.now().strftime("%H:%M:%S"),
        }
        if evaluation.get("needs_complete_specification"):
            st.info("Workflow 1 solicito completar la especificacion.")
        else:
            st.success("Workflow 1 ejecutado correctamente.")

    current_evaluation = st.session_state.current_evaluation or sufficient_evaluation()
    current_analysis = st.session_state.current_analysis or empty_analysis()
    has_analysis = bool(current_analysis.get("detected_tasks")) or bool(
        str(current_analysis.get("functional_summary", "")).strip()
    )

    if current_evaluation.get("needs_complete_specification"):
        render_incomplete_evaluation(current_evaluation)
    elif has_analysis:
        render_functional_analysis(current_analysis)

        with st.expander("Diagnostico workflow 1"):
            if st.session_state.current_wf1_history:
                st.markdown(
                    "\n".join([f"- {item}" for item in st.session_state.current_wf1_history])
                )
            else:
                st.caption("Sin historial")

    with st.sidebar:
        st.header("Workflow activo")
        st.markdown("- Analisis funcional")
        st.caption("Perfiles, RAG y creacion de funciones quedan fuera de esta etapa.")


if __name__ == "__main__":
    main()
