import pytest

from src.mcp.tools import analyze_functional_requirement
from src.mcp.mcp_server import mcp


@pytest.mark.anyio
async def test_mcp_tools_are_registered() -> None:
    tools = await mcp.list_tools()
    names = {tool.name for tool in tools}

    assert "analyze_functional_requirement" in names


def test_analyze_functional_requirement_empty_spec() -> None:
    result = analyze_functional_requirement(specification="")

    assert result["needs_complete_specification"] is True
    assert "mayor detalle" in result["requested_detail"]
    assert result["analysis"]["functional_summary"] == ""
    assert result["diagnostics"]["parse_method"] == "specification_evaluation"
