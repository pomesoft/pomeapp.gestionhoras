"""
Pruebas unitarias para src/api/security/azure_ad_validator.py

Cubre:
- Token válido → payload retornado correctamente
- Token expirado → 401 con "Token expirado."
- Token con audience incorrecto → 401 con "audience incorrecto"
- Token con issuer incorrecto → 401 con "issuer incorrecto"
- Token ausente / mal formado (sin kid) → 401
- Token con kid no encontrado en JWKS → 401
- JWKS endpoint no disponible → 503
- Cache de JWKS: segunda llamada no realiza nuevo request HTTP
"""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch, call
from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials
from jose import JWTError

# Módulo bajo prueba
import src.api.security.azure_ad_validator as validator_module
from src.api.security.azure_ad_validator import (
    validate_azure_ad_token,
    _fetch_jwks,
    _get_signing_key,
    _jwks_cache,
)
from src.infrastructure.config.settings import Settings


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

TENANT_ID = "038018c3-616c-4b46-ad9b-aa9007f701b5"
CLIENT_ID = "39946bc0-d91d-40ac-86d9-6a2f74306738"
AUDIENCE = f"api://{CLIENT_ID}"
INSTANCE = "https://login.microsoftonline.com/"
JWKS_URI = f"{INSTANCE.rstrip('/')}/{TENANT_ID}/discovery/v2.0/keys"
ISSUER = f"{INSTANCE.rstrip('/')}/{TENANT_ID}/v2.0"

FAKE_KID = "fake-kid-001"
FAKE_TOKEN = "header.payload.signature"

FAKE_JWKS = {
    "keys": [
        {
            "kid": FAKE_KID,
            "kty": "RSA",
            "use": "sig",
            "n": "sampleN",
            "e": "AQAB",
        }
    ]
}

VALID_PAYLOAD = {
    "sub": "user-001",
    "aud": AUDIENCE,
    "iss": ISSUER,
    "exp": 9999999999,
}


@pytest.fixture()
def settings() -> Settings:
    """Settings configurados con los parámetros de Azure AD."""
    return Settings(
        AZURE_TENANT_ID=TENANT_ID,
        AZURE_CLIENT_ID=CLIENT_ID,
        AZURE_AUDIENCE=AUDIENCE,
        AZURE_INSTANCE=INSTANCE,
        AZURE_CLIENT_SECRET="secret",
        LLM_API_KEY="dummy-key",
    )


@pytest.fixture(autouse=True)
def clear_jwks_cache():
    """Limpia el cache de JWKS antes de cada test para evitar contaminación."""
    _jwks_cache.clear()
    yield
    _jwks_cache.clear()


def _make_credentials(token: str = FAKE_TOKEN) -> HTTPAuthorizationCredentials:
    return HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)


# ---------------------------------------------------------------------------
# Helpers de mock
# ---------------------------------------------------------------------------

def _mock_httpx_get(jwks_response: dict | None = None, raise_error: bool = False):
    """Devuelve un mock para httpx.get."""
    if raise_error:
        import httpx
        mock = MagicMock(side_effect=httpx.HTTPError("connection error"))
        return mock

    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = jwks_response or FAKE_JWKS
    mock = MagicMock(return_value=mock_response)
    return mock


# ---------------------------------------------------------------------------
# Tests: _fetch_jwks
# ---------------------------------------------------------------------------

class TestFetchJwks:
    def test_retorna_jwks_correctamente(self):
        with patch("httpx.get", _mock_httpx_get()):
            result = _fetch_jwks(JWKS_URI)

        assert result == FAKE_JWKS

    def test_cachea_resultado_segunda_llamada_no_hace_request(self):
        mock_get = _mock_httpx_get()
        with patch("httpx.get", mock_get):
            _fetch_jwks(JWKS_URI)
            _fetch_jwks(JWKS_URI)

        # httpx.get debe haber sido llamado UNA sola vez
        assert mock_get.call_count == 1

    def test_lanza_503_si_jwks_endpoint_no_disponible(self):
        import httpx
        mock_get = MagicMock(side_effect=httpx.HTTPError("timeout"))

        with patch("httpx.get", mock_get):
            with pytest.raises(HTTPException) as exc_info:
                _fetch_jwks(JWKS_URI)

        assert exc_info.value.status_code == 503
        assert "autenticación" in exc_info.value.detail.lower() or "autenticacion" in exc_info.value.detail.lower()


# ---------------------------------------------------------------------------
# Tests: _get_signing_key
# ---------------------------------------------------------------------------

class TestGetSigningKey:
    def test_retorna_clave_correcta_para_kid_valido(self):
        fake_key = MagicMock()

        with patch("httpx.get", _mock_httpx_get()):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       return_value={"kid": FAKE_KID}):
                with patch("src.api.security.azure_ad_validator.jwk.construct",
                           return_value=fake_key) as mock_construct:
                    result = _get_signing_key(FAKE_TOKEN, JWKS_URI)

        assert result is fake_key
        mock_construct.assert_called_once()

    def test_lanza_401_si_token_mal_formado(self):
        with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                   side_effect=JWTError("bad token")):
            with pytest.raises(HTTPException) as exc_info:
                _get_signing_key(FAKE_TOKEN, JWKS_URI)

        assert exc_info.value.status_code == 401
        assert "mal formado" in exc_info.value.detail.lower()

    def test_lanza_401_si_falta_kid_en_header(self):
        with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                   return_value={"alg": "RS256"}):  # sin kid
            with pytest.raises(HTTPException) as exc_info:
                _get_signing_key(FAKE_TOKEN, JWKS_URI)

        assert exc_info.value.status_code == 401
        assert "kid" in exc_info.value.detail.lower()

    def test_lanza_401_si_kid_no_encontrado_en_jwks(self):
        jwks_sin_kid = {"keys": [{"kid": "otro-kid", "kty": "RSA"}]}

        with patch("httpx.get", _mock_httpx_get(jwks_response=jwks_sin_kid)):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       return_value={"kid": "kid-inexistente"}):
                with pytest.raises(HTTPException) as exc_info:
                    _get_signing_key(FAKE_TOKEN, JWKS_URI)

        assert exc_info.value.status_code == 401
        assert "clave de firma" in exc_info.value.detail.lower()


# ---------------------------------------------------------------------------
# Tests: validate_azure_ad_token (dependencia principal)
# ---------------------------------------------------------------------------

class TestValidateAzureAdToken:
    """Pruebas de integración interna de validate_azure_ad_token."""

    def _call(self, settings: Settings, token: str = FAKE_TOKEN) -> dict:
        credentials = _make_credentials(token)
        return validate_azure_ad_token(credentials=credentials, settings=settings)

    # ------------------------------------------------------------------
    # Token válido
    # ------------------------------------------------------------------

    def test_token_valido_retorna_payload(self, settings):
        fake_key = MagicMock()

        with patch("httpx.get", _mock_httpx_get()):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       return_value={"kid": FAKE_KID}):
                with patch("src.api.security.azure_ad_validator.jwk.construct",
                           return_value=fake_key):
                    with patch("src.api.security.azure_ad_validator.jwt.decode",
                               return_value=VALID_PAYLOAD) as mock_decode:
                        result = self._call(settings)

        assert result == VALID_PAYLOAD
        mock_decode.assert_called_once_with(
            FAKE_TOKEN,
            fake_key,
            algorithms=["RS256"],
            audience=AUDIENCE,
            issuer=ISSUER,
            options={
                "verify_exp": True,
                "verify_aud": True,
                "verify_iss": True,
            },
        )

    # ------------------------------------------------------------------
    # Token expirado
    # ------------------------------------------------------------------

    def test_token_expirado_lanza_401(self, settings):
        fake_key = MagicMock()

        with patch("httpx.get", _mock_httpx_get()):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       return_value={"kid": FAKE_KID}):
                with patch("src.api.security.azure_ad_validator.jwk.construct",
                           return_value=fake_key):
                    with patch("src.api.security.azure_ad_validator.jwt.decode",
                               side_effect=JWTError("Signature has expired")):
                        with pytest.raises(HTTPException) as exc_info:
                            self._call(settings)

        assert exc_info.value.status_code == 401
        assert "expirado" in exc_info.value.detail.lower()
        assert exc_info.value.headers.get("WWW-Authenticate") == "Bearer"

    # ------------------------------------------------------------------
    # Audience incorrecto
    # ------------------------------------------------------------------

    def test_audience_incorrecto_lanza_401(self, settings):
        fake_key = MagicMock()

        with patch("httpx.get", _mock_httpx_get()):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       return_value={"kid": FAKE_KID}):
                with patch("src.api.security.azure_ad_validator.jwk.construct",
                           return_value=fake_key):
                    with patch("src.api.security.azure_ad_validator.jwt.decode",
                               side_effect=JWTError("Invalid audience")):
                        with pytest.raises(HTTPException) as exc_info:
                            self._call(settings)

        assert exc_info.value.status_code == 401
        assert "audience" in exc_info.value.detail.lower()
        assert exc_info.value.headers.get("WWW-Authenticate") == "Bearer"

    # ------------------------------------------------------------------
    # Issuer incorrecto
    # ------------------------------------------------------------------

    def test_issuer_incorrecto_lanza_401(self, settings):
        fake_key = MagicMock()

        with patch("httpx.get", _mock_httpx_get()):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       return_value={"kid": FAKE_KID}):
                with patch("src.api.security.azure_ad_validator.jwk.construct",
                           return_value=fake_key):
                    with patch("src.api.security.azure_ad_validator.jwt.decode",
                               side_effect=JWTError("Invalid issuer")):
                        with pytest.raises(HTTPException) as exc_info:
                            self._call(settings)

        assert exc_info.value.status_code == 401
        assert "issuer" in exc_info.value.detail.lower()
        assert exc_info.value.headers.get("WWW-Authenticate") == "Bearer"

    # ------------------------------------------------------------------
    # Token mal formado (no se puede leer el header)
    # ------------------------------------------------------------------

    def test_token_mal_formado_lanza_401(self, settings):
        with patch("httpx.get", _mock_httpx_get()):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       side_effect=JWTError("bad token format")):
                with pytest.raises(HTTPException) as exc_info:
                    self._call(settings)

        assert exc_info.value.status_code == 401
        assert exc_info.value.headers.get("WWW-Authenticate") == "Bearer"

    # ------------------------------------------------------------------
    # JWTError genérico (no categorizado)
    # ------------------------------------------------------------------

    def test_jwt_error_generico_lanza_401_con_detalle(self, settings):
        fake_key = MagicMock()

        with patch("httpx.get", _mock_httpx_get()):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       return_value={"kid": FAKE_KID}):
                with patch("src.api.security.azure_ad_validator.jwk.construct",
                           return_value=fake_key):
                    with patch("src.api.security.azure_ad_validator.jwt.decode",
                               side_effect=JWTError("some unknown error")):
                        with pytest.raises(HTTPException) as exc_info:
                            self._call(settings)

        assert exc_info.value.status_code == 401
        assert "inválido" in exc_info.value.detail.lower() or "invalido" in exc_info.value.detail.lower()

    # ------------------------------------------------------------------
    # JWKS endpoint no disponible
    # ------------------------------------------------------------------

    def test_jwks_no_disponible_lanza_503(self, settings):
        import httpx

        with patch("httpx.get", side_effect=httpx.HTTPError("connection refused")):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       return_value={"kid": FAKE_KID}):
                with pytest.raises(HTTPException) as exc_info:
                    self._call(settings)

        assert exc_info.value.status_code == 503

    # ------------------------------------------------------------------
    # Kid no encontrado en JWKS (con reintento y limpieza de cache)
    # ------------------------------------------------------------------

    def test_kid_no_encontrado_lanza_401_y_limpia_cache(self, settings):
        jwks_sin_match = {"keys": [{"kid": "otro-kid", "kty": "RSA"}]}
        mock_get = _mock_httpx_get(jwks_response=jwks_sin_match)

        with patch("httpx.get", mock_get):
            with patch("src.api.security.azure_ad_validator.jwt.get_unverified_header",
                       return_value={"kid": "kid-que-no-existe"}):
                with pytest.raises(HTTPException) as exc_info:
                    self._call(settings)

        assert exc_info.value.status_code == 401
        assert "clave de firma" in exc_info.value.detail.lower()
        # Se deben haber hecho 2 llamadas: el intento inicial + reintento tras limpiar cache
        assert mock_get.call_count == 2

    # ------------------------------------------------------------------
    # Propiedades calculadas de Settings
    # ------------------------------------------------------------------

    def test_settings_jwks_uri_calculado_correctamente(self, settings):
        expected = (
            f"https://login.microsoftonline.com/{TENANT_ID}/discovery/v2.0/keys"
        )
        assert settings.azure_jwks_uri == expected

    def test_settings_issuer_calculado_correctamente(self, settings):
        expected = f"https://login.microsoftonline.com/{TENANT_ID}/v2.0"
        assert settings.azure_issuer == expected

    def test_settings_is_azure_ad_configured_true(self, settings):
        assert settings.is_azure_ad_configured is True

    def test_settings_is_azure_ad_configured_false_sin_tenant(self):
        s = Settings(
            AZURE_TENANT_ID="",
            AZURE_CLIENT_ID=CLIENT_ID,
            AZURE_AUDIENCE=AUDIENCE,
            LLM_API_KEY="dummy",
        )
        assert s.is_azure_ad_configured is False
