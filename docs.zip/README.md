# Agente Analista Funcional

Implementacion independiente del Workflow 1 de Nexplan.

## Alcance

- Entrada: texto libre de especificacion funcional.
- Proceso: LLM con salida estructurada Pydantic y fallback de parseo JSON/texto.
- Salida: resumen funcional, tareas detectadas y metadatos de analisis.

No incluye RAG, ChromaDB, perfiles, funciones ni calculo de estimaciones.

## Configuracion

### Variables de entorno - LLM

Configurar variables de entorno:

```powershell
$env:LLM_API_KEY="..."
$env:LLM_BASE_URL="https://foundrymobile.services.ai.azure.com/openai/v1/"
$env:LLM_PROVIDER="openai"
$env:LLM_MODEL="gpt-4.1"
$env:LLM_TIMEOUT_SECONDS="60"
```

`LLM_VERIFY_TLS` queda en `true` por defecto. Solo usar `false` en entornos locales controlados si el endpoint lo requiere.

Las variables legacy `API_KEY_LLM` y `BASE_URL_LLM` siguen siendo aceptadas por compatibilidad.

### Variables de entorno - Azure AD (OAuth2 / OpenID Connect)

El endpoint `POST /api/v1/functional-analysis` requiere autenticacion mediante Bearer Token validado contra Azure AD.

```powershell
$env:AZURE_TENANT_ID="038018c3-616c-4b46-ad9b-aa9007f701b5"
$env:AZURE_CLIENT_ID="39946bc0-d91d-40ac-86d9-6a2f74306738"
$env:AZURE_CLIENT_SECRET="..."
$env:AZURE_AUDIENCE="api://39946bc0-d91d-40ac-86d9-6a2f74306738"
```

Ver `.env.example` para la lista completa de variables requeridas. **Nunca commitear el archivo `.env` real** (ya incluido en `.gitignore`).

### Observabilidad

La telemetria de Azure Monitor OpenTelemetry se habilita si existe:

```powershell
$env:APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=...;IngestionEndpoint=..."
$env:OTEL_SERVICE_NAME="nexplan-functional-analysis-api"
$env:TELEMETRY_LOGGER_NAME="NEXPLAN-AGENTE"
$env:TELEMETRY_LOGGER_NAME_KPI="NEXPLAN-AGENTE-KPI"
$env:TELEMETRY_LIVE_METRICS_ENABLED="false"
```

Si `APPLICATIONINSIGHTS_CONNECTION_STRING` no esta configurada, la aplicacion continua con logging local.

## Autenticacion - Flujo OAuth2 / OpenID Connect

### Descripcion

La API utiliza validacion de tokens JWT emitidos por **Azure Active Directory** siguiendo el estandar OpenID Connect / OAuth2.

**Flujo esperado:**

1. El cliente obtiene un `access_token` desde Azure AD usando el flujo correspondiente (client credentials, authorization code, etc.).
2. El cliente incluye el token en el header `Authorization` de cada request al endpoint protegido.
3. La API valida el token contra las claves publicas del tenant (`/.well-known/openid-configuration`).
4. Si el token es valido (firma, expiración, audience, issuer), la solicitud es procesada. Caso contrario se retorna `HTTP 401`.

### Parametros de validacion

| Parametro | Valor |
|-----------|-------|
| Instance  | `https://login.microsoftonline.com/` |
| TenantId  | `038018c3-616c-4b46-ad9b-aa9007f701b5` |
| ClientId  | `39946bc0-d91d-40ac-86d9-6a2f74306738` |
| Audience  | `api://39946bc0-d91d-40ac-86d9-6a2f74306738` |
| Issuer    | `https://login.microsoftonline.com/038018c3-616c-4b46-ad9b-aa9007f701b5/v2.0` |

### Ejemplo de uso con curl

```bash
curl -X 'POST' \
  'http://localhost:8000/api/v1/functional-analysis' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer <access_token>' \
  -d '{
    "specification": "se requiere una aplicacion web para gestionar almacenes...",
    "skip_previous_evaluation": false
  }'
```

### Errores de autenticacion

| Codigo HTTP | Descripcion |
|-------------|-------------|
| `401 Unauthorized` | Token ausente, malformado, expirado, con audience incorrecto o issuer incorrecto |

## Instalar paquetes

Todos los package que se deben instalar estan en "requirements.txt"

```powershell
pip install -r requirements.txt
```

## Crear y/o activar Environment
### Crear
```powershell
python -m venv venv
```
### Activar
```powershell
venv\Scripts\activate
```

## Ejecucion FastAPI

La WebAPI expone el agente como backend sincrono y stateless:

```powershell
uvicorn src.main:app --reload --port 8585
```

Endpoints:

- `GET /health`
- `GET /ready`
- `POST /api/v1/functional-analysis` *(requiere Bearer Token de Azure AD)*

Ver especificacion tecnica y diagramas en `docs/backend_architecture.md`.

## Ejecucion Streamlit

Desde esta carpeta:

```powershell
streamlit run app.py
```

Desde la raiz del proyecto:

```powershell
streamlit run .\analisis_funcional\app.py
```

## Ejecucion CLI

```powershell
python .\run_cli.py "Se requiere implementar login, recuperacion de clave y ABM de usuarios."
```

O desde archivo:

```powershell
python .\run_cli.py --file .\especificacion.txt
```

## Ejecucion FastMCP

```powershell
fastmcp run .\src\mcp\mcp_server.py:mcp --transport http --port 8686
```

```powershell
$env:HTTP_PROXY=""; $env:HTTPS_PROXY=""; npx -y @modelcontextprotocol/inspector
```
* Command
```powershell
C:\Proyectos\Nexplan-Agente\NexplanAgente-Backend\venv\Scripts\python.exe
```

* Arguments
```powershell
C:\\Proyectos\\Nexplan-Agente\\NexplanAgente-Backend\\src\\mcp\\mcp_server.py
```