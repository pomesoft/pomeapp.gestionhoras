from __future__ import annotations

import argparse
import json
import uuid

from src.domain.models.schemas import empty_analysis, sufficient_evaluation
from src.infrastructure.agents.graph import create_functional_analysis_workflow
from src.infrastructure.config.settings import ConfigError


def execute(
    functional_specification: str,
    skip_previous_evaluation: bool = False,
) -> dict:
    workflow = create_functional_analysis_workflow()
    ticket_id = f"AF-{uuid.uuid4().hex[:6].upper()}"
    config = {"configurable": {"thread_id": f"{ticket_id}-wf1"}}
    initial_state = {
        "functional_specification": functional_specification,
        "skip_previous_functional_analysis_evaluation": skip_previous_evaluation,
        "specification_evaluation": sufficient_evaluation(),
        "functional_analysis": empty_analysis(),
        "diagnostics": {
            "workflow": "functional_analysis",
            "model": "",
            "parse_method": "",
            "trace": [],
        },
        "history": [],
    }
    for _ in workflow.stream(initial_state, config=config, stream_mode="updates"):
        pass
    final_state = workflow.get_state(config)
    values = final_state.values if hasattr(final_state, "values") else final_state
    evaluation = values.get("specification_evaluation", sufficient_evaluation())
    result = {
        "needs_complete_specification": bool(
            evaluation.get("needs_complete_specification", False)
        ),
        "requested_detail": str(evaluation.get("requested_detail", "")),
    }
    if not result["needs_complete_specification"]:
        result["analysis"] = values.get("functional_analysis", empty_analysis())
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Ejecuta el agente de analisis funcional.")
    parser.add_argument("texto", nargs="*", help="Especificacion funcional a analizar.")
    parser.add_argument("--file", help="Archivo de texto con la especificacion funcional.")
    parser.add_argument(
        "--skip-previous-evaluation",
        action="store_true",
        help="Salta la evaluacion previa y ejecuta directamente el analisis funcional.",
    )
    args = parser.parse_args()

    if args.file:
        with open(args.file, "r", encoding="utf-8") as file:
            specification = file.read()
    else:
        specification = " ".join(args.texto).strip()

    if not specification:
        parser.error("Debe indicar texto o --file.")

    try:
        result = execute(
            specification,
            skip_previous_evaluation=args.skip_previous_evaluation,
        )
    except ConfigError as exc:
        print(str(exc))
        return 2

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
